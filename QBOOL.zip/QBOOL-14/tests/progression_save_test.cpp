#include "../src/economy.hpp"
#include <cassert>
#include <cstdint>
#include <iostream>
int main() {
  eco::Save s; s.coins=4321; s.lastSpinMin=123; s.xp=987; s.level=10;
  s.weeklyDay=3000; s.weeklyGames=4; s.weeklyWins=2; s.weeklyTiles=18;
  s.dailyClaimed=5; s.weeklyClaimed=3;
  int32_t data[eco::SAVE_INTS]{}; eco::ToInts(s,data);
  eco::Save loaded; assert(eco::FromInts(data,loaded));
  assert(loaded.coins==4321 && loaded.lastSpinMin==123 && loaded.xp==987 && loaded.level==10);
  assert(loaded.weeklyDay==3000 && loaded.weeklyGames==4 && loaded.weeklyWins==2 && loaded.weeklyTiles==18);
  assert(loaded.dailyClaimed==5 && loaded.weeklyClaimed==3);
  // Validate the v4 checksum and reject tampered data.
  data[4] ^= 1; eco::Save untouched; untouched.coins=77; assert(!eco::FromInts(data,untouched)); assert(untouched.coins==77);
  // Migrate a previous QB03 save without losing wallet / XP / streak.
  int32_t old[eco::SAVE_INTS_V3]{}; int k=0;
  old[k++]=eco::SAVE_MAGIC_V3; old[k++]=765;
  for(int c=0;c<eco::NUM_CATS;c++) old[k++]=1u;
  for(int c=0;c<eco::NUM_CATS;c++) old[k++]=0;
  old[k++]=8; old[k++]=3; old[k++]=12; old[k++]=400;
  old[k++]=3000; old[k++]=4; old[k++]=123; old[k++]=987; old[k++]=10;
  old[k++]=2; old[k++]=5; old[k++]=3000; old[k++]=3; old[k++]=2; old[k++]=10;
  old[k++]=7; old[k++]=220;
  old[k]=eco::Checksum(old,k);
  eco::Save migrated; assert(eco::FromInts(old,migrated,eco::SAVE_INTS_V3));
  assert(migrated.coins==765 && migrated.xp==987 && migrated.level==10 && migrated.bestStreak==5);
  assert(migrated.weeklyGames==0 && migrated.dailyClaimed==0);
  std::cout << "Progression save round-trip + QB03 migration OK\n";
}
