// Unit tests for the pure game logic (no graphics). Run with: ctest
#include "game_logic.hpp"
#include "economy.hpp"
#include <cmath>
#include <cstdio>
#include <cstdlib>

static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static uint16_t bit(int n) { return (uint16_t)(1u << n); }

int main() {
    Board b;
    CHECK(NUM_TILES == 10 && b.openCount() == 10 && !b.allShut());

    // dice 2 and 4: close 2+4, or close 6
    auto o = findOptions(b, 2, 4);
    CHECK(o.size() == 2 && o[0] == (bit(2) | bit(4)) && o[1] == bit(6));

    // the player closes 2 and 4, then rolls 3 and 4: 4 is closed -> only 3, or 7
    b.open[2] = false; b.open[4] = false;
    o = findOptions(b, 3, 4);
    CHECK(o.size() == 2 && o[0] == bit(3) && o[1] == bit(7));

    // doubles: close the tile, or the sum
    Board c;
    o = findOptions(c, 3, 3);
    CHECK(o.size() == 2 && o[0] == bit(3) && o[1] == bit(6));
    // double 6: the sum 12 has no tile any more -> only tile 6
    o = findOptions(c, 6, 6);
    CHECK(o.size() == 1 && o[0] == bit(6));
    // 5 + 6: the sum 11 has no tile -> only "close 5 and 6"
    o = findOptions(c, 5, 6);
    CHECK(o.size() == 1 && o[0] == (bit(5) | bit(6)));
    // 4 + 6: the sum 10 is the last tile
    o = findOptions(c, 4, 6);
    CHECK(o.size() == 2 && o[0] == (bit(4) | bit(6)) && o[1] == bit(10));

    // no move
    Board d; d.open.fill(false);
    CHECK(findOptions(d, 2, 3).empty() && d.allShut());
    Board e; e.open.fill(false); e.open[1] = true;     // only tile 1 left
    CHECK(findOptions(e, 3, 4).empty());
    CHECK(findOptions(e, 1, 4).size() == 1);

    // sum 7 closed, dice tiles open
    Board f; f.open[7] = false;
    o = findOptions(f, 3, 4);
    CHECK(o.size() == 1 && o[0] == (bit(3) | bit(4)));

    // DP sanity
    CHECK(std::fabs(expectedRolls(0)) < 1e-6f);
    const float full = expectedRolls(c.openMask());
    std::printf("expected rolls to shut the box (optimal): %.2f\n", full);
    CHECK(full > 5.0f && full < 200.0f);
    CHECK(expectedRolls(bit(1)) > 1.0f);

    // bots return a legal option
    auto opts = findOptions(c, 1, 4);
    for (int diff = 0; diff < 3; ++diff) {
        uint16_t p = botPick(c, opts, (Difficulty)diff, 0.7f);
        bool ok = false; for (auto x : opts) if (x == p) ok = true;
        CHECK(ok);
    }

    // Monte-Carlo: rolls needed to finish, per difficulty (lower is better)
    auto play = [](Difficulty diff, unsigned seed) {
        std::srand(seed);
        double total = 0; const int N = 3000;
        for (int g = 0; g < N; ++g) {
            Board bd; int rolls = 0;
            while (!bd.allShut() && rolls < 5000) {
                ++rolls;
                auto op = findOptions(bd, std::rand() % 6 + 1, std::rand() % 6 + 1);
                if (op.empty()) continue;
                uint16_t pick = botPick(bd, op, diff, (float)(std::rand() % 1000) / 1000.0f);
                for (int n = 1; n <= NUM_TILES; ++n) if (pick & (1u << n)) bd.open[n] = false;
            }
            total += rolls;
        }
        return total / N;
    };
    double easy = play(Difficulty::Easy, 1), normal = play(Difficulty::Normal, 1), hard = play(Difficulty::Hard, 1);
    std::printf("avg rolls to win  easy=%.2f normal=%.2f hard=%.2f (DP %.2f)\n", easy, normal, hard, full);
    CHECK(hard <= normal + 0.3);
    CHECK(normal <= easy + 0.3);
    CHECK(std::fabs(hard - full) < 1.5);


    // ------------------------------------------------------------ economy / shop
    {
        eco::Save s;
        CHECK(s.coins == eco::START_COINS);
        for (int c = 0; c < eco::NUM_CATS; ++c) {
            CHECK(eco::ItemCount(c) >= 1 && eco::ItemCount(c) <= eco::MAX_ITEMS);
            CHECK(eco::ItemPrice(c, 0) == 0);                 // item 0 is the free default
            CHECK(eco::Owned(s, c, 0) && s.equipped[c] == 0);
            for (int i = 1; i < eco::ItemCount(c); ++i) CHECK(eco::ItemPrice(c, i) > 0 && !eco::Owned(s, c, i));
        }
        // buying: not enough coins -> nothing changes
        CHECK(!eco::Buy(s, eco::DICE, 5));                    // Royal Gold costs 500
        CHECK(s.coins == eco::START_COINS && !eco::Owned(s, eco::DICE, 5));
        // buying: enough coins
        CHECK(eco::Buy(s, eco::FELT, 1));                     // Royal Blue, 80
        CHECK(s.coins == eco::START_COINS - 80 && eco::Owned(s, eco::FELT, 1));
        CHECK(!eco::Buy(s, eco::FELT, 1));                    // cannot buy twice
        CHECK(s.coins == eco::START_COINS - 80);
        // equipping
        CHECK(!eco::Equip(s, eco::FELT, 2));                  // not owned
        CHECK(eco::Equip(s, eco::FELT, 1) && s.equipped[eco::FELT] == 1);
        CHECK(!eco::Buy(s, 99, 0) && !eco::Buy(s, eco::DICE, 99) && !eco::Buy(s, eco::DICE, -1));
        // Legendary Vault rarity labels and discounted daily-deal purchases.
        CHECK(eco::ItemRarity(eco::DICE, 0) == eco::COMMON);
        CHECK(eco::ItemRarity(eco::DICE, 1) == eco::UNCOMMON);
        CHECK(eco::ItemRarity(eco::DICE, 4) == eco::EPIC);
        CHECK(eco::ItemRarity(eco::DICE, 5) == eco::LEGENDARY);
        eco::Save deal; deal.coins = 100;
        CHECK(eco::BuyAtPrice(deal, eco::DICE, 1, 84));
        CHECK(deal.coins == 16 && eco::Owned(deal, eco::DICE, 1));
        CHECK(!eco::BuyAtPrice(deal, eco::DICE, 1, 1)); // no duplicate purchases
        CHECK(!eco::BuyAtPrice(deal, eco::DICE, 2, 999)); // no negative balance

        // rewards
        CHECK(eco::TileReward(2) == 4 && eco::TileReward(-3) == 0);
        CHECK(eco::WinReward(false, 0) == 30);
        CHECK(eco::WinReward(true, 0) < eco::WinReward(true, 1) && eco::WinReward(true, 1) < eco::WinReward(true, 2));
        eco::Save r;
        eco::AddCoins(r, 50);  CHECK(r.coins == eco::START_COINS + 50 && r.earned == 50);
        eco::AddCoins(r, -9);  CHECK(r.coins == eco::START_COINS + 50);
        eco::AddCoins(r, 2000000000); CHECK(r.coins == eco::MAX_COINS);   // capped, no overflow

        // save / load round trip
        int32_t buf[eco::SAVE_INTS];
        eco::ToInts(s, buf);
        eco::Save t;
        CHECK(eco::FromInts(buf, t));
        CHECK(t.coins == s.coins && t.equipped[eco::FELT] == 1 && eco::Owned(t, eco::FELT, 1));
        buf[1] += 1000;                                       // tampered / damaged -> rejected, `t` untouched
        const int before = t.coins;
        CHECK(!eco::FromInts(buf, t) && t.coins == before);
        int32_t zeros[eco::SAVE_INTS] = {};
        CHECK(!eco::FromInts(zeros, t));                      // empty storage = first run
        // an equipped item that is not owned is repaired on load
        eco::Save bad; bad.equipped[eco::DICE] = 3;           // 3 is not owned
        eco::ToInts(bad, buf);
        eco::Save fixed; CHECK(eco::FromInts(buf, fixed) && fixed.equipped[eco::DICE] == 0);

        // dates
        CHECK(eco::DaysFromCivil(1970, 1, 1) == 0);
        CHECK(eco::DaysFromCivil(1970, 1, 2) == 1);
        CHECK(eco::DaysFromCivil(2000, 3, 1) == 11017);
        CHECK(eco::DaysFromCivil(2026, 10, 19) - eco::DaysFromCivil(2026, 10, 18) == 1);
        CHECK(eco::DaysFromCivil(2027, 1, 1) - eco::DaysFromCivil(2026, 12, 31) == 1);
        CHECK(eco::DaysFromCivil(2024, 3, 1) - eco::DaysFromCivil(2024, 2, 28) == 2);   // leap year

        // daily gift: first claim, same day, next day (streak), gap (reset), clock going backwards
        eco::Save d;
        int day = eco::DaysFromCivil(2026, 10, 18);
        eco::Daily a = eco::ClaimDaily(d, day);
        CHECK(a.granted && a.bonus == 20 && a.streak == 1 && d.coins == eco::START_COINS + 20);
        CHECK(!eco::ClaimDaily(d, day).granted);
        eco::Daily b = eco::ClaimDaily(d, day + 1);
        CHECK(b.granted && b.bonus == 30 && b.streak == 2);
        eco::Daily c2 = eco::ClaimDaily(d, day + 5);
        CHECK(c2.granted && c2.bonus == 20 && c2.streak == 1);
        CHECK(!eco::ClaimDaily(d, day).granted);
        for (int k = 1; k <= 9; ++k) c2 = eco::ClaimDaily(d, day + 5 + k);
        CHECK(c2.bonus == 70);                                // gift is capped at 70
    }


    // ------------------------------------------------------------ wheel of fortune
    {
        // every slice reachable, frequencies follow the weights
        int total = 0; for (auto& w : eco::kWheel) total += w.weight;
        int hits[eco::WHEEL_SLOTS] = {};
        const int N = 200000;
        for (int i = 0; i < N; ++i) ++hits[eco::PickWheel((float)i / (float)N)];
        for (int i = 0; i < eco::WHEEL_SLOTS; ++i) {
            CHECK(hits[i] > 0);
            const double want = (double)N * eco::kWheel[i].weight / total;
            CHECK(std::fabs(hits[i] - want) < N * 0.001);
        }
        CHECK(eco::PickWheel(-5.0f) == 0 && eco::PickWheel(5.0f) == eco::WHEEL_SLOTS - 1);

        // first spin is free, then 24 hours of waiting
        eco::Save w;
        const int64_t t0 = 1800000000;
        CHECK(eco::WheelReady(w, t0) && eco::WheelSecondsLeft(w, t0) == 0);
        const int before = w.coins;
        const int slot = eco::SpinWheel(w, t0, 0.0f);
        CHECK(slot == 0 && w.coins == before + eco::kWheel[0].prize);
        CHECK(eco::SpinWheel(w, t0 + 10, 0.5f) == -1 && w.coins == before + eco::kWheel[0].prize);   // not ready
        CHECK(!eco::WheelReady(w, t0 + 23 * 3600));
        const int64_t left = eco::WheelSecondsLeft(w, t0 + 3600);
        CHECK(left > 22 * 3600 && left <= 23 * 3600 + 60);                                           // ~23 h left
        CHECK(eco::WheelReady(w, t0 + 24 * 3600 + 60));
        CHECK(eco::SpinWheel(w, t0 + 25 * 3600, 0.999f) == eco::WHEEL_SLOTS - 1);
        // clock moved far back: never more than 24 h of waiting
        CHECK(eco::WheelSecondsLeft(w, t0 - 30LL * 86400) <= 24 * 3600);

        // the spin time survives saving; a save from the first release still loads (no wheel yet)
        int32_t buf[eco::SAVE_INTS];
        eco::ToInts(w, buf);
        eco::Save back; CHECK(eco::FromInts(buf, back) && back.lastSpinMin == w.lastSpinMin && back.coins == w.coins);
        int32_t v1[eco::SAVE_INTS_V1];
        for (int i = 0; i < eco::SAVE_INTS_V1- 1; ++i) v1[i] = buf[i];
        v1[0] = eco::SAVE_MAGIC_V1;
        v1[eco::SAVE_INTS_V1 - 1] = eco::Checksum(v1, eco::SAVE_INTS_V1 - 1);
        eco::Save old; CHECK(eco::FromInts(v1, old, eco::SAVE_INTS_V1) && old.coins == w.coins && old.lastSpinMin == 0);
        CHECK(!eco::FromInts(v1, old, 5));                    // truncated file
    }

    if (fails == 0) std::printf("ALL TESTS PASSED\n");
    return fails == 0 ? 0 : 1;
}
