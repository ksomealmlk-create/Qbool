// Q BOOL - coins, shop catalogue and save data.
// Pure logic (no raylib) so it can be unit-tested, same as game_logic.hpp.
#pragma once
#include <algorithm>
#include <cstddef>
#include <cstdint>

namespace eco {

struct RGB { uint8_t r, g, b; };

enum Cat { DICE = 0, TABLE, FELT, TILES, SPARKS, NUM_CATS };
inline const char* CAT_NAME[NUM_CATS] = { "DICE", "TABLE", "FELT", "TILES", "SPARKS" };

constexpr int     MAX_ITEMS = 6;            // shop shows at most this many cards per tab
constexpr int32_t MAX_COINS = 99999999;
constexpr int     START_COINS = 100;

// ------------------------------------------------------------------ catalogue
struct DiceSkin  { const char* name; int price; RGB body, pip; float spec, shin, metal; };
// tex: 0 = wood, 1 = lacquer (plain grain, takes any colour), 2 = stone / marble
struct TableSkin { const char* name; int price; int tex; RGB floor, board, rim, trim; };
struct FeltSkin  { const char* name; int price; RGB felt, arena; };
// open tiles keep their player colour; the skin changes the finish and the look of CLOSED tiles
struct TileSkin  { const char* name; int price; float spec, shin, metal;
                   int closedTex; RGB closed; float cSpec, cShin, cMetal; };
struct SparkSkin { const char* name; int price; RGB col; bool rainbow; };

inline constexpr DiceSkin kDice[] = {
    { "أزرق لامع",  0,   { 52,  94, 168}, {244, 242, 234}, 0.9f,  70.0f, 0.0f },
    { "ياقوت",        120, {172,  34,  52}, {250, 238, 224}, 0.9f,  80.0f, 0.0f },
    { "زمرد",     120, { 28, 132,  82}, {250, 244, 228}, 0.9f,  80.0f, 0.0f },
    { "عاجي",       200, {236, 230, 208}, { 30,  30,  34}, 0.6f,  40.0f, 0.0f },
    { "أسود وذهبي", 300, { 30,  30,  36}, {244, 198,  72}, 1.0f, 120.0f, 0.0f },
    { "ذهب ملكي",  500, {214, 170,  70}, { 70,  36,  20}, 1.0f, 120.0f, 0.8f },
};

inline constexpr TableSkin kTable[] = {
    { "بلوط كلاسيكي",   0,   0, {112,  86,  74}, {214, 160, 110}, {196, 140,  94}, {214, 170,  70} },
    { "جوز داكن",   150, 0, { 78,  58,  50}, {140, 100,  72}, {124,  88,  62}, {214, 170,  70} },
    { "بتولا",         200, 1, {140, 118,  94}, {190, 164, 124}, {176, 146, 106}, {190, 120,  70} },
    { "أبنوس",         250, 1, { 34,  30,  34}, { 64,  58,  62}, { 50,  45,  48}, {205, 210, 220} },
    { "أزرق منتصف الليل", 300, 1, { 24,  30,  56}, { 52,  78, 150}, { 38,  58, 114}, {205, 214, 238} },
    { "رخام",        400, 2, {120, 116, 112}, {226, 222, 214}, {200, 196, 188}, {214, 170,  70} },
};

inline constexpr FeltSkin kFelt[] = {
    { "أخضر",      0,   { 34, 118,  62}, { 26,  96,  50} },
    { "أزرق ملكي", 80,  { 36,  72, 156}, { 28,  56, 124} },
    { "عنابي",   80,  {138,  36,  52}, {108,  28,  40} },
    { "فيروزي",       120, { 24, 130, 130}, { 18, 102, 102} },
    { "بنفسجي",     160, {100,  54, 146}, { 78,  42, 116} },
    { "أسود",      200, { 40,  40,  48}, { 26,  26,  32} },
};

inline constexpr TileSkin kTiles[] = {
    { "كلاسيكي",      0,   1.0f,  70.0f, 0.0f,  0, {120,  84,  60}, 0.25f,  14.0f, 0.0f },
    { "مطفي",        100, 0.12f,  8.0f, 0.0f,  0, {100,  72,  52}, 0.10f,   6.0f, 0.0f },
    { "لامع",       150, 1.0f, 170.0f, 0.0f,  0, {120,  84,  60}, 0.50f,  40.0f, 0.0f },
    { "سبج",     250, 1.0f,  70.0f, 0.0f,  1, { 52,  54,  68}, 1.0f, 150.0f, 0.0f },
    { "معدني",     300, 1.0f, 120.0f, 0.7f,  1, { 84,  90, 106}, 0.9f, 100.0f, 0.8f },
    { "ذهبي", 400, 1.0f,  70.0f, 0.0f,  1, {214, 170,  70}, 1.0f,  60.0f, 1.0f },
};

inline constexpr SparkSkin kSpark[] = {
    { "ذهبي",    0,   {255, 205,  90}, false },
    { "جليدي",     80,  {130, 210, 255}, false },
    { "وردي",    80,  {255, 120, 200}, false },
    { "زمرد", 100, { 90, 255, 150}, false },
    { "قوس قزح", 250, {255, 255, 255}, true  },
};

template <typename T, size_t N> constexpr int Count(const T (&)[N]) { return (int)N; }

inline int ItemCount(int cat) {
    switch (cat) {
    case DICE:   return Count(kDice);
    case TABLE:  return Count(kTable);
    case FELT:   return Count(kFelt);
    case TILES:  return Count(kTiles);
    case SPARKS: return Count(kSpark);
    }
    return 0;
}
inline bool ValidItem(int cat, int i) { return cat >= 0 && cat < NUM_CATS && i >= 0 && i < ItemCount(cat); }

inline const char* ItemName(int cat, int i) {
    if (!ValidItem(cat, i)) return "";
    switch (cat) {
    case DICE:   return kDice[i].name;
    case TABLE:  return kTable[i].name;
    case FELT:   return kFelt[i].name;
    case TILES:  return kTiles[i].name;
    case SPARKS: return kSpark[i].name;
    }
    return "";
}
inline int ItemPrice(int cat, int i) {
    if (!ValidItem(cat, i)) return 0;
    switch (cat) {
    case DICE:   return kDice[i].price;
    case TABLE:  return kTable[i].price;
    case FELT:   return kFelt[i].price;
    case TILES:  return kTiles[i].price;
    case SPARKS: return kSpark[i].price;
    }
    return 0;
}
enum Rarity { COMMON = 0, UNCOMMON, RARE, EPIC, LEGENDARY };
inline const char* RarityName(int cat, int i) {
    const int p = ItemPrice(cat, i);
    if (p >= 450) return "أسطوري";
    if (p >= 280) return "ملحمي";
    if (p >= 150) return "نادر";
    if (p > 0) return "غير شائع";
    return "شائع";
}
inline Rarity ItemRarity(int cat, int i) {
    const int p = ItemPrice(cat, i);
    if (p >= 450) return LEGENDARY;
    if (p >= 280) return EPIC;
    if (p >= 150) return RARE;
    if (p > 0) return UNCOMMON;
    return COMMON;
}

// Two colours shown on the shop card (k = 0 or 1).
inline RGB ItemSwatch(int cat, int i, int k) {
    if (!ValidItem(cat, i)) return RGB{ 128, 128, 128 };
    switch (cat) {
    case DICE:   return k ? kDice[i].pip   : kDice[i].body;
    case TABLE:  return k ? kTable[i].trim : kTable[i].board;
    case FELT:   return k ? kFelt[i].arena : kFelt[i].felt;
    case TILES:  return k ? kTiles[i].closed : RGB{ 50, 110, 230 };      // open tile sample | closed tile
    case SPARKS:
        if (kSpark[i].rainbow) return k ? RGB{ 90, 150, 255 } : RGB{ 255, 90, 110 };
        return kSpark[i].col;
    }
    return RGB{ 128, 128, 128 };
}

// ------------------------------------------------------------------ save data
struct Save {
    int32_t  coins = START_COINS;
    uint32_t owned[NUM_CATS];        // bit i set = item i of that category is owned
    int32_t  equipped[NUM_CATS];
    int32_t  games = 0, wins = 0, tiles = 0, earned = 0;
    int32_t  lastDay = 0, streak = 0;
    int32_t  lastSpinMin = 0;        // wheel of fortune: minute (unix time / 60) of the last spin, 0 = never
    int32_t xp = 0, level = 1, winStreak = 0, bestStreak = 0;
    int32_t missionDay = 0, missionGames = 0, missionWins = 0, missionTiles = 0;
    int32_t achievements = 0, seasonPoints = 0;
    int32_t weeklyDay = 0, weeklyGames = 0, weeklyWins = 0, weeklyTiles = 0;
    int32_t dailyClaimed = 0, weeklyClaimed = 0;
    Save() { for (int c = 0; c < NUM_CATS; ++c) { owned[c] = 1u; equipped[c] = 0; } }
};

constexpr int     SAVE_INTS_V1 = 19;            // first release: no wheel
constexpr int     SAVE_INTS_V2 = 20;
constexpr int     SAVE_INTS_V3 = 30;
constexpr int     SAVE_INTS    = 36;            // daily/weekly challenges update
constexpr int32_t SAVE_MAGIC_V1 = 0x51423031;   // "QB01"
constexpr int32_t SAVE_MAGIC_V2 = 0x51423032;   // "QB02"
constexpr int32_t SAVE_MAGIC_V3 = 0x51423033;   // "QB03"
constexpr int32_t SAVE_MAGIC    = 0x51423034;   // "QB04"

inline int32_t Checksum(const int32_t* a, int n) {
    uint32_t h = 2166136261u;
    for (int i = 0; i < n; ++i) { h ^= (uint32_t)a[i]; h *= 16777619u; }
    return (int32_t)h;
}

inline void ToInts(const Save& s, int32_t* o) {
    int k = 0;
    o[k++] = SAVE_MAGIC;
    o[k++] = s.coins;
    for (int c = 0; c < NUM_CATS; ++c) o[k++] = (int32_t)s.owned[c];
    for (int c = 0; c < NUM_CATS; ++c) o[k++] = s.equipped[c];
    o[k++] = s.games; o[k++] = s.wins; o[k++] = s.tiles; o[k++] = s.earned;
    o[k++] = s.lastDay; o[k++] = s.streak;
    o[k++] = s.lastSpinMin;
    o[k++] = s.xp; o[k++] = s.level; o[k++] = s.winStreak; o[k++] = s.bestStreak;
    o[k++] = s.missionDay; o[k++] = s.missionGames; o[k++] = s.missionWins; o[k++] = s.missionTiles;
    o[k++] = s.achievements; o[k++] = s.seasonPoints;
    o[k++] = s.weeklyDay; o[k++] = s.weeklyGames; o[k++] = s.weeklyWins; o[k++] = s.weeklyTiles;
    o[k++] = s.dailyClaimed; o[k++] = s.weeklyClaimed;
    o[k] = Checksum(o, k);            // k == SAVE_INTS - 1 here
}

// `n` = how many ints were really read. Accepts the current layout and the first release's
// (so players keep their coins when the game updates). Returns false (and leaves `out`
// untouched) if the data is missing or damaged.
inline bool FromInts(const int32_t* a, Save& out, int n = SAVE_INTS) {
    if (n < 1) return false;
    const bool v4 = (a[0] == SAVE_MAGIC && n >= SAVE_INTS);
    const bool v3 = (a[0] == SAVE_MAGIC_V3 && n >= SAVE_INTS_V3);
    const bool v2 = (a[0] == SAVE_MAGIC_V2 && n >= SAVE_INTS_V2);
    const bool v1 = (a[0] == SAVE_MAGIC_V1 && n >= SAVE_INTS_V1);
    if (!v4 && !v3 && !v2 && !v1) return false;
    const int len = v4 ? SAVE_INTS : (v3 ? SAVE_INTS_V3 : (v2 ? SAVE_INTS_V2 : SAVE_INTS_V1));
    if (Checksum(a, len - 1) != a[len - 1]) return false;
    Save s;
    int k = 1;
    s.coins = std::max<int32_t>(0, std::min<int32_t>(a[k++], MAX_COINS));
    for (int c = 0; c < NUM_CATS; ++c) {
        const uint32_t all = (ItemCount(c) >= 32) ? 0xFFFFFFFFu : ((1u << ItemCount(c)) - 1u);
        s.owned[c] = ((uint32_t)a[k++] & all) | 1u;              // item 0 is always owned
    }
    for (int c = 0; c < NUM_CATS; ++c) {
        int e = a[k++];
        if (e < 0 || e >= ItemCount(c) || !(s.owned[c] & (1u << e))) e = 0;
        s.equipped[c] = e;
    }
    s.games   = std::max<int32_t>(0, a[k++]);
    s.wins    = std::max<int32_t>(0, a[k++]);
    s.tiles   = std::max<int32_t>(0, a[k++]);
    s.earned  = std::max<int32_t>(0, a[k++]);
    s.lastDay = std::max<int32_t>(0, a[k++]);
    s.streak  = std::max<int32_t>(0, a[k++]);
    s.lastSpinMin = (v2 || v3 || v4) ? std::max<int32_t>(0, a[k++]) : 0;
    if (v3 || v4) {
        s.xp = std::max<int32_t>(0, a[k++]); s.level = std::max<int32_t>(1, a[k++]);
        s.winStreak = std::max<int32_t>(0, a[k++]); s.bestStreak = std::max<int32_t>(0, a[k++]);
        s.missionDay = std::max<int32_t>(0, a[k++]); s.missionGames = std::max<int32_t>(0, a[k++]);
        s.missionWins = std::max<int32_t>(0, a[k++]); s.missionTiles = std::max<int32_t>(0, a[k++]);
        s.achievements = std::max<int32_t>(0, a[k++]); s.seasonPoints = std::max<int32_t>(0, a[k++]);
    }
    if (v4) {
        s.weeklyDay = std::max<int32_t>(0, a[k++]); s.weeklyGames = std::max<int32_t>(0, a[k++]);
        s.weeklyWins = std::max<int32_t>(0, a[k++]); s.weeklyTiles = std::max<int32_t>(0, a[k++]);
        s.dailyClaimed = std::max<int32_t>(0, a[k++]) & 7; s.weeklyClaimed = std::max<int32_t>(0, a[k++]) & 7;
    }
    out = s;
    return true;
}

// ------------------------------------------------------------------ wallet
inline void AddCoins(Save& s, int n) {
    if (n <= 0) return;
    s.coins  = (int32_t)std::min<int64_t>((int64_t)s.coins + n, MAX_COINS);
    s.earned = (int32_t)std::min<int64_t>((int64_t)s.earned + n, MAX_COINS);
}
inline bool Owned(const Save& s, int cat, int i) { return ValidItem(cat, i) && (s.owned[cat] & (1u << i)); }
inline bool Buy(Save& s, int cat, int i) {
    if (!ValidItem(cat, i) || Owned(s, cat, i)) return false;
    const int price = ItemPrice(cat, i);
    if (s.coins < price) return false;
    s.coins -= price;
    s.owned[cat] |= (1u << i);
    return true;
}
inline bool BuyAtPrice(Save& s, int cat, int i, int price) {
    if (!ValidItem(cat, i) || Owned(s, cat, i) || price < 0 || s.coins < price) return false;
    s.coins -= price;
    s.owned[cat] |= (1u << i);
    return true;
}
inline bool Equip(Save& s, int cat, int i) {
    if (!Owned(s, cat, i)) return false;
    s.equipped[cat] = i;
    return true;
}

// ------------------------------------------------------------------ rewards
inline int TileReward(int tilesClosed) { return 2 * std::max(0, tilesClosed); }
inline int FinishReward() { return 10; }                          // every finished match
inline int WinReward(bool vsComputer, int difficulty) {          // difficulty: 0 easy, 1 normal, 2 hard
    if (!vsComputer) return 30;
    return difficulty <= 0 ? 20 : (difficulty == 1 ? 40 : 70);
}

// ------------------------------------------------------------------ daily gift
// Days since 1970-01-01 for a calendar date (proleptic Gregorian).
inline int DaysFromCivil(int y, int m, int d) {
    y -= m <= 2;
    const int era = (y >= 0 ? y : y - 399) / 400;
    const unsigned yoe = (unsigned)(y - era * 400);
    const unsigned mp  = (unsigned)(m > 2 ? m - 3 : m + 9);
    const unsigned doy = (153 * mp + 2) / 5 + (unsigned)d - 1;
    const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + (int)doe - 719468;
}

struct Daily { bool granted = false; int bonus = 0; int streak = 0; };

// Call once at start-up with today's day number. Consecutive days raise the gift: 20, 30 ... 70.
inline Daily ClaimDaily(Save& s, int today) {
    Daily r;
    if (today <= s.lastDay) return r;                  // already claimed (or the clock went backwards)
    s.streak  = (s.lastDay > 0 && today == s.lastDay + 1) ? s.streak + 1 : 1;
    s.lastDay = today;
    r.granted = true;
    r.streak  = s.streak;
    r.bonus   = 20 + 10 * std::min(s.streak - 1, 5);
    AddCoins(s, r.bonus);
    return r;
}

// ------------------------------------------------------------------ wheel of fortune
// One free spin every 24 hours. Slices are laid out so big and small prizes alternate;
// `weight` is how likely a slice is (the picture shows all slices the same size).
struct WheelSlot { int prize; int weight; };
constexpr int WHEEL_SLOTS = 8;
inline constexpr WheelSlot kWheel[WHEEL_SLOTS] = {
    { 20, 22 }, { 150, 3 }, { 40, 16 }, { 75, 8 }, { 30, 20 }, { 100, 5 }, { 50, 13 }, { 300, 1 },
};
constexpr int64_t WHEEL_COOLDOWN_SEC = 24 * 60 * 60;

// r01 in [0,1) -> slice index, proportional to the weights.
inline int PickWheel(float r01) {
    int total = 0;
    for (const WheelSlot& w : kWheel) total += w.weight;
    int x = (int)(std::max(0.0f, std::min(r01, 0.999999f)) * (float)total);
    for (int i = 0; i < WHEEL_SLOTS; ++i) {
        if (x < kWheel[i].weight) return i;
        x -= kWheel[i].weight;
    }
    return WHEEL_SLOTS - 1;
}

// Seconds until the next spin (0 = ready now). A clock set backwards can never lock
// the wheel for more than 24 hours.
inline int64_t WheelSecondsLeft(const Save& s, int64_t nowSec) {
    if (s.lastSpinMin <= 0) return 0;
    const int64_t nowMin = nowSec / 60;
    const int64_t last = std::min<int64_t>(s.lastSpinMin, nowMin);
    const int64_t left = (last * 60 + WHEEL_COOLDOWN_SEC) - nowSec;
    return left > 0 ? left : 0;
}
inline bool WheelReady(const Save& s, int64_t nowSec) { return WheelSecondsLeft(s, nowSec) == 0; }

// Spins: picks the slice, pays the prize and starts the 24 h timer. Returns the slice, or -1 if not ready.
inline int SpinWheel(Save& s, int64_t nowSec, float r01) {
    if (!WheelReady(s, nowSec)) return -1;
    const int i = PickWheel(r01);
    AddCoins(s, kWheel[i].prize);
    s.lastSpinMin = (int32_t)(nowSec / 60);
    return i;
}

} // namespace eco
