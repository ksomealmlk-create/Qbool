// Q BOOL - 3D tile-closing dice board game (2-4 players), C++ + raylib.
// One roll per turn. Close the two dice tiles (e.g. 2 and 3) OR just their sum (5).
// When you can't move, your open tiles are your score. Lowest score wins!
#include "raylib.h"
#include "raymath.h"
#include "rlgl.h"

#include "audio.hpp"
#include "economy.hpp"
#include "fx.hpp"
#include "game_logic.hpp"
#include "gfx.hpp"
#include "storage.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <string>
#include <vector>
#if defined(__ANDROID__)
#include <jni.h>
#include <mutex>
#include <condition_variable>
#include <chrono>
// Online HTTP bridge. The Java worker thread (OnlineBridge.startWorker) calls INTO this library:
// nativeNextRequest() blocks until the game wants a URL, nativeSetResponse() hands the answer back.
// The game thread never calls Java, so there is no FindClass/AttachCurrentThread (that crashed).
// heap objects that are never destroyed: the Java worker may still be blocked on them at process exit
static std::mutex& g_netMu = *new std::mutex;
static std::condition_variable& g_netCv = *new std::condition_variable;
static std::string& g_netReq = *new std::string;
static std::string& g_netRes = *new std::string;
static int g_netReqId = 0, g_netResId = -1;
static bool g_netReqPending = false;
extern "C" JNIEXPORT jstring JNICALL Java_com_qbool_game_OnlineBridge_nativeNextRequest(JNIEnv* env, jclass) {
    std::string s;
    {
        std::unique_lock<std::mutex> lk(g_netMu);
        g_netCv.wait(lk, [] { return g_netReqPending; });
        g_netReqPending = false;
        s = std::to_string(g_netReqId) + "\t" + g_netReq;
    }
    return env->NewStringUTF(s.c_str());
}
extern "C" JNIEXPORT void JNICALL Java_com_qbool_game_OnlineBridge_nativeSetResponse(JNIEnv* env, jclass, jint id, jstring body) {
    std::string r = "{\"error\":\"network_error\"}";
    if (body) { const char* c = env->GetStringUTFChars(body, nullptr); if (c) { r = c; env->ReleaseStringUTFChars(body, c); } }
    { std::lock_guard<std::mutex> lk(g_netMu); g_netRes = r; g_netResId = (int)id; }
    g_netCv.notify_all();
}
#endif

#if defined(__EMSCRIPTEN__)
#include <emscripten/emscripten.h>
#endif

#if !defined(__EMSCRIPTEN__) && !defined(__ANDROID__)
#define QB_DESKTOP 1
#endif

namespace {

using gfx::gx;
using gfx::Clampf;
using gfx::PI_F;

// ------------------------------------------------------------ constants
const float HINGE_Y   = 0.47f;
const float HINGE_Z   = 6.2f;
const float TILE_STEP = 0.96f;     // 10 tiles * 0.96 = the same 9.6 board width the 12 thinner tiles had
const float OPEN_ANG  = 68.0f;
const float SEL_ANG   = 38.0f;

const Color SEAT_COL[4]  = { Color{50,110,230,255}, Color{225,55,55,255},
                             Color{45,175,85,255},  Color{240,200,40,255} };
const char* SEAT_NAME[4] = { "BLUE", "RED", "GREEN", "YELLOW" };
const Color GOLD_COL         = Color{255,210,70,255};
const Color BTN_ON       = Color{230,150,20,255};
const Color BTN_OFF      = Color{70,70,90,255};
const Color BTN_GO       = Color{40,160,70,255};

enum class State   { Menu, Online, WaitRoll, Rolling, Choose, Delay, GameOver };
enum class Overlay { None, Help, Settings, Pause, Shop, Wheel };

struct Game {
    State state = State::Menu;
    Overlay overlay = Overlay::None;
    Overlay overlayBack = Overlay::None;       // where "back" goes from Help / Settings

    // match options
    int numPlayers = 4;
    bool vsComputer = false;
    Difficulty diff = Difficulty::Normal;
    bool hints = true;
    bool quit = false;
    // Online room lobby
    int onlinePage = 0; // 0=menu, 1=lobby
    char onlineCode[6] = "";
    char onlineStatus[128] = "Create a room or enter a code";
    char onlinePid[40] = "";
    bool onlineBusy = false;
    bool onlineActive = false;
    int onlineYou = -1;
    int onlineVersion = -1;
    int onlineRollSeq = 0;
    int onlineMoveSeq = 0;
    float onlinePollTimer = 0.0f;
    bool onlineStarted = false;

    // match state
    int seats[4] = {0, 1, 2, 3};     // turn index -> seat
    Board boards[4];                 // indexed by SEAT
    float angle[4][NUM_TILES + 1] = {};
    int winner = -1;                 // turn index of the player who shut the box
    bool keepTurn = false;           // same player rolls again after a move
    int cur = 0;                     // current turn index

    // dice
    int d1 = 0, d2 = 0, rollTotal = 0;
    float rollT = 1.0f;
    int bounceMark = 3;
    Vector3 dieStart[2] = {}, dieEnd[2] = {};
    float dieYaw[2] = {0, 0};
    float dieSpin[2][2] = {};

    // choosing
    uint16_t selected = 0;
    uint16_t preview = 0;            // option under the mouse pointer
    std::vector<uint16_t> combos;
    int hintIdx = -1;
    float botTimer = 0.0f;
    int botStage = 0;

    float timer = 0.0f;
    char msg[96] = "";

    // camera / effects
    float camAngle = 0.0f;
    float camDiff = 0.0f;            // how far the camera still has to turn (radians)
    float shake = 0.0f;
    float celebrate = 0.0f;
    float celebrateTick = 0.0f;

    // coins / shop
    int earned = 0;                  // coins earned in the current match
    int shopCat = 0;                 // tab shown in the shop
    int shopSel[eco::NUM_CATS] = {}; // item selected (previewed) per tab
    bool shopDice = false;           // dice are on the table only to preview skins
    float toastT = 0.0f;             // daily-gift banner timer
    char toast[96] = "";

    // wheel of fortune (one free spin every 24 h)
    float wheelRot = 0.0f;           // degrees, clockwise on screen
    float wheelFrom = 0.0f, wheelTo = 0.0f, wheelT = 1.0f;
    bool  wheelSpinning = false;
    int   wheelPrize = -1;           // slice won by the last spin
    int   wheelMark = 0;             // last slice boundary that passed the pointer (for the ticking sound)
};

Game g;
Camera3D cam;
Vector2 g_mp = {0, 0};
bool g_tap = false;
Matrix g_lightVP = {};

eco::Save g_save;                    // wallet, owned + equipped items, stats
int g_prevCat = -1, g_prevIdx = 0;   // item being previewed in the shop (-1 = none)
Board g_shopSaved[4];                // boards hidden while the shop shows its preview tiles

Color RGBc(eco::RGB c, unsigned char a = 255) { return Color{ c.r, c.g, c.b, a }; }
int SkinIdx(int cat) { return g_prevCat == cat ? g_prevIdx : g_save.equipped[cat]; }
const eco::DiceSkin&  DiceSk()  { return eco::kDice [SkinIdx(eco::DICE)]; }
const eco::TableSkin& TableSk() { return eco::kTable[SkinIdx(eco::TABLE)]; }
const eco::FeltSkin&  FeltSk()  { return eco::kFelt [SkinIdx(eco::FELT)]; }
const eco::TileSkin&  TileSk()  { return eco::kTiles[SkinIdx(eco::TILES)]; }
const Texture2D& TableTex() {
    switch (TableSk().tex) { case 1: return gfx::gx.paint; case 2: return gfx::gx.stone; default: return gfx::gx.wood; }
}
Color SparkColor() {
    const eco::SparkSkin& k = eco::kSpark[SkinIdx(eco::SPARKS)];
    if (k.rainbow) return ColorFromHSV((float)GetRandomValue(0, 359), 0.65f, 1.0f);
    return RGBc(k.col);
}
void SaveNow() { storage::Store(g_save); }
void Award(int n) { if (n <= 0) return; eco::AddCoins(g_save, n); g.earned += n; }

int CurSeat() { return g.seats[g.cur]; }
bool IsBot(int turnIdx) { return g.vsComputer && turnIdx != 0; }
float UIScale() {
    float u = std::min(GetScreenWidth() / 960.0f, GetScreenHeight() / 540.0f);
    return std::max(0.55f, std::min(u, 2.2f));
}
float Rnd01() { return (float)GetRandomValue(0, 9999) / 10000.0f; }
void Beep(Sound& s, float vol = 1.0f, float pitch = 1.0f) { audio::Play(s, vol, pitch); }

// ------------------------------------------------------------ online client
const char* ONLINE_URL = "https://qbool-online.ksomealmlk.workers.dev";
#if defined(__ANDROID__)
std::string OnlineHttp(const std::string& url) {
    std::unique_lock<std::mutex> lk(g_netMu);
    const int id = ++g_netReqId;
    g_netReq = url; g_netReqPending = true; g_netResId = -1;
    g_netCv.notify_all();
    if (!g_netCv.wait_for(lk, std::chrono::milliseconds(4500), [&] { return g_netResId == id; }))
        return "{\"error\":\"timeout\"}";
    return g_netRes;
}
#else
std::string OnlineHttp(const std::string&) { return "{\"error\":\"online_requires_android\"}"; }
#endif
std::string UrlEncode(const std::string& in) { std::string o; for (unsigned char c: in) { if ((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_') o+=(char)c; else { char b[4]; std::snprintf(b,sizeof(b),"%%%02X",c); o+=b; } } return o; }
std::string JsonString(const std::string& j, const char* key) { std::string k = std::string("\"")+key+"\""; auto p=j.find(k); if(p==std::string::npos)return {}; p=j.find(':',p+k.size()); if(p==std::string::npos)return {}; p=j.find('"',p); if(p==std::string::npos)return {}; auto e=j.find('"',p+1); if(e==std::string::npos)return {}; return j.substr(p+1,e-p-1); }
int JsonInt(const std::string& j, const char* key, int fallback=-1) { std::string k=std::string("\"")+key+"\""; auto p=j.find(k); if(p==std::string::npos)return fallback; p=j.find(':',p+k.size()); if(p==std::string::npos)return fallback; ++p; while(p<j.size()&&(j[p]==' '||j[p]=='\t'))++p; try{return std::stoi(j.substr(p));}catch(...){return fallback;} }
std::vector<int> JsonIntArray(const std::string& j, const char* key) { std::vector<int> out; std::string k=std::string("\"")+key+"\""; auto p=j.find(k); if(p==std::string::npos)return out; p=j.find('[',p+k.size()); if(p==std::string::npos)return out; auto e=j.find(']',p); if(e==std::string::npos)return out; ++p; while(p<e){while(p<e&&(j[p]==' '||j[p]=='\t'||j[p]==','))++p; if(p>=e)break; try{size_t n=0; int v=std::stoi(j.substr(p,e-p),&n); out.push_back(v); p+=n;}catch(...){break;}} return out; }
void EnsureOnlinePid() { if (g.onlinePid[0]) return; std::snprintf(g.onlinePid,sizeof(g.onlinePid),"qb_%08X%04X",(unsigned)GetRandomValue(1,0x7fffffff),(unsigned)GetRandomValue(1,65535)); }
std::string OnlineEndpoint(const char* action, const std::string& extra="") { EnsureOnlinePid(); return std::string(ONLINE_URL)+"/"+action+"?pid="+g.onlinePid+"&code="+g.onlineCode+extra; }
void OnlineApplyState(const std::string& r) {
    if (r.find("\"error\"")!=std::string::npos) { auto err=JsonString(r,"error"); if(!err.empty()) std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),"Online: %s",err.c_str()); return; }
    const int you=JsonInt(r,"you",-1), ver=JsonInt(r,"v",-1), cur=JsonInt(r,"cur",0);
    if (you < 0) return;
    g.onlineYou=you; g.onlineVersion=ver; g.cur=std::max(0,cur); g.numPlayers=std::max(2,std::min(4,JsonInt(r,"n",2)));
    auto seats=JsonIntArray(r,"seats"); for(int i=0;i<g.numPlayers && i<(int)seats.size();++i) g.seats[i]=seats[i];
    auto opens=JsonIntArray(r,"open");
    for(int i=0;i<g.numPlayers && i<(int)opens.size();++i){ int seat=g.seats[i]; for(int t=1;t<=NUM_TILES;++t) g.boards[seat].open[t]=(opens[i]&(1<<t))!=0; }
    const int rollSeq=JsonInt(r,"rollSeq",g.onlineRollSeq), moveSeq=JsonInt(r,"moveSeq",g.onlineMoveSeq);
    const std::string phase=JsonString(r,"phase");
    auto dice=JsonIntArray(r,"dice");
    if(rollSeq>g.onlineRollSeq && dice.size()>=2){
        g.onlineRollSeq=rollSeq; g.d1=dice[0]; g.d2=dice[1]; g.rollTotal=g.d1+g.d2;
        if(phase=="choose") { g.rollT=0.0f; g.bounceMark=0;
        const int seat=CurSeat(); for(int i=0;i<2;++i){g.dieEnd[i]=Vector3{i==0?-0.95f:0.95f,0.765f,i==0?0.3f:-0.3f};g.dieStart[i]=Vector3{(i==0?-1.0f:1.0f)*8.0f,3.2f,(float)(seat==0?8.0f:-8.0f)};g.dieYaw[i]=(float)GetRandomValue(0,359);g.dieSpin[i][0]=700;g.dieSpin[i][1]=600;}
        g.state=State::Rolling; g.selected=0; g.preview=0; g.msg[0]=0;
        } else { g.state=State::WaitRoll; g.d1=g.d2=g.rollTotal=0; }
    }
    if(moveSeq>g.onlineMoveSeq) g.onlineMoveSeq=moveSeq;
    if(phase=="lobby") { g.onlineStarted=false; g.state=State::Online; g.onlinePage=1; std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),"Waiting for another player..."); }
    else if(phase=="roll") { g.onlineStarted=true; if(g.state!=State::Rolling && g.state!=State::Delay) {g.state=State::WaitRoll;g.d1=g.d2=g.rollTotal=0;g.combos.clear();} std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),you==cur?"Your turn - roll the dice":"Waiting for opponent..."); }
    else if(phase=="choose") { g.onlineStarted=true; if(g.state!=State::Rolling) {g.d1=dice.size()>0?dice[0]:0;g.d2=dice.size()>1?dice[1]:0;g.rollTotal=g.d1+g.d2;g.rollT=1.0f;g.combos.clear();for(int m:JsonIntArray(r,"options"))g.combos.push_back((uint16_t)m);g.state=State::Choose;} std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),you==cur?"Choose a move":"Opponent is choosing..."); }
    else if(phase=="over") { g.onlineStarted=true; g.winner=JsonInt(r,"winner",-1);g.state=State::GameOver;std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),g.winner==you?"You won!":"Match finished"); }
    g.onlinePollTimer=0.65f;
}
void OnlinePoll(bool force=false) { if(!g.onlineActive || g.onlineCode[0]==0 || g.onlineBusy)return; if(!force && g.onlinePollTimer>0)return; g.onlineBusy=true; auto r=OnlineHttp(OnlineEndpoint("state","&v="+std::to_string(g.onlineVersion))); if(r.find("\"same\":1")==std::string::npos)OnlineApplyState(r); else g.onlinePollTimer=0.65f; g.onlineBusy=false; }
void OnlineCreateRoom() { EnsureOnlinePid(); g.onlineBusy=true; std::string url=std::string(ONLINE_URL)+"/create?pid="+g.onlinePid+"&name=Player&n=2"; std::string r=OnlineHttp(url); g.onlineBusy=false; auto code=JsonString(r,"code"); if(code.size()==5){std::snprintf(g.onlineCode,sizeof(g.onlineCode),"%s",code.c_str());g.onlineActive=true;g.onlineVersion=-1;g.onlineRollSeq=0;g.onlineMoveSeq=0;g.onlinePage=1;OnlineApplyState(r);std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),"Room created - share code %s",g.onlineCode);} else {auto err=JsonString(r,"error");std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),"Server: %s",err.empty()?"invalid response":err.c_str());} }
void OnlineJoinRoom() { if(std::strlen(g.onlineCode)!=5){std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),"Enter the 5-letter room code");return;} EnsureOnlinePid();g.onlineBusy=true;std::string url=std::string(ONLINE_URL)+"/join?pid="+g.onlinePid+"&name=Player&code="+g.onlineCode;std::string r=OnlineHttp(url);g.onlineBusy=false;if(r.find("\"error\"")==std::string::npos){g.onlineActive=true;g.onlineVersion=-1;g.onlineRollSeq=0;g.onlineMoveSeq=0;g.onlinePage=1;OnlineApplyState(r);}else{auto err=JsonString(r,"error");std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),"Join failed: %s",err.c_str());} }
void OnlineRoll() { if(!g.onlineActive || g.onlineYou!=g.cur)return;g.onlineBusy=true;auto r=OnlineHttp(OnlineEndpoint("roll"));g.onlineBusy=false;if(r.find("\"error\"")!=std::string::npos){std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),"Roll: %s",JsonString(r,"error").c_str());return;}OnlineApplyState(r); }
bool OnlineMove(uint16_t mask) { if(!g.onlineActive || g.onlineYou!=g.cur)return false;g.onlineBusy=true;auto r=OnlineHttp(OnlineEndpoint("move","&mask="+std::to_string((int)mask)));g.onlineBusy=false;if(r.find("\"error\"")!=std::string::npos){std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),"Move: %s",JsonString(r,"error").c_str());return false;}OnlineApplyState(r);return true; }
void OnlineLeave() { if(g.onlineActive && g.onlineCode[0]) { g.onlineBusy=true; OnlineHttp(OnlineEndpoint("leave")); g.onlineBusy=false; } g.onlineActive=false; g.onlineCode[0]=0; g.onlinePage=0; g.onlineYou=-1; g.onlineVersion=-1; }

// ------------------------------------------------------------ game flow
void StartGame() {
    const int n = g.numPlayers;
    if (n == 2)      { g.seats[0] = 0; g.seats[1] = 2; }
    else             { for (int i = 0; i < n; ++i) g.seats[i] = i; }
    bool active[4] = {false, false, false, false};
    for (int i = 0; i < n; ++i) active[g.seats[i]] = true;
    for (int s = 0; s < 4; ++s) {
        g.boards[s].reset();
        if (!active[s]) g.boards[s].shutAll();
        for (int t = 0; t <= NUM_TILES; ++t) g.angle[s][t] = 0.0f;
    }
    g.cur = 0;
    g.winner = -1;
    g.keepTurn = false;
    g.selected = 0; g.preview = 0;
    g.rollT = 1.0f; g.bounceMark = 3;
    g.d1 = g.d2 = 0;
    g.rollTotal = 0;
    g.msg[0] = 0;
    g.celebrate = 0.0f;
    g.earned = 0;
    g.botTimer = 1.1f;
    g.state = State::WaitRoll;
}

void ToMenu() {
    OnlineLeave();
    for (int s = 0; s < 4; ++s) g.boards[s].reset();
    g.selected = 0; g.preview = 0;
    g.rollT = 1.0f; g.bounceMark = 3;
    g.d1 = g.d2 = 0;
    g.rollTotal = 0;
    g.cur = 0;
    g.winner = -1;
    g.msg[0] = 0;
    g.celebrate = 0.0f;
    g.overlay = Overlay::None;
    g.state = State::Menu;
}

Vector3 DicePos(int i, float t) {
    const float e = 1.0f - (1.0f - t) * (1.0f - t);
    Vector3 p;
    p.x = g.dieStart[i].x + (g.dieEnd[i].x - g.dieStart[i].x) * e;
    p.z = g.dieStart[i].z + (g.dieEnd[i].z - g.dieStart[i].z) * e;
    p.y = g.dieEnd[i].y + fabsf(sinf(t * PI_F * 3.0f)) * (1.0f - t) * 2.2f;
    return p;
}

void DiceImpact(float strength) {
    Beep(audio::bank.thud, 0.45f + 0.55f * strength, 0.85f + 0.3f * (1.0f - strength));
    g.shake = std::max(g.shake, 0.07f * strength);
    for (int i = 0; i < 2; ++i) {
        const Vector3 p = DicePos(i, g.rollT);
        fx::Puff(Vector3{ p.x, 0.52f, p.z }, 2 + (int)(4.0f * strength));
    }
}

void DoRoll() {
    const int seat = CurSeat();
    g.d1 = GetRandomValue(1, 6);
    g.d2 = GetRandomValue(1, 6);
    g.rollTotal = g.d1 + g.d2;
    g.rollT = 0.0f;
    g.bounceMark = 0;

    const float phi = seat * PI_F / 2.0f;
    const float sx = sinf(phi), sz = cosf(phi);
    for (int i = 0; i < 2; ++i) {
        float jx = GetRandomValue(-30, 30) / 100.0f;
        float jz = GetRandomValue(-30, 30) / 100.0f;
        g.dieEnd[i] = Vector3{ (i == 0 ? -0.95f : 0.95f) + jx, 0.765f,
                               (i == 0 ? 0.3f : -0.3f) + jz };
        g.dieStart[i] = Vector3{ sx * 8.0f + (i == 0 ? -0.8f : 0.8f) * sz, 3.2f,
                                 sz * 8.0f - (i == 0 ? -0.8f : 0.8f) * sx };
        g.dieYaw[i] = (float)GetRandomValue(0, 359);
        g.dieSpin[i][0] = (GetRandomValue(0, 1) ? 1.0f : -1.0f) * (700.0f + GetRandomValue(0, 400));
        g.dieSpin[i][1] = (GetRandomValue(0, 1) ? 1.0f : -1.0f) * (600.0f + GetRandomValue(0, 400));
    }
    g.selected = 0; g.preview = 0;
    g.msg[0] = 0;
    g.state = State::Rolling;
    Beep(audio::bank.rattle, 0.9f, 0.95f + 0.1f * Rnd01());
}

void EnterChoose() {
    const int seat = CurSeat();
    g.combos = findOptions(g.boards[seat], g.d1, g.d2);
    g.selected = 0; g.preview = 0;
    g.hintIdx = -1;
    if (g.combos.empty()) {
        std::snprintf(g.msg, sizeof(g.msg), "No move!  Next player");
        g.keepTurn = false;
        if (g.onlineActive) { g.state = State::WaitRoll; g.d1 = g.d2 = g.rollTotal = 0; g.onlinePollTimer = 0.0f; }
        else { g.state = State::Delay; g.timer = 1.8f; }
        Beep(audio::bank.sad);
    } else {
        if (g.hints && !IsBot(g.cur)) g.hintIdx = bestOptionIndex(g.boards[seat], g.combos);
        g.state = State::Choose;
        g.botTimer = 0.9f + 0.5f * Rnd01();
        g.botStage = 0;
    }
}

void EndTurn() {
    g.selected = 0; g.preview = 0;
    g.msg[0] = 0;
    g.d1 = g.d2 = 0;          // dice leave the table between rolls
    g.rollTotal = 0;
    g.rollT = 1.0f; g.bounceMark = 3;
    if (g.winner >= 0) {                       // somebody shut the box
        g.state = State::GameOver;
        g.celebrate = 5.0f;
        Beep(audio::bank.win);
        return;
    }
    if (!g.keepTurn) g.cur = (g.cur + 1) % g.numPlayers;
    g.keepTurn = false;
    g.state = State::WaitRoll;
    g.botTimer = 1.0f;
}

Vector3 TileCenter(int seat, int n, float angDeg) {
    const float lx = (n - (NUM_TILES + 1) * 0.5f) * TILE_STEP;
    const float th = angDeg * PI_F / 180.0f;
    const float ly = HINGE_Y + 0.6f * sinf(th) + 0.06f * cosf(th);
    const float lz = HINGE_Z - 0.6f * cosf(th) + 0.06f * sinf(th);
    const float phi = seat * PI_F / 2.0f;
    return Vector3{ lx * cosf(phi) + lz * sinf(phi), ly, -lx * sinf(phi) + lz * cosf(phi) };
}

void ConfirmSelection() {
    if (g.onlineActive) { if (!OnlineMove(g.selected)) return; g.selected = 0; g.preview = 0; g.state = State::WaitRoll; g.d1 = g.d2 = g.rollTotal = 0; return; }
    const int seat = CurSeat();
    int closedCount = 0;
    for (int n = 1; n <= NUM_TILES; ++n) {
        if (g.selected & (1u << n)) {
            const Vector3 c = TileCenter(seat, n, g.angle[seat][n]);
            fx::Sparks(c, 14, SparkColor());
            g.boards[seat].open[n] = false;
            Beep(audio::bank.clack, 0.8f, 0.9f + 0.25f * Rnd01());
            ++closedCount;
        }
    }
    if (!IsBot(g.cur) && closedCount > 0) {          // coins for every tile a human closes
        Award(eco::TileReward(closedCount));
        g_save.tiles += closedCount;
    }
    g.selected = 0; g.preview = 0;
    g.shake = std::max(g.shake, 0.03f);
    if (g.boards[seat].allShut()) {
        g.winner = g.cur;
        std::snprintf(g.msg, sizeof(g.msg), "SHUT THE BOX!  %s wins", SEAT_NAME[seat]);
        g.state = State::Delay;
        g.timer = 2.8f;
        g.celebrate = 3.0f;
        Beep(audio::bank.fanfare);
        ++g_save.games;                        // match finished: coins for playing and for winning
        Award(eco::FinishReward());
        if (!IsBot(g.cur)) { Award(eco::WinReward(g.vsComputer, (int)g.diff)); ++g_save.wins; }
    } else {
        g.msg[0] = 0;
        g.keepTurn = false;                    // turn passes to the next player
        g.state = State::Delay;
        g.timer = 1.0f;
    }
    if (!IsBot(g.cur) || g.winner >= 0) SaveNow();
}

// Returns the open tile (1..NUM_TILES) of `seat` nearest to the pointer, or 0.
int PickTile(int seat, Vector2 mp) {
    int best = 0;
    float bestD = 1e9f;
    const float phi = seat * PI_F / 2.0f;
    for (int n = 1; n <= NUM_TILES; ++n) {
        if (!g.boards[seat].open[n]) continue;
        Vector3 c = TileCenter(seat, n, g.angle[seat][n]);
        Vector2 s = GetWorldToScreen(c, cam);
        Vector3 r = Vector3{ c.x + 0.5f * cosf(phi), c.y, c.z - 0.5f * sinf(phi) };
        Vector2 s2 = GetWorldToScreen(r, cam);
        float halfW = hypotf(s2.x - s.x, s2.y - s.y);
        float d = hypotf(mp.x - s.x, mp.y - s.y);
        if (d < halfW * 1.25f && d < bestD) { bestD = d; best = n; }
    }
    return best;
}

Rectangle RollRect() {
    float u = UIScale();
    float w = 230 * u, h = 62 * u;
    return Rectangle{ GetScreenWidth() / 2.0f - w / 2, GetScreenHeight() - h - 24 * u, w, h };
}
Rectangle OptionRect(int i, int n) {
    float u = UIScale();
    float w = 250 * u, h = 58 * u, gap = 18 * u;
    float total = n * w + (n - 1) * gap;
    return Rectangle{ GetScreenWidth() / 2.0f - total / 2 + i * (w + gap),
                      GetScreenHeight() - h - 24 * u, w, h };
}
Rectangle PauseBtnRect() {
    float u = UIScale();
    return Rectangle{ 14 * u, 50 * u, 46 * u, 46 * u };
}

// ------------------------------------------------------------ update
void ReadInput() {
    static bool touchPrev = false;
    static double lastTap = -10.0;
    g_mp = GetMousePosition();
    bool touchNow = GetTouchPointCount() > 0;
    if (touchNow) g_mp = GetTouchPosition(0);
    g_tap = IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || (touchNow && !touchPrev);
    touchPrev = touchNow;
    double now = GetTime();
    if (g_tap) {
        if (now - lastTap < 0.30) g_tap = false;   // ignore duplicate touch+mouse events
        else { lastTap = now; Beep(audio::bank.click, 0.35f); }
    }
}

void UpdateCamera(float dt) {
    float target;
    if (g.state == State::Menu || g.state == State::GameOver) {
        g.camAngle += dt * 0.15f;
        target = g.camAngle;
    } else {
        target = CurSeat() * PI_F / 2.0f;
    }
    float diff = target - g.camAngle;
    while (diff > PI_F)  diff -= 2 * PI_F;
    while (diff < -PI_F) diff += 2 * PI_F;
    g.camDiff = diff;
    g.camAngle += diff * std::min(1.0f, dt * 3.5f);

    float aspect = (float)GetScreenWidth() / (float)GetScreenHeight();
    float k = aspect < 1.5f ? 1.5f / aspect : 1.0f;
    k = Clampf(k, 1.0f, 2.4f);
    const float R = 11.0f * k, H = 15.0f * k;
    const float t = (float)GetTime();
    g.shake = std::max(0.0f, g.shake - dt * 0.35f);
    cam.position = Vector3{ sinf(g.camAngle) * R + (Rnd01() - 0.5f) * g.shake * 2.0f,
                            H + sinf(t * 0.5f) * 0.10f + (Rnd01() - 0.5f) * g.shake * 2.0f,
                            cosf(g.camAngle) * R + (Rnd01() - 0.5f) * g.shake * 2.0f };
    cam.target = Vector3{ 0.0f, 0.0f, 0.0f };
    cam.up = Vector3{ 0.0f, 1.0f, 0.0f };
    cam.fovy = 45.0f;
    cam.projection = CAMERA_PERSPECTIVE;
}

void UpdateTiles(float dt) {
    for (int s = 0; s < 4; ++s) {
        for (int n = 1; n <= NUM_TILES; ++n) {
            float target = 0.0f;
            if (g.boards[s].open[n]) {
                target = OPEN_ANG;
                const bool playing = g.state != State::Menu && g.state != State::GameOver;
                if (playing && s == CurSeat() && ((g.selected | g.preview) & (1u << n))) target = SEL_ANG;
            }
            g.angle[s][n] += (target - g.angle[s][n]) * std::min(1.0f, dt * 9.0f);
        }
    }
}

void UpdateCelebration(float dt) {
    if (g.celebrate > 0.0f) {
        g.celebrate -= dt;
        g.celebrateTick -= dt;
        if (g.celebrateTick <= 0.0f) { fx::Confetti(10); g.celebrateTick = 0.05f; }
    }
}

// ------------------------------------------------------------ wheel flow
long long NowSec() { return (long long)std::time(nullptr); }
const float WHEEL_SEG = 360.0f / (float)eco::WHEEL_SLOTS;

void OpenWheel() { g.overlay = Overlay::Wheel; g.overlayBack = Overlay::None; }

void CloseWheel() {
    if (g.wheelSpinning) { g.wheelSpinning = false; g.wheelRot = fmodf(g.wheelTo, 360.0f); }   // the prize is already paid
    g.overlay = g.overlayBack;
}

void StartWheelSpin() {
    const int idx = eco::SpinWheel(g_save, NowSec(), Rnd01());       // pays + starts the 24 h timer
    if (idx < 0) return;
    SaveNow();                                                       // saved first: quitting mid-spin cannot be abused
    g.wheelPrize = idx;
    const float jitter = (Rnd01() - 0.5f) * WHEEL_SEG * 0.7f;        // lands inside the slice, never on its edge
    const float stopAt = 270.0f - ((float)idx + 0.5f) * WHEEL_SEG + jitter;   // pointer is at the top = 270 deg
    float base = fmodf(g.wheelRot, 360.0f);
    if (base < 0.0f) base += 360.0f;
    float delta = stopAt - base;
    while (delta < 0.0f) delta += 360.0f;
    g.wheelFrom = g.wheelRot;
    g.wheelTo = g.wheelRot + delta + 360.0f * (float)(5 + GetRandomValue(0, 2));
    g.wheelT = 0.0f;
    g.wheelSpinning = true;
    g.wheelMark = (int)floorf(g.wheelRot / WHEEL_SEG);
    Beep(audio::bank.rattle, 0.6f);
}

void UpdateWheel(float dt) {
    g.wheelT += dt / 5.0f;
    const float t = std::min(1.0f, g.wheelT);
    const float e = 1.0f - powf(1.0f - t, 3.0f);                     // fast start, slow stop
    g.wheelRot = g.wheelFrom + (g.wheelTo - g.wheelFrom) * e;
    const int mark = (int)floorf(g.wheelRot / WHEEL_SEG);
    if (mark != g.wheelMark) { g.wheelMark = mark; Beep(audio::bank.click, 0.4f, 1.4f); }
    if (t >= 1.0f) {
        g.wheelSpinning = false;
        g.wheelRot = fmodf(g.wheelTo, 360.0f);
        if (g.wheelPrize >= 0 && eco::kWheel[g.wheelPrize].prize >= 100) { Beep(audio::bank.fanfare); fx::Confetti(160); }
        else Beep(audio::bank.win, 0.8f);
    }
}

// ------------------------------------------------------------ shop flow
void ShopSetPreview(int cat, int idx) { g_prevCat = cat; g_prevIdx = idx; g.shopSel[cat] = idx; }

void OpenShop() {
    g.overlayBack = Overlay::None;
    g.overlay = Overlay::Shop;
    // show a few closed tiles on every side so the tile skins can be judged
    for (int s = 0; s < 4; ++s) {
        g_shopSaved[s] = g.boards[s];
        g.boards[s].reset();
        for (int n = 3; n <= NUM_TILES; n += 3) g.boards[s].open[n] = false;
    }
    // and two dice resting on the table for the dice skins
    g.shopDice = (g.d1 == 0);
    if (g.shopDice) {
        g.d1 = 3; g.d2 = 5; g.rollTotal = 8;
        g.rollT = 1.0f; g.bounceMark = 3;
        g.dieEnd[0]   = g.dieStart[0] = Vector3{ -0.95f, 0.765f,  0.30f };
        g.dieEnd[1]   = g.dieStart[1] = Vector3{  0.95f, 0.765f, -0.30f };
        g.dieYaw[0] = 25.0f; g.dieYaw[1] = -40.0f;
    }
    g.shopCat = 0;
    for (int c = 0; c < eco::NUM_CATS; ++c) g.shopSel[c] = g_save.equipped[c];
    ShopSetPreview(0, g.shopSel[0]);
}

void CloseShop() {
    g.overlay = g.overlayBack;
    g_prevCat = -1;
    for (int s = 0; s < 4; ++s) g.boards[s] = g_shopSaved[s];
    if (g.shopDice) { g.d1 = g.d2 = 0; g.rollTotal = 0; g.shopDice = false; }
}

void HandleBackKey() {
    const bool back = IsKeyPressed(KEY_ESCAPE) || IsKeyPressed(KEY_BACK);
    if (!back) return;
    if (g.overlay == Overlay::Pause) g.overlay = Overlay::None;
    else if (g.overlay == Overlay::Shop) CloseShop();
    else if (g.overlay == Overlay::Wheel) CloseWheel();
    else if (g.overlay == Overlay::Help || g.overlay == Overlay::Settings) g.overlay = g.overlayBack;
    else if (g.state == State::Menu) {
#if defined(QB_DESKTOP) || defined(__ANDROID__)
        g.quit = true;
#endif
    } else g.overlay = Overlay::Pause;
}

void Update(float dt) {
    if (g.toastT > 0.0f) g.toastT -= dt;
    if (g.wheelSpinning) UpdateWheel(dt);              // keeps turning while its panel is open
    ReadInput();
    audio::Update();
    fx::Update(dt);
    UpdateCamera(dt);
    UpdateTiles(dt);
    HandleBackKey();
#if defined(QB_DESKTOP)
    if (IsKeyPressed(KEY_F11)) ToggleFullscreen();
#endif
    if (g.overlay != Overlay::None) return;          // game is frozen behind menus
    UpdateCelebration(dt);
    if (g.onlineActive) { g.onlinePollTimer -= dt; if (g.state != State::Rolling && g.state != State::Delay) OnlinePoll(false); }

    const int seat = CurSeat();
    switch (g.state) {
    case State::Menu:
    case State::Online:
    case State::GameOver:
        break;

    case State::WaitRoll: {
        const bool camReady = fabsf(g.camDiff) < 0.12f;
        if (g.onlineActive) { if (g.onlineYou == g.cur && camReady && IsKeyPressed(KEY_SPACE)) OnlineRoll(); }
        else if (IsBot(g.cur)) {
            g.botTimer -= dt;
            if (g.botTimer <= 0.0f && camReady) DoRoll();
        } else if (camReady && IsKeyPressed(KEY_SPACE)) {
            DoRoll();
        }
        break;
    }

    case State::Rolling: {
        g.rollT += dt / 1.1f;
        if (g.rollT >= 1.0f) g.rollT = 1.0f;
        const int mk = std::min(3, (int)(g.rollT * 3.0f));
        while (g.bounceMark < mk) {                  // one impact per bounce
            ++g.bounceMark;
            DiceImpact(g.bounceMark == 1 ? 1.0f : (g.bounceMark == 2 ? 0.6f : 0.35f));
        }
        if (g.rollT >= 1.0f) EnterChoose();
        break;
    }

    case State::Choose:
        if (g.onlineActive && g.onlineYou != g.cur) { /* wait for remote player's move */ }
        else if (g.onlineActive) { /* local selection uses the normal board controls */ }
        else if (IsBot(g.cur)) {
            g.botTimer -= dt;
            if (g.botTimer <= 0.0f) {
                if (g.botStage == 0) {
                    g.selected = botPick(g.boards[seat], g.combos, g.diff, Rnd01());
                    g.botStage = 1;
                    g.botTimer = 0.8f;
                } else {
                    ConfirmSelection();
                }
            }
        } else {
            const int n = (int)g.combos.size();
            if (IsKeyPressed(KEY_ONE) && n >= 1)   { g.selected = g.combos[0]; ConfirmSelection(); break; }
            if (IsKeyPressed(KEY_TWO) && n >= 2)   { g.selected = g.combos[1]; ConfirmSelection(); break; }
            g.preview = 0;
#if !defined(__ANDROID__)
            {
                const int over = PickTile(seat, g_mp);
                if (over) for (uint16_t c : g.combos) if (c & (1u << over)) g.preview = c;
            }
#endif
            if (g_tap) {
                bool onButton = false;
                for (int i = 0; i < n; ++i)
                    if (CheckCollisionPointRec(g_mp, OptionRect(i, n))) onButton = true;
                if (!onButton) {
                    const int hit = PickTile(seat, g_mp);
                    if (hit) {
                        for (int i = 0; i < n; ++i) {
                            if (g.combos[i] & (1u << hit)) { g.selected = g.combos[i]; ConfirmSelection(); break; }
                        }
                    }
                }
            }
        }
        break;

    case State::Delay:
        g.timer -= dt;
        if (g.timer <= 0.0f) EndTurn();
        break;
    }
}

// ------------------------------------------------------------ drawing: 3D
// dice colours / finish come from the equipped (or previewed) dice skin

void DrawPipFace(int value) {   // pips on the +Y face of a die (local space)
    const float a = 0.15f, base = 0.263f;
    auto pip = [&](float x, float z) {
        rlPushMatrix();
        rlTranslatef(x, base, z);
        gfx::DrawLit(gx.pip, gx.paint, RGBc(DiceSk().pip), 0.25f, 16.0f);
        rlPopMatrix();
    };
    if (value == 1 || value == 3 || value == 5) pip(0, 0);
    if (value >= 2) { pip(-a, -a); pip(a, a); }
    if (value >= 4) { pip(-a, a); pip(a, -a); }
    if (value == 6) { pip(-a, 0); pip(a, 0); }
}

void DrawDie(int i) {
    if (g.d1 == 0) return;
    const float t = g.rollT;
    const Vector3 p = DicePos(i, t);
    const float spin = powf(1.0f - t, 1.5f);
    const float ax = spin * g.dieSpin[i][0];
    const float az = spin * g.dieSpin[i][1];

    const int v = (i == 0) ? g.d1 : g.d2;       // value on the top face
    int rest[4], rn = 0;
    for (int k = 1; k <= 6; ++k) if (k != v && k != 7 - v) rest[rn++] = k;
    const int fa = rest[0];
    const int fb = (rest[1] != 7 - fa) ? rest[1] : rest[2];
    // face index: 0 +Y, 1 -Y, 2 +X, 3 -X, 4 +Z, 5 -Z
    const int val[6] = { v, 7 - v, fa, 7 - fa, fb, 7 - fb };

    rlPushMatrix();
    rlTranslatef(p.x, p.y, p.z);
    rlRotatef(g.dieYaw[i], 0, 1, 0);
    rlRotatef(ax, 1, 0, 0);
    rlRotatef(az, 0, 0, 1);
    {
        const eco::DiceSkin& ds = DiceSk();
        gfx::DrawLit(gx.die, gx.stone, RGBc(ds.body), ds.spec, ds.shin, 1.0f, ds.metal);
    }
    if (!gx.shadowPass) {
        for (int f = 0; f < 6; ++f) {
            rlPushMatrix();
            if (f == 1)      rlRotatef(180, 1, 0, 0);
            else if (f == 2) rlRotatef(-90, 0, 0, 1);
            else if (f == 3) rlRotatef(90, 0, 0, 1);
            else if (f == 4) rlRotatef(90, 1, 0, 0);
            else if (f == 5) rlRotatef(-90, 1, 0, 0);
            DrawPipFace(val[f]);
            rlPopMatrix();
        }
    }
    rlPopMatrix();
}

void DrawDieShadow(int i, float strength) {
    if (g.d1 == 0) return;
    const Vector3 p = DicePos(i, g.rollT);
    const float h = p.y - 0.765f;
    const float k = 1.0f / (1.0f + h * 1.4f);
    gfx::DrawBlob(p.x + 0.10f, 0.4745f, p.z + 0.12f, 0.62f + h * 0.18f, 0.62f + h * 0.18f, 0.62f * k * strength);
}

Vector3 LightDirNow() {
    const float ca = cosf(g.camAngle), sa = sinf(g.camAngle);
    const float lx0 = -0.45f, lz0 = 0.55f;     // light follows the camera: key light front-left
    return Vector3Normalize(Vector3{ lx0 * ca + lz0 * sa, 1.0f, -lx0 * sa + lz0 * ca });
}

void DrawScene() {
    const bool sp = gx.shadowPass;
    const bool shadowsOn = gx.shadowOk && gfx::shadowsEnabled;

    if (!sp && gx.ok) {
        const Vector3 L = LightDirNow();
        float Lv[3] = { L.x, L.y, L.z };
        float V[3] = { cam.position.x, cam.position.y, cam.position.z };
        float on = shadowsOn ? 1.0f : 0.0f;
        float texel = 1.0f / (float)gx.shadowSize;
        SetShaderValue(gx.lit, gx.locLight, Lv, SHADER_UNIFORM_VEC3);
        SetShaderValue(gx.lit, gx.locView, V, SHADER_UNIFORM_VEC3);
        SetShaderValue(gx.lit, gx.locShadowOn, &on, SHADER_UNIFORM_FLOAT);
        SetShaderValue(gx.lit, gx.locTexel, &texel, SHADER_UNIFORM_FLOAT);
        SetShaderValueMatrix(gx.lit, gx.locLightVP, g_lightVP);
    }

    const eco::TableSkin& tk = TableSk();
    const eco::FeltSkin&  fk = FeltSk();
    const eco::TileSkin&  ts = TileSk();
    const Texture2D& tabTex = TableTex();
    const Color trim = RGBc(tk.trim);

    // table
    if (!sp) gfx::DrawLit(gx.plane, tabTex, RGBc(tk.floor), 0.15f, 14.0f, 14.0f);

    // wooden board
    rlPushMatrix(); rlTranslatef(0, 0.225f, 0);
    gfx::DrawLit(gx.board, tabTex, RGBc(tk.board), 0.45f, 32.0f);
    rlPopMatrix();
    const float rimY = 0.50f;
    const float zs[2] = { -6.7f, 6.7f };
    for (int k = 0; k < 2; ++k) {
        rlPushMatrix(); rlTranslatef(0, rimY, zs[k]);
        gfx::DrawLit(gx.rimLong, tabTex, RGBc(tk.rim), 0.5f, 36.0f);
        rlPopMatrix();
        rlPushMatrix(); rlTranslatef(zs[k], rimY, 0);
        gfx::DrawLit(gx.rimShort, tabTex, RGBc(tk.rim), 0.5f, 36.0f);
        rlPopMatrix();
    }
    // brass corner caps
    for (int a = 0; a < 2; ++a)
        for (int b = 0; b < 2; ++b) {
            rlPushMatrix(); rlTranslatef(zs[a], 0.55f, zs[b]);
            gfx::DrawLit(gx.cap, gx.paint, trim, 1.0f, 60.0f, 1.0f, 1.0f);
            rlPopMatrix();
        }

    if (!sp) {
        // brass inlay frame
        for (int k = 0; k < 2; ++k) {
            rlPushMatrix(); rlTranslatef(0, 0.468f, zs[k] * 0.96f);
            gfx::DrawLit(gx.inlayX, gx.paint, trim, 1.0f, 60.0f, 1.0f, 1.0f);
            rlPopMatrix();
            rlPushMatrix(); rlTranslatef(zs[k] * 0.96f, 0.468f, 0);
            gfx::DrawLit(gx.inlayZ, gx.paint, trim, 1.0f, 60.0f, 1.0f, 1.0f);
            rlPopMatrix();
        }
        // green felt in the middle + golden ring = the dice arena
        rlPushMatrix(); rlTranslatef(0, 0.445f, 0);
        gfx::DrawLit(gx.feltBox, gx.felt, RGBc(fk.felt), 0.04f, 6.0f);
        rlPopMatrix();
        rlPushMatrix(); rlTranslatef(0, 0.465f, 0);
        gfx::DrawLit(gx.discBig, gx.paint, trim, 1.0f, 60.0f, 1.0f, 1.0f);
        rlPopMatrix();
        rlPushMatrix(); rlTranslatef(0, 0.467f, 0);
        gfx::DrawLit(gx.discSmall, gx.felt, RGBc(fk.arena), 0.05f, 6.0f, 2.0f);
        rlPopMatrix();
    }

    const float pulse = 0.5f + 0.5f * sinf((float)GetTime() * 4.0f);
    const bool choosing = (g.state == State::Choose);
    uint16_t eligible = 0;
    if (choosing) for (uint16_t c : g.combos) eligible |= c;
    uint16_t hinted = 0;
    if (choosing && g.hintIdx >= 0 && g.hintIdx < (int)g.combos.size()) hinted = g.combos[(size_t)g.hintIdx];

    for (int s = 0; s < 4; ++s) {
        bool active = false;
        for (int i = 0; i < g.numPlayers; ++i) if (g.seats[i] == s) active = true;
        const bool playing = g.state != State::Menu && g.state != State::GameOver;
        const bool isCur = playing && s == CurSeat();
        Color c = ColorBrightness(SEAT_COL[s], active ? -0.20f : -0.65f);
        if (isCur) c = ColorBrightness(SEAT_COL[s], 0.10f + 0.20f * pulse);

        rlPushMatrix();
        rlRotatef(s * 90.0f, 0, 1, 0);

        if (!sp) {
            // coloured felt strip for this seat
            rlPushMatrix(); rlTranslatef(0, 0.45f, 5.6f);
            gfx::DrawLit(gx.strip, gx.felt, c, 0.05f, 6.0f);
            rlPopMatrix();
        }

        // brass hinge rod
        rlPushMatrix();
        rlTranslatef(-4.85f, HINGE_Y + 0.03f, HINGE_Z + 0.03f);
        rlRotatef(-90.0f, 0, 0, 1);
        gfx::DrawLit(gx.rod, gx.paint, trim, 1.0f, 60.0f, 1.0f, 1.0f);
        rlPopMatrix();

        for (int n = 1; n <= NUM_TILES; ++n) {
            const bool open = g.boards[s].open[n];
            const bool sel = playing && s == CurSeat() && ((g.selected | g.preview) & (1u << n));
            const bool elig = isCur && (eligible & (1u << n)) && !IsBot(g.cur);
            const bool hint = isCur && (hinted & (1u << n)) && !IsBot(g.cur);
            rlPushMatrix();
            rlTranslatef((n - (NUM_TILES + 1) * 0.5f) * TILE_STEP, HINGE_Y, HINGE_Z);
            rlRotatef(g.angle[s][n], 1, 0, 0);
            rlTranslatef(0.0f, 0.06f, -0.6f);
            if (open) {
                Color body = sel ? Color{ 255, 168, 40, 255 } : SEAT_COL[s];
                float gl = elig ? 0.10f + 0.16f * pulse : 0.0f;
                if (hint) gl += 0.10f + 0.12f * pulse;
                gfx::DrawLit(gx.tile, gx.paint, body, ts.spec, ts.shin, 1.0f, ts.metal, gl, gl * 0.85f, gl * 0.3f);
                if (!sp && g.angle[s][n] > 8.0f) gfx::DrawNumberQuad(n, sel ? 1 : 0);
            } else {
                gfx::DrawLit(gx.tile, ts.closedTex == 1 ? gx.paint : gx.wood, RGBc(ts.closed), ts.cSpec, ts.cShin, 1.0f, ts.cMetal);
                if (!sp && g.state != State::Menu && active) gfx::DrawNumberQuad(n, 2);
            }
            rlPopMatrix();
        }
        rlPopMatrix();
    }
    DrawDie(0);
    DrawDie(1);

    if (!sp) {
        // soft contact shadows (drawn last, without writing depth)
        const float k = (shadowsOn) ? 0.55f : 1.0f;
        rlDrawRenderBatchActive();
        rlDisableDepthMask();
        gfx::DrawBlob(0.2f, 0.03f, 0.3f, 10.5f, 10.5f, 0.55f);     // board on table
        DrawDieShadow(0, k);
        DrawDieShadow(1, k);
        rlDrawRenderBatchActive();
        rlEnableDepthMask();
    }
}

// Render the scene from the light into an RGBA-packed depth texture.
void RenderShadowMap() {
    Camera3D lc = {};
    const Vector3 L = LightDirNow();
    lc.position = Vector3Scale(L, 22.0f);
    lc.target = Vector3{ 0.0f, 0.0f, 0.0f };
    lc.up = Vector3{ 0.0f, 1.0f, 0.0f };
    lc.fovy = 22.0f;                                  // orthographic height in world units
    lc.projection = CAMERA_ORTHOGRAPHIC;

    BeginTextureMode(gx.shadowRT);
    ClearBackground(WHITE);                           // 1.0 = "infinitely far"
    rlSetClipPlanes(4.0, 44.0);
    BeginMode3D(lc);
    g_lightVP = MatrixMultiply(rlGetMatrixModelview(), rlGetMatrixProjection());
    rlDrawRenderBatchActive();
    rlDisableColorBlend();                            // the alpha channel carries depth bits
    gx.shadowPass = true;
    DrawScene();
    gx.shadowPass = false;
    rlDrawRenderBatchActive();
    rlEnableColorBlend();
    EndMode3D();
    EndTextureMode();
}

// ------------------------------------------------------------ drawing: 2D
void Txt(const char* s, float x, float y, float size, Color c) {
    const float o = std::max(1.0f, size / 16.0f);
    DrawTextEx(gx.font, s, Vector2{ x + o, y + o }, size, size * 0.02f, Fade(BLACK, 0.65f));
    DrawTextEx(gx.font, s, Vector2{ x, y }, size, size * 0.02f, c);
}
float TxtW(const char* s, float size) { return MeasureTextEx(gx.font, s, size, size * 0.02f).x; }
void TxtC(const char* s, float cx, float y, float size, Color c) { Txt(s, cx - TxtW(s, size) / 2.0f, y, size, c); }

bool Btn(Rectangle r, const char* label, Color col, float fontSize, bool enabled = true) {
    const bool hover = enabled && CheckCollisionPointRec(g_mp, r);
    if (!enabled) col = ColorBrightness(col, -0.5f);
    DrawRectangleRounded(Rectangle{r.x + 3, r.y + 5, r.width, r.height}, 0.3f, 8, Fade(BLACK, 0.4f));
    DrawRectangleRounded(r, 0.3f, 8, hover ? ColorBrightness(col, 0.2f) : col);
    DrawRectangleRounded(Rectangle{r.x + 2, r.y + 2, r.width - 4, r.height * 0.48f}, 0.5f, 8, Fade(WHITE, 0.13f));
    TxtC(label, r.x + r.width / 2, r.y + (r.height - fontSize) / 2 - fontSize * 0.08f, fontSize, enabled ? WHITE : Color{160,160,160,255});
    if (enabled && g_tap && hover) { g_tap = false; return true; }
    return false;
}

void DrawCoinIcon(float x, float y, float r) {        // centre x, y
    DrawCircle((int)x, (int)y, r, Color{ 150, 100, 10, 255 });
    DrawCircle((int)x, (int)y, r * 0.86f, Color{ 255, 205, 60, 255 });
    DrawCircle((int)x, (int)y, r * 0.60f, Color{ 236, 172, 32, 255 });
    DrawCircle((int)(x - r * 0.28f), (int)(y - r * 0.30f), r * 0.16f, Fade(WHITE, 0.6f));
}

void DrawCoinBadge(float rightX, float y, float u, int coins) {
    char b[24];
    std::snprintf(b, sizeof(b), "%d", coins);
    const float fs = 26 * u, h = 40 * u;
    const float w = TxtW(b, fs) + 64 * u;
    const Rectangle r{ rightX - w, y, w, h };
    DrawRectangleRounded(r, 0.5f, 10, Fade(BLACK, 0.6f));
    DrawCoinIcon(r.x + 22 * u, r.y + h / 2, 14 * u);
    Txt(b, r.x + 46 * u, r.y + (h - fs) / 2 - fs * 0.08f, fs, GOLD_COL);
}

void DrawVignette() {
    DrawTexturePro(gx.vignette, Rectangle{ 0, 0, (float)gx.vignette.width, (float)gx.vignette.height },
                   Rectangle{ 0, 0, (float)GetScreenWidth(), (float)GetScreenHeight() },
                   Vector2{ 0, 0 }, 0.0f, WHITE);
}

void DrawMenu() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    const float cx = W / 2;
    DrawRectangle(0, 0, (int)W, (int)H, Fade(BLACK, 0.42f));

    TxtC("Q BOOL", cx, 10 * u, 78 * u, GOLD_COL);
    TxtC("3D dice & tiles board game", cx, 96 * u, 22 * u, WHITE);
    DrawCoinBadge(W - 12 * u, 10 * u, u, g_save.coins);
    {                                                        // wheel of fortune: glows when a free spin is waiting
        const long long now = NowSec();
        const bool ready = eco::WheelReady(g_save, now);
        char lb[40];
        if (ready) std::snprintf(lb, sizeof(lb), "FREE SPIN!");
        else {
            const long long left = eco::WheelSecondsLeft(g_save, now);
            std::snprintf(lb, sizeof(lb), "WHEEL %02d:%02d:%02d", (int)(left / 3600), (int)(left / 60 % 60), (int)(left % 60));
        }
        const float pulse = 0.5f + 0.5f * sinf((float)GetTime() * 5.0f);
        const Color col = ready ? ColorBrightness(Color{ 215, 120, 20, 255 }, 0.18f * pulse) : Color{ 70, 70, 104, 255 };
        if (Btn(Rectangle{ 12 * u, 10 * u, 214 * u, 42 * u }, lb, col, 20 * u)) OpenWheel();
    }

    auto label = [&](const char* s, float y) { Txt(s, cx - 340 * u, y + 11 * u, 24 * u, Color{235,235,235,255}); };
    const float bh = 48 * u;
    float y = 142 * u;

    label("Players", y);
    for (int i = 0; i < 3; ++i) {
        const int n = i + 2;
        char b[4]; std::snprintf(b, sizeof(b), "%d", n);
        if (Btn(Rectangle{ cx - 90 * u + i * 112 * u, y, 100 * u, bh }, b, g.numPlayers == n ? BTN_ON : BTN_OFF, 28 * u))
            g.numPlayers = n;
    }
    y += 62 * u;

    label("Mode", y);
    if (Btn(Rectangle{ cx - 90 * u,  y, 168 * u, bh }, "Pass & Play", !g.vsComputer ? BTN_ON : BTN_OFF, 20 * u)) g.vsComputer = false;
    if (Btn(Rectangle{ cx + 88 * u,  y, 168 * u, bh }, "vs Computer", g.vsComputer ? BTN_ON : BTN_OFF, 20 * u)) g.vsComputer = true;
    y += 62 * u;

    label("Computer", y);
    static const char* DN[3] = { "Easy", "Normal", "Hard" };
    for (int i = 0; i < 3; ++i) {
        const bool sel = (int)g.diff == i;
        if (Btn(Rectangle{ cx - 90 * u + i * 112 * u, y, 100 * u, bh }, DN[i], sel ? BTN_ON : BTN_OFF, 20 * u, g.vsComputer))
            g.diff = (Difficulty)i;
    }
    y += 62 * u;

    y += 8 * u;
    if (Btn(Rectangle{ cx - 130 * u, y, 260 * u, 48 * u }, "ONLINE", Color{35,125,190,255}, 28 * u)) { g.state = State::Online; g.onlinePage = 0; std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),"Create a room or enter a code"); }
    y += 54 * u;
    if (Btn(Rectangle{ cx - 130 * u, y, 260 * u, 64 * u }, "START", BTN_GO, 36 * u) || IsKeyPressed(KEY_ENTER)) StartGame();
    y += 78 * u;

#if defined(QB_DESKTOP)
    const int nb = 4;
#else
    const int nb = 3;
#endif
    const float bw = 170 * u, gap = 14 * u;
    float bx = cx - (nb * bw + (nb - 1) * gap) / 2;
    if (Btn(Rectangle{ bx, y, bw, 44 * u }, "HOW TO PLAY", Color{60,90,140,255}, 18 * u)) { g.overlay = Overlay::Help; g.overlayBack = Overlay::None; }
    bx += bw + gap;
    if (Btn(Rectangle{ bx, y, bw, 44 * u }, "SETTINGS", Color{60,90,140,255}, 18 * u)) { g.overlay = Overlay::Settings; g.overlayBack = Overlay::None; }
    bx += bw + gap;
    if (Btn(Rectangle{ bx, y, bw, 44 * u }, "SHOP", Color{200,135,20,255}, 18 * u)) OpenShop();
    if (g.toastT > 0.0f) {                                   // daily gift banner
        const float a = std::min(1.0f, g.toastT);
        const float fs = 22 * u, w = TxtW(g.toast, fs) + 50 * u, h = 40 * u, ty = y + 56 * u;
        DrawRectangleRounded(Rectangle{ cx - w / 2, ty, w, h }, 0.5f, 8, Fade(Color{ 20, 100, 55, 255 }, 0.92f * a));
        TxtC(g.toast, cx, ty + (h - fs) / 2 - fs * 0.08f, fs, Fade(WHITE, a));
    }
#if defined(QB_DESKTOP)
    bx += bw + gap;
    if (Btn(Rectangle{ bx, y, bw, 44 * u }, "QUIT", Color{150,50,50,255}, 18 * u)) g.quit = true;
#endif
}

void DrawOnline() {
    const float u=UIScale(), W=(float)GetScreenWidth(), H=(float)GetScreenHeight(), cx=W/2;
    DrawRectangle(0,0,(int)W,(int)H,Color{18,22,31,245});
    TxtC("ONLINE MULTIPLAYER",cx,42*u,34*u,GOLD_COL);
    TxtC("Server: qbool-online",cx,86*u,18*u,Color{170,205,225,255});
    if (g.onlinePage==0) {
        TxtC("Create a room or join your friend",cx,140*u,22*u,WHITE);
        if (Btn(Rectangle{cx-180*u,190*u,360*u,58*u},"CREATE ROOM",Color{35,145,85,255},26*u)) { std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),"Connecting..."); OnlineCreateRoom(); }
        TxtC("ROOM CODE",cx,258*u,18*u,Color{220,220,220,255});
        DrawRectangleRounded(Rectangle{cx-120*u,278*u,240*u,43*u},0.15f,8,Color{45,50,65,255});
        TxtC(g.onlineCode,cx,284*u,26*u,GOLD_COL);
        int ch; while ((ch=GetCharPressed())>0) { if(ch>='a'&&ch<='z')ch-=32; if((((ch>='A'&&ch<='Z')&&ch!='I'&&ch!='O')||(ch>='2'&&ch<='9'))&&std::strlen(g.onlineCode)<5){size_t n=std::strlen(g.onlineCode);g.onlineCode[n]=(char)ch;g.onlineCode[n+1]=0;} }
        if (IsKeyPressed(KEY_BACKSPACE) && g.onlineCode[0]) g.onlineCode[std::strlen(g.onlineCode)-1]=0;
        const char* keys="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        const float kw=31*u, kh=30*u, gap=3*u, total=16*kw+15*gap, kx=cx-total/2;
        for(int i=0;i<32;++i){ int row=i/16,col=i%16; Rectangle kr={kx+col*(kw+gap),326*u+row*(kh+3*u),kw,kh}; char label[2]={keys[i],0}; if(Btn(kr,label,Color{48,62,80,255},15*u) && std::strlen(g.onlineCode)<5){size_t n=std::strlen(g.onlineCode);g.onlineCode[n]=keys[i];g.onlineCode[n+1]=0;} }
        if (Btn(Rectangle{cx+total/2+5*u,326*u,45*u,kh},"DEL",Color{130,65,55,255},13*u) && g.onlineCode[0]) g.onlineCode[std::strlen(g.onlineCode)-1]=0;
        if (Btn(Rectangle{cx-180*u,397*u,360*u,48*u},"JOIN ROOM",Color{45,105,185,255},24*u)) OnlineJoinRoom();
    } else {
        TxtC("ROOM CODE",cx,150*u,20*u,WHITE); TxtC(g.onlineCode,cx,190*u,56*u,GOLD_COL);
        TxtC(g.onlineStarted?"Match connected":"Waiting for players to join...",cx,270*u,20*u,WHITE);
        TxtC("Keep this screen open while your friend joins",cx,305*u,16*u,Color{180,190,205,255});
        if (Btn(Rectangle{cx-150*u,340*u,300*u,54*u},"LEAVE ROOM",Color{130,65,55,255},22*u)) { OnlineLeave(); g.state=State::Online; g.onlinePage=0; std::snprintf(g.onlineStatus,sizeof(g.onlineStatus),"You left the room"); }
    }
    TxtC(g.onlineStatus,cx,H-85*u,18*u,Color{230,210,150,255});
    if (Btn(Rectangle{cx-100*u,H-55*u,200*u,40*u},"BACK",Color{140,60,55,255},20*u)) {OnlineLeave();g.state=State::Menu;}
}

void DrawHUD() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth();
    const float H = (float)GetScreenHeight();
    const int seat = CurSeat();

    Txt("Q BOOL", 14 * u, 8 * u, 30 * u, GOLD_COL);
    if (Btn(PauseBtnRect(), "II", Color{40,40,55,255}, 22 * u)) g.overlay = Overlay::Pause;

    // scoreboard (top-right)
    const float bw = 200.0f * u;
    float bx = W - bw - 6 * u, by = 10 * u;
    DrawRectangleRounded(Rectangle{bx - 8 * u, by - 4 * u, bw, (g.numPlayers * 28 + 12) * u}, 0.15f, 6, Fade(BLACK, 0.5f));
    for (int i = 0; i < g.numPlayers; ++i) {
        const int s = g.seats[i];
        DrawRectangle((int)bx, (int)(by + (i * 28 + 4) * u), (int)(16 * u), (int)(16 * u), SEAT_COL[s]);
        char line[64];
        std::snprintf(line, sizeof(line), "%s: %d left", SEAT_NAME[s], g.boards[s].openCount());
        const bool isCur = (i == g.cur);
        Txt(line, bx + 24 * u, by + (i * 28 + 3) * u, 16 * u, isCur ? Color{255,230,120,255} : WHITE);
    }

    // turn banner
    char t[64];
    std::snprintf(t, sizeof(t), "%s's turn%s", SEAT_NAME[seat], IsBot(g.cur) ? " (CPU)" : "");
    TxtC(t, W / 2, 10 * u, 28 * u, SEAT_COL[seat].r > 200 && SEAT_COL[seat].g > 180 ? SEAT_COL[seat] : ColorBrightness(SEAT_COL[seat], 0.35f));

    // roll info
    if (g.rollTotal > 0 && g.rollT >= 1.0f) {
        char r[64];
        std::snprintf(r, sizeof(r), "Roll: %d + %d = %d", g.d1, g.d2, g.rollTotal);
        TxtC(r, W / 2, 50 * u, 26 * u, WHITE);
    }

    if (g.state == State::WaitRoll && (!g.onlineActive || g.onlineYou == g.cur) && !IsBot(g.cur) && fabsf(g.camDiff) < 0.12f) {
        if (Btn(RollRect(), "ROLL", Color{220,120,20,255}, 34 * u)) { if(g.onlineActive) OnlineRoll(); else DoRoll(); }
    }
    if (g.state == State::Choose && (!g.onlineActive || g.onlineYou == g.cur) && !IsBot(g.cur)) {
        const int n = (int)g.combos.size();
        TxtC("Choose one", W / 2, H - 112 * u, 22 * u, Color{255,235,150,255});
        int picked = -1;
        for (int i = 0; i < n; ++i) {
            char lab[40];
            int a1 = 0, a2 = 0;
            for (int tt = 1; tt <= NUM_TILES; ++tt) if (g.combos[i] & (1u << tt)) { if (!a1) a1 = tt; else a2 = tt; }
            const char* star = (i == g.hintIdx) ? "\xE2\x98\x85 " : "";
            if (a2) std::snprintf(lab, sizeof(lab), "%sClose %d + %d", star, a1, a2);
            else    std::snprintf(lab, sizeof(lab), "%sClose %d", star, a1);
            if (Btn(OptionRect(i, n), lab, i == 0 ? Color{40,140,200,255} : Color{200,120,30,255}, 26 * u))
                picked = i;
        }
        if (picked >= 0) { g.selected = g.combos[(size_t)picked]; ConfirmSelection(); }
    }
    if (g.state == State::Delay && g.msg[0]) {
        const float fs = 40 * u;
        const float w = TxtW(g.msg, fs) + 60 * u;
        DrawRectangleRounded(Rectangle{W / 2 - w / 2, H / 2 - 44 * u, w, 88 * u}, 0.3f, 8, Fade(BLACK, 0.68f));
        TxtC(g.msg, W / 2, H / 2 - fs / 2.0f - 2 * u, fs, Color{255,225,110,255});
    }
#if defined(__EMSCRIPTEN__)
    if (H > W) TxtC("Tip: rotate your phone sideways", W / 2, H - 28 * u, 16 * u, Fade(WHITE, 0.8f));
#endif
}

void DrawGameOver() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    const float cx = W / 2;
    DrawRectangle(0, 0, (int)W, (int)H, Fade(BLACK, 0.5f));

    const int wseat = g.winner >= 0 ? g.seats[g.winner] : 0;
    char title[64];
    std::snprintf(title, sizeof(title), "%s WINS!", SEAT_NAME[wseat]);
    TxtC("SHUT THE BOX!", cx, H * 0.16f, 44 * u, GOLD_COL);
    TxtC(title, cx, H * 0.16f + 62 * u, 70 * u, SEAT_COL[wseat].r > 200 && SEAT_COL[wseat].g > 180 ? SEAT_COL[wseat] : ColorBrightness(SEAT_COL[wseat], 0.35f));

    char cb[64];
    std::snprintf(cb, sizeof(cb), "+%d coins earned", g.earned);
    TxtC(cb, cx, H * 0.16f + 140 * u, 28 * u, GOLD_COL);
    DrawCoinBadge(W - 12 * u, 10 * u, u, g_save.coins);

    const float y = H * 0.16f + 190 * u;
    if (Btn(Rectangle{ cx - 275 * u, y, 260 * u, 62 * u }, "PLAY AGAIN", BTN_GO, 30 * u) || IsKeyPressed(KEY_ENTER)) StartGame();
    if (Btn(Rectangle{ cx + 15 * u,  y, 260 * u, 62 * u }, "MENU", Color{70,70,110,255}, 30 * u)) ToMenu();
    if (Btn(Rectangle{ cx - 130 * u, y + 76 * u, 260 * u, 52 * u }, "SHOP", Color{200,135,20,255}, 26 * u)) OpenShop();
}

void Panel(float u, float w, float h, const char* title) {
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    DrawRectangle(0, 0, (int)W, (int)H, Fade(BLACK, 0.68f));
    Rectangle r{ W / 2 - w * u / 2, H / 2 - h * u / 2, w * u, h * u };
    DrawRectangleRounded(Rectangle{ r.x + 5, r.y + 8, r.width, r.height }, 0.05f, 10, Fade(BLACK, 0.5f));
    DrawRectangleRounded(r, 0.05f, 10, Color{34,28,26,250});
    DrawRectangleRounded(Rectangle{ r.x + 3 * u, r.y + 3 * u, r.width - 6 * u, r.height - 6 * u }, 0.05f, 10, Color{48,40,36,255});
    TxtC(title, W / 2, r.y + 14 * u, 40 * u, GOLD_COL);
}

void DrawHelp() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    Panel(u, 860, 470, "HOW TO PLAY");
    static const char* LINES[] = {
        "1. Roll the two dice (ROLL button or SPACE).",
        "2. Close BOTH dice tiles (e.g. 2 and 4) OR only their sum (6).",
        "3. A closed tile stays closed. If one dice tile is already",
        "    closed you can close the other one alone, or the sum.",
        "4. One roll per turn: after your move (or if you have no",
        "    legal move) the turn passes to the next player.",
        "5. Closed tiles stay closed. Tiles are 1-10 (sums 11, 12 are lost).",
        "6. The first player to close ALL 10 tiles wins!",
        "",
        "Tap a tile or a button to choose.",
        "Keys: SPACE roll | 1 / 2 choose | ESC pause | F11 fullscreen",
        "A gold star marks the best move when Hints are ON.",
    };
    float fs = 19 * u;
    float maxw = 0.0f;
    for (const char* l : LINES) maxw = std::max(maxw, TxtW(l, fs));
    if (maxw > 800 * u) fs *= 800 * u / maxw;
    float y = H / 2 - 470 * u / 2 + 74 * u;
    for (const char* l : LINES) { Txt(l, W / 2 - 400 * u, y, fs, Color{235,235,235,255}); y += fs * 1.42f; }
    if (Btn(Rectangle{ W / 2 - 100 * u, H / 2 + 470 * u / 2 - 66 * u, 200 * u, 52 * u }, "BACK", BTN_GO, 26 * u)) g.overlay = g.overlayBack;
}

bool Toggle(Rectangle r, const char* name, bool on) {
    char b[64];
    std::snprintf(b, sizeof(b), "%s:  %s", name, on ? "ON" : "OFF");
    return Btn(r, b, on ? Color{40,130,70,255} : Color{110,60,60,255}, 24 * UIScale());
}

void DrawSettings() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    Panel(u, 560, 470, "SETTINGS");
    float y = H / 2 - 470 * u / 2 + 74 * u;
    const float x = W / 2 - 220 * u, w = 440 * u, h = 50 * u, step = 60 * u;
    if (Toggle(Rectangle{ x, y, w, h }, "Sound effects", audio::bank.sfxOn)) audio::bank.sfxOn = !audio::bank.sfxOn;
    y += step;
    if (Toggle(Rectangle{ x, y, w, h }, "Music", audio::bank.musicOn)) audio::bank.musicOn = !audio::bank.musicOn;
    y += step;
    if (Toggle(Rectangle{ x, y, w, h }, "Shadows", gfx::shadowsEnabled && gx.shadowOk)) { if (gx.shadowOk) gfx::shadowsEnabled = !gfx::shadowsEnabled; }
    y += step;
    if (Toggle(Rectangle{ x, y, w, h }, "Hints (best move)", g.hints)) g.hints = !g.hints;
    y += step;
#if defined(QB_DESKTOP)
    if (Toggle(Rectangle{ x, y, w, h }, "Fullscreen", IsWindowFullscreen())) ToggleFullscreen();
#endif
    if (Btn(Rectangle{ W / 2 - 100 * u, H / 2 + 470 * u / 2 - 66 * u, 200 * u, 52 * u }, "BACK", BTN_GO, 26 * u)) g.overlay = g.overlayBack;
}

void DrawPause() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    Panel(u, 460, 460, "PAUSED");
    float y = H / 2 - 460 * u / 2 + 74 * u;
    const float x = W / 2 - 170 * u, w = 340 * u, h = 52 * u, step = 62 * u;
    if (Btn(Rectangle{ x, y, w, h }, "RESUME", BTN_GO, 26 * u)) g.overlay = Overlay::None;
    y += step;
    if (Btn(Rectangle{ x, y, w, h }, "RESTART", Color{200,120,30,255}, 24 * u)) { g.overlay = Overlay::None; StartGame(); }
    y += step;
    if (Btn(Rectangle{ x, y, w, h }, "SETTINGS", Color{60,90,140,255}, 24 * u)) { g.overlay = Overlay::Settings; g.overlayBack = Overlay::Pause; }
    y += step;
    if (Btn(Rectangle{ x, y, w, h }, "HOW TO PLAY", Color{60,90,140,255}, 24 * u)) { g.overlay = Overlay::Help; g.overlayBack = Overlay::Pause; }
    y += step;
    if (Btn(Rectangle{ x, y, w, h }, "MAIN MENU", Color{150,50,50,255}, 24 * u)) ToMenu();
}

void DrawWheel() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    Panel(u, 560, 520, "LUCKY WHEEL");
    const long long now = NowSec();
    const bool ready = eco::WheelReady(g_save, now);
    const float cx = W / 2, cy = H / 2, R = 130 * u;
    const int N = eco::WHEEL_SLOTS;

    // coins shown without the prize that is still spinning (no spoilers)
    const int pending = (g.wheelSpinning && g.wheelPrize >= 0) ? eco::kWheel[g.wheelPrize].prize : 0;
    DrawCoinBadge(W - 12 * u, 10 * u, u, g_save.coins - pending);

    // result line
    char line[64];
    if (g.wheelSpinning)                  std::snprintf(line, sizeof(line), "Good luck!");
    else if (g.wheelPrize >= 0 && !ready) std::snprintf(line, sizeof(line), "You won +%d coins!", eco::kWheel[g.wheelPrize].prize);
    else if (ready)                       std::snprintf(line, sizeof(line), "Your free spin is ready");
    else                                  std::snprintf(line, sizeof(line), "Come back tomorrow");
    TxtC(line, cx, H / 2 - 198 * u, 28 * u, (g.wheelPrize >= 0 && !g.wheelSpinning && !ready) ? Color{ 120, 235, 140, 255 } : WHITE);

    // wheel
    static const Color SLICE[8] = {
        { 196, 56, 56, 255 }, { 44, 112, 196, 255 }, { 210, 132, 24, 255 }, { 44, 150, 84, 255 },
        { 130, 70, 170, 255 }, { 26, 136, 140, 255 }, { 200, 70, 130, 255 }, { 150, 120, 30, 255 } };
    DrawCircle((int)cx, (int)cy, R + 12 * u, Color{ 90, 60, 14, 255 });
    DrawCircle((int)cx, (int)cy, R + 8 * u, GOLD_COL);
    for (int i = 0; i < N; ++i)
        DrawCircleSector(Vector2{ cx, cy }, R, g.wheelRot + i * WHEEL_SEG, g.wheelRot + (i + 1) * WHEEL_SEG, 24, SLICE[i % 8]);
    for (int i = 0; i < N; ++i) {
        const float a = (g.wheelRot + ((float)i + 0.5f) * WHEEL_SEG) * DEG2RAD;
        char pb[12];
        std::snprintf(pb, sizeof(pb), "%d", eco::kWheel[i].prize);
        const float fs = (eco::kWheel[i].prize >= 100 ? 26 : 22) * u;
        TxtC(pb, cx + cosf(a) * R * 0.66f, cy + sinf(a) * R * 0.66f - fs * 0.5f, fs, WHITE);
    }
    DrawCircle((int)cx, (int)cy, 20 * u, Color{ 90, 60, 14, 255 });
    DrawCircle((int)cx, (int)cy, 15 * u, GOLD_COL);
    // pointer (both windings so it shows whatever the culling mode)
    const Vector2 tip{ cx, cy - R + 16 * u }, pl{ cx - 15 * u, cy - R - 18 * u }, pr{ cx + 15 * u, cy - R - 18 * u };
    DrawTriangle(tip, pr, pl, Color{ 235, 50, 50, 255 });
    DrawTriangle(tip, pl, pr, Color{ 235, 50, 50, 255 });

    // buttons
    const float by = H / 2 + 190 * u, bw = 250 * u, bh = 52 * u;
    char sb[40];
    if (g.wheelSpinning)  std::snprintf(sb, sizeof(sb), "SPINNING...");
    else if (ready)       std::snprintf(sb, sizeof(sb), "SPIN");
    else {
        const long long left = eco::WheelSecondsLeft(g_save, now);
        std::snprintf(sb, sizeof(sb), "%02d:%02d:%02d", (int)(left / 3600), (int)(left / 60 % 60), (int)(left % 60));
    }
    if (Btn(Rectangle{ cx - bw - 10 * u, by, bw, bh }, sb, BTN_GO, 28 * u, ready && !g.wheelSpinning)) StartWheelSpin();
    if (Btn(Rectangle{ cx + 10 * u, by, bw, bh }, "BACK", Color{ 150, 50, 50, 255 }, 28 * u)) CloseWheel();
}

void DrawShop() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    const int cat = g.shopCat;
    const int n = eco::ItemCount(cat);

    // top bar: back, title, coins
    DrawRectangleGradientV(0, 0, (int)W, (int)(72 * u), Fade(BLACK, 0.7f), Fade(BLACK, 0.0f));
    TxtC("SHOP", W / 2, 8 * u, 40 * u, GOLD_COL);
    DrawCoinBadge(W - 12 * u, 12 * u, u, g_save.coins);
    if (Btn(Rectangle{ 12 * u, 12 * u, 110 * u, 42 * u }, "BACK", Color{150,50,50,255}, 22 * u)) { CloseShop(); return; }

    // bottom panel
    const float ph = 236 * u, py = H - ph;
    DrawRectangle(0, (int)py, (int)W, (int)ph, Fade(Color{ 20, 16, 14, 255 }, 0.94f));
    DrawRectangle(0, (int)py, (int)W, (int)(3 * u), GOLD_COL);

    // category tabs
    const float tw = 168 * u, tg = 8 * u;
    const float tx = W / 2 - (eco::NUM_CATS * tw + (eco::NUM_CATS - 1) * tg) / 2;
    for (int c = 0; c < eco::NUM_CATS; ++c) {
        if (Btn(Rectangle{ tx + c * (tw + tg), py + 12 * u, tw, 40 * u }, eco::CAT_NAME[c], c == cat ? BTN_ON : BTN_OFF, 20 * u) && c != cat) {
            g.shopCat = c;                                    // cards below switch on the next frame
            ShopSetPreview(c, g_save.equipped[c]);
        }
    }

    // item cards
    const float cw = 138 * u, cg = 8 * u, ch = 104 * u;
    const float cx0 = W / 2 - (n * cw + (n - 1) * cg) / 2;
    const float cy = py + 62 * u;
    for (int i = 0; i < n; ++i) {
        const Rectangle r{ cx0 + i * (cw + cg), cy, cw, ch };
        const bool owned = eco::Owned(g_save, cat, i);
        const bool equipped = g_save.equipped[cat] == i;
        const bool sel = g.shopSel[cat] == i;
        const bool hover = CheckCollisionPointRec(g_mp, r);
        if (sel) DrawRectangleRounded(Rectangle{ r.x - 3 * u, r.y - 3 * u, r.width + 6 * u, r.height + 6 * u }, 0.14f, 8, GOLD_COL);
        DrawRectangleRounded(r, 0.12f, 8, hover ? Color{ 74, 62, 56, 255 } : Color{ 52, 44, 40, 255 });

        const float sw = (cw - 20 * u) / 2;
        DrawRectangleRounded(Rectangle{ r.x + 10 * u, r.y + 8 * u, sw - 2 * u, 40 * u }, 0.3f, 6, RGBc(eco::ItemSwatch(cat, i, 0)));
        DrawRectangleRounded(Rectangle{ r.x + 10 * u + sw + 2 * u, r.y + 8 * u, sw - 2 * u, 40 * u }, 0.3f, 6, RGBc(eco::ItemSwatch(cat, i, 1)));

        const char* nm = eco::ItemName(cat, i);
        float fs = 16 * u;
        if (TxtW(nm, fs) > cw - 12 * u) fs *= (cw - 12 * u) / TxtW(nm, fs);
        TxtC(nm, r.x + cw / 2, r.y + 54 * u, fs, WHITE);

        const float ly = r.y + 78 * u;
        if (equipped)      TxtC("EQUIPPED", r.x + cw / 2, ly, 15 * u, Color{ 110, 230, 130, 255 });
        else if (owned)    TxtC("OWNED", r.x + cw / 2, ly, 15 * u, Color{ 190, 190, 190, 255 });
        else {
            char pb[16];
            std::snprintf(pb, sizeof(pb), "%d", eco::ItemPrice(cat, i));
            const float pw = TxtW(pb, 16 * u);
            const float start = r.x + (cw - (22 * u + pw)) / 2;
            DrawCoinIcon(start + 8 * u, ly + 9 * u, 8 * u);
            Txt(pb, start + 22 * u, ly, 16 * u, g_save.coins >= eco::ItemPrice(cat, i) ? GOLD_COL : Color{ 220, 120, 120, 255 });
        }
        if (g_tap && hover) {
            g_tap = false;
            ShopSetPreview(cat, i);
            if (cat == eco::SPARKS) fx::Sparks(Vector3{ 0.0f, 1.0f, 0.0f }, 40, SparkColor());
        }
    }

    // buy / equip button
    const int sel = g.shopSel[cat];
    const bool owned = eco::Owned(g_save, cat, sel);
    const bool equipped = g_save.equipped[cat] == sel;
    const Rectangle ab{ W / 2 - 150 * u, H - 64 * u, 300 * u, 50 * u };
    if (owned) {
        if (Btn(ab, equipped ? "EQUIPPED" : "EQUIP", equipped ? BTN_OFF : BTN_GO, 26 * u, !equipped)) {
            eco::Equip(g_save, cat, sel);
            SaveNow();
            Beep(audio::bank.clack);
        }
    } else {
        const int price = eco::ItemPrice(cat, sel);
        const bool can = g_save.coins >= price;
        char bl[48];
        if (can) std::snprintf(bl, sizeof(bl), "BUY  -  %d", price);
        else     std::snprintf(bl, sizeof(bl), "NEED %d MORE", price - g_save.coins);
        if (Btn(ab, bl, BTN_ON, 26 * u, can) && eco::Buy(g_save, cat, sel)) {
            eco::Equip(g_save, cat, sel);
            SaveNow();
            Beep(audio::bank.fanfare, 0.7f);
            fx::Sparks(Vector3{ 0.0f, 1.0f, 0.0f }, 60, Color{ 255, 215, 90, 255 });
        }
    }
    char st[64];
    std::snprintf(st, sizeof(st), "Games %d   Wins %d", g_save.games, g_save.wins);
    Txt(st, 14 * u, H - 50 * u, 16 * u, Color{ 200, 195, 185, 255 });
}

void Draw() {
    BeginDrawing();
    if (gx.shadowOk && gfx::shadowsEnabled) RenderShadowMap();
    ClearBackground(Color{22,17,15,255});
    rlSetClipPlanes(1.0, 120.0);
    BeginMode3D(cam);
    DrawScene();
    fx::Draw(cam, gx.glow);
    EndMode3D();
    DrawVignette();

    const bool tap = g_tap;
    if (g.overlay != Overlay::None) g_tap = false;       // base UI is inert behind menus
    if (g.overlay == Overlay::Shop)       { /* the shop replaces the menu */ }
    else if (g.state == State::Menu)      DrawMenu();
    else if (g.state == State::Online)    DrawOnline();
    else if (g.state == State::GameOver) DrawGameOver();
    else                                  DrawHUD();
    g_tap = tap;

    switch (g.overlay) {
    case Overlay::Help:     DrawHelp(); break;
    case Overlay::Settings: DrawSettings(); break;
    case Overlay::Pause:    DrawPause(); break;
    case Overlay::Shop:     DrawShop(); break;
    case Overlay::Wheel:    DrawWheel(); break;
    case Overlay::None:     break;
    }
    EndDrawing();
}

void Frame() {
    float dt = GetFrameTime();
    if (dt > 0.05f) dt = 0.05f;
    Update(dt);
    Draw();
}

} // namespace

int main() {
    int w = 1280, h = 720;
#if defined(__EMSCRIPTEN__)
    w = EM_ASM_INT({ return window.innerWidth; });
    h = EM_ASM_INT({ return window.innerHeight; });
#endif
#if defined(__ANDROID__)
    w = 0; h = 0;   // 0,0 = use the whole phone/tablet screen
#endif
    SetConfigFlags(FLAG_MSAA_4X_HINT | FLAG_WINDOW_RESIZABLE | FLAG_VSYNC_HINT);
    InitWindow(w, h, "Q BOOL");
    SetExitKey(KEY_NULL);            // ESC / Back opens the pause menu instead of quitting
    SetTargetFPS(60);
    SetRandomSeed((unsigned int)std::time(nullptr));

    // first frame while the textures are being generated
    BeginDrawing();
    ClearBackground(Color{28,22,20,255});
    DrawText("Q BOOL", GetScreenWidth() / 2 - MeasureText("Q BOOL", 60) / 2, GetScreenHeight() / 2 - 50, 60, Color{255,210,70,255});
    DrawText("loading...", GetScreenWidth() / 2 - MeasureText("loading...", 24) / 2, GetScreenHeight() / 2 + 20, 24, WHITE);
    EndDrawing();

    audio::Init();
    gfx::InitGraphics();
    fx::SeedMotes();

    storage::Load(g_save);                                   // first run: keeps the defaults
    {
        const std::time_t now = std::time(nullptr);
        const std::tm* lt = std::localtime(&now);
        if (lt) {
            const int today = eco::DaysFromCivil(lt->tm_year + 1900, lt->tm_mon + 1, lt->tm_mday);
            const eco::Daily d = eco::ClaimDaily(g_save, today);
            if (d.granted) {
                std::snprintf(g.toast, sizeof(g.toast), "Daily gift  +%d coins   (day %d streak)", d.bonus, d.streak);
                g.toastT = 7.0f;
            }
        }
        SaveNow();
    }

    g.numPlayers = 4;
    for (int s = 0; s < 4; ++s)
        for (int n = 0; n <= NUM_TILES; ++n) g.angle[s][n] = g.boards[s].open[n] ? OPEN_ANG : 0.0f;
    cam.up = Vector3{0, 1, 0};
    g_lightVP = MatrixIdentity();

#if defined(__EMSCRIPTEN__)
    emscripten_set_main_loop(Frame, 0, 1);
#else
    while (!WindowShouldClose() && !g.quit) Frame();
#endif
    audio::Shutdown();
    CloseWindow();
    return 0;
}
