package com.qbool.game;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;

/** HTTP bridge for the native game. Networking runs off the Android UI thread. */
public final class OnlineBridge {
    private OnlineBridge() {}

    public static String get(final String address) {
        FutureTask<String> task = new FutureTask<>(() -> request(address));
        Thread worker = new Thread(task, "qbool-online-http");
        worker.setDaemon(true);
        worker.start();
        try {
            return task.get(3500, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            task.cancel(true);
            return "{\"error\":\"network_error\"}";
        }
    }

    private static String request(String address) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(1800);
            connection.setReadTimeout(1800);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/json");
            int status = connection.getResponseCode();
            InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            if (stream == null) return "{\"error\":\"http_error\"}";
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) result.append(line);
            reader.close();
            return result.toString();
        } catch (Exception e) {
            return "{\"error\":\"network_error\"}";
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
