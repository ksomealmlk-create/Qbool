package com.qbool.game;

import android.app.NativeActivity;

/** Loads the native library through Android's Java loader first, so JNI_OnLoad
 * receives and caches the process JavaVM before NativeActivity starts it. */
public final class QBoolActivity extends NativeActivity {
    static {
        System.loadLibrary("main");
    }
}
