package com.qbool.game;

import android.util.Log;

import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public final class FirebaseHelper {
    private static final String TAG = "QBoolFirebase";
    private FirebaseHelper() {}

    /** Saves a player's score into the "scores" collection. Never crashes the game. */
    public static void saveScore(String playerName, int score) {
        try {
            Map<String, Object> data = new HashMap<>();
            data.put("name", playerName);
            data.put("score", score);
            data.put("time", FieldValue.serverTimestamp());

            FirebaseFirestore.getInstance()
                    .collection("scores")
                    .add(data)
                    .addOnSuccessListener(ref -> Log.d(TAG, "Saved: " + ref.getId()))
                    .addOnFailureListener(e -> Log.e(TAG, "Failed", e));
        } catch (Throwable t) {
            Log.e(TAG, "Firebase not ready", t);
        }
    }
}
