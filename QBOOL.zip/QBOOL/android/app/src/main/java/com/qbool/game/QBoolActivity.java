package com.qbool.game;

import android.app.NativeActivity;
import android.os.Bundle;

/** Loads the native library through Android's Java loader first, then starts the HTTP worker. */
public final class QBoolActivity extends NativeActivity {
    static {
        System.loadLibrary("main");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        OnlineBridge.startWorker();

        // اختبار الربط مع Firebase (احذفه بعد التأكد)
        FirebaseHelper.saveScore("test", 1);
    }
}
