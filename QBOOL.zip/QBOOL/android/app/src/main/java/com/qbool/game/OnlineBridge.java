package com.qbool.game;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** HTTP worker for the native game. It runs on its own Java thread and talks to C++ only through
 *  the two native methods below (Java -> C++), so the game thread never calls into Java. */
public final class OnlineBridge {
    private OnlineBridge() {}

    private static native String nativeNextRequest();              // "id<TAB>url", blocks until needed
    private static native void nativeSetResponse(int id, String body);

    private static boolean started = false;

    public static synchronized void startWorker() {
        if (started) return;
        started = true;
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                while (true) {
                    String req;
                    try { req = nativeNextRequest(); } catch (Throwable e) { return; }
                    if (req == null) return;
                    int tab = req.indexOf('\t');
                    if (tab < 0) continue;
                    int id;
                    try { id = Integer.parseInt(req.substring(0, tab)); } catch (Exception e) { continue; }
                    String res;
                    try { res = request(req.substring(tab + 1)); }
                    catch (Throwable e) { res = "{\"error\":\"network_error\"}"; }
                    try { nativeSetResponse(id, res); } catch (Throwable e) { return; }
                }
            }
        }, "qbool-online-http");
        t.setDaemon(true);
        t.start();
    }

    private static String request(String address) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(address).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(3000);
            connection.setReadTimeout(3000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Connection", "keep-alive");
            int status = connection.getResponseCode();
            InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            if (stream == null) return "{\"error\":\"http_error\"}";
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) result.append(line);
            reader.close();
            return result.toString();
        } catch (Exception e) {
            return "{\"error\":\"network_error\"}";
        }
    }
}
