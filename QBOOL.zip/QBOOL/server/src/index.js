// Q BOOL online server (Cloudflare Worker).
// Every endpoint works with GET or POST and answers HTTP 200 with JSON ({"error": "..."} on failure),
// which keeps the game client (C++ / JNI / emscripten_fetch) very simple.
import { Room } from './room.js';
export { Room };

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET, POST, OPTIONS',
  'access-control-allow-headers': '*',
  'cache-control': 'no-store',
  'content-type': 'application/json',
};
const json = (o) => new Response(JSON.stringify(o), { headers: CORS });

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';     // 32 symbols, no I / O / 0 / 1
const CODE_RE = /^[A-HJ-NP-Z2-9]{5}$/;

function newCode() {
  const b = new Uint8Array(5);
  crypto.getRandomValues(b);
  return Array.from(b, x => ALPHABET[x & 31]).join('');
}

const ACTIONS = ['join', 'state', 'roll', 'move', 'leave'];

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const url = new URL(request.url);
    const act = url.pathname.replace(/^\/+/, '');

    if (act === '' || act === 'ping') return json({ ok: 1, service: 'qbool-online' });

    const forward = async (code) => {
      url.searchParams.set('code', code);
      const stub = env.ROOMS.get(env.ROOMS.idFromName(code));
      const res = await stub.fetch(url.toString());
      return new Response(await res.text(), { headers: CORS });
    };

    if (act === 'create') {
      for (let i = 0; i < 6; i++) {                    // pick a free code
        const code = newCode();
        const res = await forward(code);
        const body = await res.clone().json();
        if (body.error !== 'exists') return res;
      }
      return json({ error: 'busy' });
    }

    if (ACTIONS.includes(act)) {
      const code = (url.searchParams.get('code') || '').toUpperCase();
      if (!CODE_RE.test(code)) return json({ error: 'bad_code' });
      return forward(code);
    }

    return json({ error: 'not_found' });
  },
};
