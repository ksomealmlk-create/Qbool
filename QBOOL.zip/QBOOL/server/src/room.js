// One Durable Object = one room. All moves are checked here, so a modified client cannot cheat.
import { newGame, addPlayer, roll, move, leave, view } from './game.js';

const AWAY_MS = 12000;             // no poll for this long = player shown as "away"
const KEEP_MS = 3 * 3600 * 1000;   // an idle room is deleted after 3 hours

const PID_RE = /^[A-Za-z0-9_-]{8,64}$/;

function die() {                   // fair 1..6 (rejection sampling, no modulo bias)
  const b = new Uint8Array(1);
  do { crypto.getRandomValues(b); } while (b[0] >= 252);
  return (b[0] % 6) + 1;
}

function cleanName(s, fallback) {
  const t = String(s || '').replace(/[^\p{L}\p{N} _-]/gu, '').trim().slice(0, 12);
  return t || fallback;
}

export class Room {
  constructor(ctx, env) {
    this.ctx = ctx;
    this.g = null;
    this.seen = {};                // pid -> last request time (memory only)
    // On Cloudflare no request is delivered until this finishes (tests await `ready` themselves).
    this.ready = ctx.blockConcurrencyWhile(async () => { this.g = (await ctx.storage.get('g')) || null; });
  }

  away() {
    const now = Date.now();
    return this.g.players.map(p => now - (this.seen[p.pid] || 0) > AWAY_MS);
  }

  async save() {
    await this.ctx.storage.put('g', this.g);
    await this.ctx.storage.setAlarm(Date.now() + KEEP_MS);
  }

  async alarm() {
    await this.ctx.storage.deleteAll();
    this.g = null; this.seen = {};
  }

  reply(pid) { return { ...view(this.g, pid, this.away()) }; }

  async handle(act, q) {
    const pid = q.get('pid') || '';
    if (!PID_RE.test(pid)) return { error: 'bad_request' };
    const code = (q.get('code') || '').toUpperCase();

    if (act === 'create') {
      if (this.g) return { error: 'exists' };
      const n = Math.min(4, Math.max(2, parseInt(q.get('n') || '2', 10) || 2));
      this.g = newGame(code, n);
      addPlayer(this.g, pid, cleanName(q.get('name'), 'Player 1'));
      this.seen[pid] = Date.now();
      await this.save();
      return this.reply(pid);
    }

    if (!this.g) return { error: 'no_room' };
    this.seen[pid] = Date.now();

    if (act === 'state') {
      const v = parseInt(q.get('v') || '-1', 10);
      if (v === this.g.v) return { ok: 1, same: 1, v: this.g.v, away: this.away() };
      return this.reply(pid);
    }

    let res;
    if (act === 'join') {
      res = addPlayer(this.g, pid, cleanName(q.get('name'), 'Player ' + (this.g.players.length + 1)));
    } else if (act === 'roll') {
      res = roll(this.g, pid, die);
    } else if (act === 'move') {
      res = move(this.g, pid, parseInt(q.get('mask'), 10));
    } else if (act === 'leave') {
      res = leave(this.g, pid);
      if (res.closeRoom) {
        await this.ctx.storage.deleteAll();
        this.g = null;
        return { ok: 1, closed: 1 };
      }
    } else {
      return { error: 'bad_request' };
    }
    if (res.error) return { error: res.error };
    await this.save();
    return this.reply(pid);
  }

  async fetch(request) {
    const url = new URL(request.url);
    const out = await this.handle(url.pathname.replace(/^\/+/, ''), url.searchParams);
    return new Response(JSON.stringify(out), { headers: { 'content-type': 'application/json' } });
  }
}
