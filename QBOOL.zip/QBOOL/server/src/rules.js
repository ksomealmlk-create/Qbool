// Q BOOL rules - a line-by-line port of findOptions() in ../../src/game_logic.hpp.
// test/parity.sh compiles the real C++ header and checks both give identical answers.
export const NUM_TILES = 10;
export const MASK_ALL = (1 << (NUM_TILES + 1)) - 2;   // bits 1..10

// openMask: bit n set = tile n is still open. Returns the legal moves as bit masks
// of the tiles that would be closed (same order as the C++ version).
export function findOptions(openMask, d1, d2) {
  const out = [];
  let dice = 0;
  if (d1 >= 1 && d1 <= NUM_TILES && (openMask & (1 << d1))) dice |= 1 << d1;
  if (d2 >= 1 && d2 <= NUM_TILES && (openMask & (1 << d2))) dice |= 1 << d2;
  if (dice) out.push(dice);
  const total = d1 + d2;
  if (total >= 1 && total <= NUM_TILES && (openMask & (1 << total))) {
    const s = 1 << total;
    if (s !== dice) out.push(s);
  }
  return out;
}
