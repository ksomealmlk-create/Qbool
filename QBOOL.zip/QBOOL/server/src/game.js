// Pure game state machine for one room (no Cloudflare APIs, so it is unit-testable).
import { MASK_ALL, findOptions } from './rules.js';

// Same seat layout as StartGame() in main.cpp: 2 players sit opposite each other.
export const SEATS = { 2: [0, 2], 3: [0, 1, 2], 4: [0, 1, 2, 3] };

export function newGame(code, n) {
  return {
    code, n, seats: SEATS[n],
    players: [],              // [{ pid, name }] in turn order (join order)
    phase: 'lobby',           // lobby | roll | choose | over
    cur: 0,                   // turn index of the player to act
    open: [],                 // open-tile mask per turn index
    dice: [0, 0],             // the last roll
    options: [],              // legal masks while phase === 'choose'
    winner: -1,
    left: -1,                 // turn index of a player who left mid-game
    v: 1,                     // bumped on every change (clients poll with it)
    rollSeq: 0, rollBy: -1,   // every roll
    moveSeq: 0, moveBy: -1, moveMask: 0,   // every move (mask 0 = could not move)
  };
}

export function addPlayer(g, pid, name) {
  const have = g.players.findIndex(p => p.pid === pid);
  if (have >= 0) return { idx: have };                    // rejoin
  if (g.phase !== 'lobby' || g.players.length >= g.n) return { error: 'full' };
  g.players.push({ pid, name });
  if (g.players.length === g.n) {
    g.open = g.players.map(() => MASK_ALL);
    g.phase = 'roll';
    g.cur = 0;
  }
  g.v++;
  return { idx: g.players.length - 1 };
}

// rnd() must return an integer 1..6.
export function roll(g, pid, rnd) {
  if (g.phase !== 'roll') return { error: 'bad_phase' };
  if (g.players[g.cur].pid !== pid) return { error: 'not_your_turn' };
  const d1 = rnd(), d2 = rnd();
  g.dice = [d1, d2];
  g.rollSeq++; g.rollBy = g.cur;
  g.options = findOptions(g.open[g.cur], d1, d2);
  if (g.options.length === 0) {                           // no move: turn passes
    g.moveSeq++; g.moveBy = g.cur; g.moveMask = 0;
    g.cur = (g.cur + 1) % g.n;
    g.phase = 'roll';
  } else {
    g.phase = 'choose';
  }
  g.v++;
  return {};
}

export function move(g, pid, mask) {
  if (g.phase !== 'choose') return { error: 'bad_phase' };
  if (g.players[g.cur].pid !== pid) return { error: 'not_your_turn' };
  if (!Number.isInteger(mask) || !g.options.includes(mask)) return { error: 'bad_move' };
  g.open[g.cur] &= ~mask;
  g.moveSeq++; g.moveBy = g.cur; g.moveMask = mask;
  g.options = [];
  if (g.open[g.cur] === 0) {
    g.phase = 'over';
    g.winner = g.cur;
  } else {
    g.cur = (g.cur + 1) % g.n;                            // one roll per turn
    g.phase = 'roll';
  }
  g.v++;
  return {};
}

export function leave(g, pid) {
  const i = g.players.findIndex(p => p.pid === pid);
  if (i < 0) return { error: 'not_in_room' };
  if (g.phase === 'lobby') {                              // host leaving closes the room
    g.players.splice(i, 1); g.v++;
    return { closeRoom: i === 0 };
  }
  if (g.phase !== 'over') { g.phase = 'over'; g.left = i; g.options = []; g.v++; }
  return {};
}

// What a client may see (never the player tokens).
export function view(g, pid, away = []) {
  return {
    ok: 1,
    code: g.code, n: g.n, v: g.v,
    you: g.players.findIndex(p => p.pid === pid),
    phase: g.phase, cur: g.cur, seats: g.seats,
    players: g.players.map((p, i) => ({ name: p.name, seat: g.seats[i], away: !!away[i] })),
    open: g.open, dice: g.dice,
    options: g.phase === 'choose' ? g.options : [],
    winner: g.winner, left: g.left,
    rollSeq: g.rollSeq, rollBy: g.rollBy,
    moveSeq: g.moveSeq, moveBy: g.moveBy, moveMask: g.moveMask,
  };
}
