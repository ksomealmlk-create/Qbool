# Q BOOL online server

Cloudflare Worker + one Durable Object per room. The server rolls the dice and checks every move
with the same rules as the game (`../src/game_logic.hpp`), so a modified client cannot cheat.

Every endpoint works with GET or POST, always answers HTTP 200 with JSON; failures look like `{"error":"..."}`.
`pid` is a random per-device token (8-64 chars `A-Za-z0-9_-`) that the client keeps; it identifies the player.

| Endpoint | Params | Purpose |
|---|---|---|
| `/create` | `pid name n` (2-4) | new room, returns the 5-letter `code` |
| `/join` | `code pid name` | join (also re-joins with the same `pid`) |
| `/state` | `code pid v` | current state; if `v` equals the server version the reply is just `{same:1,v,away}` |
| `/roll` | `code pid` | roll the dice (only on your turn) |
| `/move` | `code pid mask` | close tiles; `mask` must be one of `options` |
| `/leave` | `code pid` | leave the room |

State fields: `phase` (lobby/roll/choose/over), `cur` (turn index), `you` (your turn index), `seats`, `players`,
`open` (open-tile mask per turn index, bit n = tile n), `dice`, `options`, `winner`, and the counters
`rollSeq/rollBy` and `moveSeq/moveBy/moveMask` that tell a client which animations to play.
Errors: `bad_request bad_code no_room exists full not_your_turn bad_phase bad_move not_in_room busy`.

Rooms are deleted after 3 hours without activity.

## Tests
```
npm test            # unit tests (Node 22)
npm run parity      # compiles the real C++ rules and compares all 36,864 board/dice cases
```
