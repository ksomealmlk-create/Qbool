#!/usr/bin/env bash
# Checks that the server rules (JS) give exactly the same moves as the game's C++ rules.
set -euo pipefail
cd "$(dirname "$0")"
tmp="$(mktemp -d)"
node dump_rules.mjs > "$tmp/js.txt"
g++ -std=c++17 -O1 dump_rules.cpp -o "$tmp/dump"
"$tmp/dump" > "$tmp/cpp.txt"
if cmp -s "$tmp/js.txt" "$tmp/cpp.txt"; then
  echo "parity OK: $(wc -l < "$tmp/js.txt") cases identical"
else
  echo "PARITY FAILED"; diff "$tmp/js.txt" "$tmp/cpp.txt" | head -20; exit 1
fi
