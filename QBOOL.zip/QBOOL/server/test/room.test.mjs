// Drives the Room Durable Object through its HTTP interface with a fake storage.
import test from 'node:test';
import assert from 'node:assert/strict';
import { Room } from '../src/room.js';

function fakeCtx() {
  const m = new Map();
  let alarm = null;
  return {
    storage: {
      get: async (k) => (m.has(k) ? structuredClone(m.get(k)) : undefined),
      put: async (k, v) => { m.set(k, structuredClone(v)); },
      deleteAll: async () => { m.clear(); },
      setAlarm: async (t) => { alarm = t; },
    },
    blockConcurrencyWhile: async (f) => f(),
    get alarm() { return alarm; },
  };
}

const A = 'aaaaaaaa-host', B = 'bbbbbbbb-guest';
const call = async (room, path, params) => {
  await room.ready;
  const u = new URL('https://room/' + path);
  for (const [k, v] of Object.entries({ code: 'ABCDE', ...params })) u.searchParams.set(k, v);
  return (await room.fetch(new Request(u))).json();
};

test('create, join, poll, roll and move through the HTTP interface', async () => {
  const ctx = fakeCtx();
  const room = new Room(ctx, {});

  const c = await call(room, 'create', { pid: A, name: 'Ali', n: 2 });
  assert.equal(c.ok, 1);
  assert.equal(c.you, 0);
  assert.equal(c.phase, 'lobby');
  assert.ok(ctx.alarm > Date.now());                       // cleanup is scheduled

  assert.equal((await call(room, 'create', { pid: B })).error, 'exists');

  const j = await call(room, 'join', { pid: B, name: 'Sami' });
  assert.equal(j.you, 1);
  assert.equal(j.phase, 'roll');
  assert.deepEqual(j.players.map(p => p.name), ['Ali', 'Sami']);

  // unchanged state answers with a tiny reply
  const same = await call(room, 'state', { pid: A, v: j.v });
  assert.equal(same.same, 1);
  const full = await call(room, 'state', { pid: A, v: 0 });
  assert.equal(full.phase, 'roll');

  assert.equal((await call(room, 'roll', { pid: B })).error, 'not_your_turn');
  const r = await call(room, 'roll', { pid: A });
  assert.equal(r.rollSeq, 1);
  assert.ok(r.dice[0] >= 1 && r.dice[0] <= 6 && r.dice[1] >= 1 && r.dice[1] <= 6);

  if (r.phase === 'choose') {
    assert.equal((await call(room, 'move', { pid: A, mask: 1 })).error, 'bad_move');
    const m = await call(room, 'move', { pid: A, mask: r.options[0] });
    assert.equal(m.moveSeq, 1);
    assert.equal(m.cur, 1);
  } else {
    assert.equal(r.cur, 1);                                 // passed
  }

  // a second Room instance on the same storage (eviction / restart) keeps the game
  const again = new Room(ctx, {});
  assert.equal((await call(again, 'state', { pid: B, v: 0 })).players.length, 2);
});

test('bad input is refused', async () => {
  const room = new Room(fakeCtx(), {});
  assert.equal((await call(room, 'join', { pid: A })).error, 'no_room');
  assert.equal((await call(room, 'create', { pid: 'x' })).error, 'bad_request');
  await call(room, 'create', { pid: A });
  assert.equal((await call(room, 'nonsense', { pid: A })).error, 'bad_request');
});

test('host leaving the lobby closes the room, the alarm clears it', async () => {
  const ctx = fakeCtx();
  const room = new Room(ctx, {});
  await call(room, 'create', { pid: A, n: 3 });
  const l = await call(room, 'leave', { pid: A });
  assert.equal(l.closed, 1);
  assert.equal((await call(room, 'state', { pid: A, v: 0 })).error, 'no_room');
  await call(room, 'create', { pid: A });
  await room.alarm();
  assert.equal((await call(room, 'state', { pid: A, v: 0 })).error, 'no_room');
});
