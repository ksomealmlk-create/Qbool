// Prints findOptions() from the real game header (see dump_rules.mjs).
#include "../../src/game_logic.hpp"
#include <cstdio>
int main() {
    for (unsigned k = 0; k < 1024; ++k) {
        const unsigned m = k << 1;
        Board bd;
        for (int n = 1; n <= NUM_TILES; ++n) bd.open[n] = (m >> n) & 1u;
        for (int a = 1; a <= 6; ++a)
            for (int b = 1; b <= 6; ++b) {
                std::printf("%u %d %d ", m, a, b);
                const auto opts = findOptions(bd, a, b);
                for (size_t i = 0; i < opts.size(); ++i) std::printf(i ? ",%u" : "%u", (unsigned)opts[i]);
                std::printf("\n");
            }
    }
    return 0;
}
