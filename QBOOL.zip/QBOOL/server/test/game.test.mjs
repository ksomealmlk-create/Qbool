import test from 'node:test';
import assert from 'node:assert/strict';
import { newGame, addPlayer, roll, move, leave, view } from '../src/game.js';
import { MASK_ALL } from '../src/rules.js';

const P = (i) => 'player-' + i + '-token';
const seq = (...vals) => { let i = 0; return () => vals[i++]; };

function started(n = 2) {
  const g = newGame('ABCDE', n);
  for (let i = 0; i < n; i++) addPlayer(g, P(i), 'P' + i);
  return g;
}

test('lobby fills, then the game starts with every tile open', () => {
  const g = newGame('ABCDE', 2);
  assert.equal(g.phase, 'lobby');
  addPlayer(g, P(0), 'A');
  assert.equal(g.phase, 'lobby');
  addPlayer(g, P(1), 'B');
  assert.equal(g.phase, 'roll');
  assert.deepEqual(g.open, [MASK_ALL, MASK_ALL]);
  assert.deepEqual(g.seats, [0, 2]);
  assert.equal(addPlayer(g, P(2), 'C').error, 'full');
  assert.equal(addPlayer(g, P(0), 'A').idx, 0);          // rejoin is fine
});

test('only the player whose turn it is may roll', () => {
  const g = started();
  assert.equal(roll(g, P(1), seq(1, 2)).error, 'not_your_turn');
  assert.equal(roll(g, P(0), seq(1, 2)).error, undefined);
  assert.equal(roll(g, P(0), seq(1, 2)).error, 'bad_phase');   // must move first
});

test('moves must be one of the offered options', () => {
  const g = started();
  roll(g, P(0), seq(3, 4));                                    // options: tiles 3+4, or 7
  assert.deepEqual(g.options, [(1 << 3) | (1 << 4), 1 << 7]);
  assert.equal(move(g, P(1), 1 << 7).error, 'not_your_turn');
  assert.equal(move(g, P(0), 1 << 5).error, 'bad_move');
  assert.equal(move(g, P(0), (1 << 3)).error, 'bad_move');     // half of the dice option is not allowed
  assert.equal(move(g, P(0), 'x').error, 'bad_move');
  assert.equal(move(g, P(0), 1 << 7).error, undefined);
  assert.equal(g.open[0] & (1 << 7), 0);
  assert.equal(g.cur, 1);                                      // turn passes after a move
  assert.equal(g.phase, 'roll');
});

test('no legal move passes the turn automatically', () => {
  const g = started();
  g.open[0] = 0b10;                  // only tile 1 left for player 0
  roll(g, P(0), seq(6, 6));          // 12 and 6: nothing to close
  assert.equal(g.phase, 'roll');
  assert.equal(g.cur, 1);
  assert.equal(g.moveMask, 0);
  assert.equal(g.moveSeq, 1);
  assert.deepEqual(g.dice, [6, 6]);
});

test('shutting the last tile wins', () => {
  const g = started();
  g.open[0] = 1 << 7;
  roll(g, P(0), seq(3, 4));
  move(g, P(0), 1 << 7);
  assert.equal(g.phase, 'over');
  assert.equal(g.winner, 0);
  assert.equal(roll(g, P(1), seq(1, 1)).error, 'bad_phase');
});

test('leaving mid-game ends it; leaving the lobby as host closes the room', () => {
  const g = started();
  leave(g, P(1));
  assert.equal(g.phase, 'over');
  assert.equal(g.left, 1);
  const l = newGame('ABCDE', 3);
  addPlayer(l, P(0), 'A'); addPlayer(l, P(1), 'B');
  assert.equal(leave(l, P(1)).closeRoom, false);
  assert.equal(leave(l, P(0)).closeRoom, true);
});

test('view never leaks player tokens', () => {
  const g = started();
  assert.ok(!JSON.stringify(view(g, P(0))).includes('token'));
  assert.equal(view(g, P(1)).you, 1);
  assert.equal(view(g, 'stranger-xxxx').you, -1);
});

test('random full games always finish and keep the rules', () => {
  for (let n = 2; n <= 4; n++) {
    for (let game = 0; game < 200; game++) {
      const g = started(n);
      let steps = 0;
      while (g.phase !== 'over' && steps++ < 5000) {
        const pid = g.players[g.cur].pid;
        assert.equal(roll(g, pid, () => 1 + Math.floor(Math.random() * 6)).error, undefined);
        if (g.phase === 'choose') {
          const pick = g.options[Math.floor(Math.random() * g.options.length)];
          const before = g.open[g.cur];
          assert.equal(move(g, pid, pick).error, undefined);
          assert.equal(before & pick, pick);                   // only open tiles get closed
        }
      }
      assert.equal(g.phase, 'over', 'game must end');
      assert.equal(g.open[g.winner], 0);
    }
  }
});
