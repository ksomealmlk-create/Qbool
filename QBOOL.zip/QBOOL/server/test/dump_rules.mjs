// Prints findOptions() for every board and every dice pair. test/dump_rules.cpp prints the same
// thing from the real C++ header; parity.sh checks the two outputs are byte-identical.
import { findOptions } from '../src/rules.js';
const lines = [];
for (let k = 0; k < 1024; k++) {
  const m = k << 1;                                   // bits 1..10
  for (let a = 1; a <= 6; a++)
    for (let b = 1; b <= 6; b++)
      lines.push(`${m} ${a} ${b} ${findOptions(m, a, b).join(',')}`);
}
process.stdout.write(lines.join('\n') + '\n');
