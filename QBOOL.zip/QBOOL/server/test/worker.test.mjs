// Tests the Worker entry point with an in-memory stand-in for the ROOMS namespace.
import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../src/index.js';
import { Room } from '../src/room.js';

function fakeEnv() {
  const rooms = new Map();
  const mk = () => {
    const m = new Map();
    return {
      storage: {
        get: async (k) => m.get(k), put: async (k, v) => { m.set(k, structuredClone(v)); },
        deleteAll: async () => m.clear(), setAlarm: async () => {},
      },
      blockConcurrencyWhile: async (f) => f(),
    };
  };
  return {
    ROOMS: {
      idFromName: (name) => name,
      get: (name) => {
        if (!rooms.has(name)) rooms.set(name, new Room(mk(), {}));
        const r = rooms.get(name);
        return { fetch: async (u) => { await r.ready; return r.fetch(new Request(u)); } };
      },
    },
  };
}

const get = async (env, path) => {
  const res = await worker.fetch(new Request('https://qbool.example/' + path), env);
  return { res, body: await res.json() };
};

test('ping, CORS, unknown paths', async () => {
  const env = fakeEnv();
  const { res, body } = await get(env, 'ping');
  assert.equal(body.ok, 1);
  assert.equal(res.headers.get('access-control-allow-origin'), '*');
  assert.equal((await get(env, 'whatever')).body.error, 'not_found');
  const pre = await worker.fetch(new Request('https://qbool.example/create', { method: 'OPTIONS' }), env);
  assert.equal(pre.status, 204);
});

test('a full session through the Worker', async () => {
  const env = fakeEnv();
  const A = 'aaaaaaaa-host', B = 'bbbbbbbb-guest';
  const c = (await get(env, `create?pid=${A}&name=Ali&n=2`)).body;
  assert.match(c.code, /^[A-HJ-NP-Z2-9]{5}$/);
  const j = (await get(env, `join?code=${c.code.toLowerCase()}&pid=${B}&name=Sami`)).body;   // codes are case-insensitive
  assert.equal(j.phase, 'roll');
  const r = (await get(env, `roll?code=${c.code}&pid=${A}`)).body;
  assert.equal(r.rollSeq, 1);
  assert.equal((await get(env, `roll?code=${c.code}&pid=${B}`)).body.error === undefined, r.phase === 'roll');
});

test('bad and unknown codes', async () => {
  const env = fakeEnv();
  assert.equal((await get(env, 'join?code=12&pid=aaaaaaaa-x')).body.error, 'bad_code');
  assert.equal((await get(env, 'join?code=ABCDE&pid=aaaaaaaa-x')).body.error, 'no_room');
});
