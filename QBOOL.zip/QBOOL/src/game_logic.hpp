// Q BOOL - pure game logic (no graphics), easy to test.
#pragma once
#include <array>
#include <cstdint>
#include <vector>

constexpr int NUM_TILES = 12;

struct Board {
    std::array<bool, NUM_TILES + 1> open{};   // index 1..12

    Board() { reset(); }
    void reset() { open.fill(true); open[0] = false; }
    void shutAll() { open.fill(false); }

    int openSum() const {
        int s = 0;
        for (int n = 1; n <= NUM_TILES; ++n) if (open[n]) s += n;
        return s;
    }
    bool allShut() const { return openSum() == 0; }
    // When tiles 7..12 are all shut, the player rolls ONE die only.
    bool highShut() const {
        for (int n = 7; n <= NUM_TILES; ++n) if (open[n]) return false;
        return true;
    }
};

// Every subset of open tiles that adds up to `target`.
// A subset is returned as a bit mask: bit n set = tile n is used.
inline std::vector<uint16_t> findCombos(const Board& b, int target) {
    std::vector<int> t;
    for (int n = 1; n <= NUM_TILES; ++n) if (b.open[n]) t.push_back(n);
    std::vector<uint16_t> out;
    const unsigned m = (unsigned)t.size();
    for (unsigned mask = 1; mask < (1u << m); ++mask) {
        int s = 0;
        uint16_t bits = 0;
        for (unsigned i = 0; i < m; ++i)
            if (mask & (1u << i)) { s += t[i]; bits |= (uint16_t)(1u << t[i]); }
        if (s == target) out.push_back(bits);
    }
    return out;
}

// Computer player: prefers closing the biggest tiles (lowest leftover score).
inline uint16_t botPick(const std::vector<uint16_t>& combos) {
    uint16_t best = 0;
    long bestScore = -1;
    for (uint16_t c : combos) {
        long sc = 0;
        for (int n = 1; n <= NUM_TILES; ++n) if (c & (1u << n)) sc += (long)n * n;
        if (sc > bestScore) { bestScore = sc; best = c; }
    }
    return best;
}

inline int selectionSum(uint16_t bits) {
    int s = 0;
    for (int n = 1; n <= NUM_TILES; ++n) if (bits & (1u << n)) s += n;
    return s;
}
