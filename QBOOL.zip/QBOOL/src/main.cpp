// Q BOOL - 3D tile-closing dice board game (2-4 players), C++ + raylib.
// Roll the dice, then close tiles that add up to the roll.
// When you can't move, your open tiles are your score. Lowest score wins!
#include "raylib.h"
#include "rlgl.h"
#include "game_logic.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <vector>

#if defined(__EMSCRIPTEN__)
#include <emscripten/emscripten.h>
#endif

namespace {

// ------------------------------------------------------------ constants
const float PI_F      = 3.14159265f;
const float HINGE_Y   = 0.47f;
const float HINGE_Z   = 6.2f;
const float TILE_W    = 0.7f;
const float TILE_L    = 1.2f;
const float TILE_T    = 0.12f;
const float TILE_STEP = 0.8f;
const float OPEN_ANG  = 68.0f;
const float SEL_ANG   = 38.0f;

const Color SEAT_COL[4]  = { Color{50,110,230,255}, Color{225,55,55,255},
                             Color{45,175,85,255},  Color{240,200,40,255} };
const char* SEAT_NAME[4] = { "BLUE", "RED", "GREEN", "YELLOW" };
const Color CLOSED_COL   = Color{70,55,45,255};

enum class State { Menu, WaitRoll, Rolling, Choose, Pause, GameOver };
enum class PauseNext { GoRoll, EndTurn };

struct Game {
    State state = State::Menu;
    int numPlayers = 4;
    bool vsComputer = false;

    int seats[4] = {0, 1, 2, 3};     // turn index -> seat
    Board boards[4];                 // indexed by SEAT
    float angle[4][NUM_TILES + 1] = {};
    int scores[4] = {0, 0, 0, 0};    // indexed by turn index
    bool done[4] = {false, false, false, false};
    int cur = 0;                     // current turn index

    int d1 = 1, d2 = 1, rollTotal = 2;
    bool oneDie = false;
    float rollT = 1.0f;
    Vector3 dieStart[2] = {}, dieEnd[2] = {};
    float dieYaw[2] = {0, 0};
    float dieSpin[2][2] = {};

    uint16_t selected = 0;
    std::vector<uint16_t> combos;
    float botTimer = 0.0f;
    int botStage = 0;

    float timer = 0.0f;
    PauseNext pauseNext = PauseNext::GoRoll;
    char msg[96] = "";

    float camAngle = 0.0f;
};

Game g;
Camera3D cam;
Vector2 g_mp = {0, 0};
bool g_tap = false;

int CurSeat() { return g.seats[g.cur]; }
bool IsBot(int turnIdx) { return g.vsComputer && turnIdx != 0; }
float UIScale() {
    float u = std::min(GetScreenWidth() / 960.0f, GetScreenHeight() / 540.0f);
    return std::max(0.55f, std::min(u, 2.2f));
}
float Clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

// ------------------------------------------------------------ game flow
void StartGame() {
    const int n = g.numPlayers;
    if (n == 2)      { g.seats[0] = 0; g.seats[1] = 2; }
    else             { for (int i = 0; i < n; ++i) g.seats[i] = i; }
    bool active[4] = {false, false, false, false};
    for (int i = 0; i < n; ++i) active[g.seats[i]] = true;
    for (int s = 0; s < 4; ++s) {
        g.boards[s].reset();
        if (!active[s]) g.boards[s].shutAll();
        for (int t = 0; t <= NUM_TILES; ++t) g.angle[s][t] = 0.0f;
    }
    for (int i = 0; i < 4; ++i) { g.scores[i] = 0; g.done[i] = false; }
    g.cur = 0;
    g.selected = 0;
    g.rollT = 1.0f;
    g.d1 = g.d2 = 0;
    g.rollTotal = 0;
    g.msg[0] = 0;
    g.botTimer = 0.9f;
    g.state = State::WaitRoll;
}

void ToMenu() {
    for (int s = 0; s < 4; ++s) g.boards[s].reset();
    g.selected = 0;
    g.rollT = 1.0f;
    g.d1 = g.d2 = 0;
    g.rollTotal = 0;
    g.cur = 0;
    g.msg[0] = 0;
    g.state = State::Menu;
}

void DoRoll() {
    const int seat = CurSeat();
    g.oneDie = g.boards[seat].highShut();
    g.d1 = GetRandomValue(1, 6);
    g.d2 = g.oneDie ? 0 : GetRandomValue(1, 6);
    g.rollTotal = g.d1 + g.d2;
    g.rollT = 0.0f;

    const float phi = seat * PI_F / 2.0f;
    const float sx = sinf(phi), sz = cosf(phi);
    for (int i = 0; i < 2; ++i) {
        float jx = GetRandomValue(-30, 30) / 100.0f;
        float jz = GetRandomValue(-30, 30) / 100.0f;
        if (g.oneDie) {
            g.dieEnd[i] = Vector3{ 0.0f + jx, 0.765f, 0.0f + jz };
        } else {
            g.dieEnd[i] = Vector3{ (i == 0 ? -0.95f : 0.95f) + jx, 0.765f,
                                   (i == 0 ? 0.3f : -0.3f) + jz };
        }
        g.dieStart[i] = Vector3{ sx * 8.0f + (i == 0 ? -0.8f : 0.8f) * sz, 3.2f,
                                 sz * 8.0f - (i == 0 ? -0.8f : 0.8f) * sx };
        g.dieYaw[i] = (float)GetRandomValue(0, 359);
        g.dieSpin[i][0] = (GetRandomValue(0, 1) ? 1.0f : -1.0f) * (700.0f + GetRandomValue(0, 400));
        g.dieSpin[i][1] = (GetRandomValue(0, 1) ? 1.0f : -1.0f) * (600.0f + GetRandomValue(0, 400));
    }
    g.selected = 0;
    g.msg[0] = 0;
    g.state = State::Rolling;
}

void EnterChoose() {
    const int seat = CurSeat();
    g.combos = findCombos(g.boards[seat], g.rollTotal);
    g.selected = 0;
    if (g.combos.empty()) {
        g.scores[g.cur] = g.boards[seat].openSum();
        g.done[g.cur] = true;
        std::snprintf(g.msg, sizeof(g.msg), "No move!  %s scores %d", SEAT_NAME[seat], g.scores[g.cur]);
        g.state = State::Pause;
        g.pauseNext = PauseNext::EndTurn;
        g.timer = 2.2f;
    } else {
        g.state = State::Choose;
        g.botTimer = 1.0f;
        g.botStage = 0;
    }
}

void EndTurn() {
    g.cur++;
    g.selected = 0;
    g.msg[0] = 0;
    if (g.cur >= g.numPlayers) {
        g.cur = g.numPlayers - 1;
        g.state = State::GameOver;
    } else {
        g.state = State::WaitRoll;
        g.botTimer = 0.9f;
    }
}

void ConfirmSelection() {
    const int seat = CurSeat();
    for (int n = 1; n <= NUM_TILES; ++n)
        if (g.selected & (1u << n)) g.boards[seat].open[n] = false;
    g.selected = 0;
    if (g.boards[seat].allShut()) {
        g.scores[g.cur] = 0;
        g.done[g.cur] = true;
        std::snprintf(g.msg, sizeof(g.msg), "SHUT THE BOX!  %s scores 0", SEAT_NAME[seat]);
        g.state = State::Pause;
        g.pauseNext = PauseNext::EndTurn;
        g.timer = 2.6f;
    } else {
        g.msg[0] = 0;
        g.state = State::Pause;
        g.pauseNext = PauseNext::GoRoll;
        g.timer = 0.7f;
    }
}

// ------------------------------------------------------------ geometry
Vector3 TileCenter(int seat, int n, float angDeg) {
    const float lx = (n - 6.5f) * TILE_STEP;
    const float th = angDeg * PI_F / 180.0f;
    const float ly = HINGE_Y + 0.6f * sinf(th) + 0.06f * cosf(th);
    const float lz = HINGE_Z - 0.6f * cosf(th) + 0.06f * sinf(th);
    const float phi = seat * PI_F / 2.0f;
    return Vector3{ lx * cosf(phi) + lz * sinf(phi), ly, -lx * sinf(phi) + lz * cosf(phi) };
}

// Returns the open tile (1..12) of `seat` nearest to the pointer, or 0.
int PickTile(int seat, Vector2 mp) {
    int best = 0;
    float bestD = 1e9f;
    const float phi = seat * PI_F / 2.0f;
    for (int n = 1; n <= NUM_TILES; ++n) {
        if (!g.boards[seat].open[n]) continue;
        Vector3 c = TileCenter(seat, n, g.angle[seat][n]);
        Vector2 s = GetWorldToScreen(c, cam);
        Vector3 r = Vector3{ c.x + 0.4f * cosf(phi), c.y, c.z - 0.4f * sinf(phi) };
        Vector2 s2 = GetWorldToScreen(r, cam);
        float halfW = hypotf(s2.x - s.x, s2.y - s.y);
        float d = hypotf(mp.x - s.x, mp.y - s.y);
        if (d < halfW * 1.25f && d < bestD) { bestD = d; best = n; }
    }
    return best;
}

Rectangle RollRect() {
    float u = UIScale();
    float w = 230 * u, h = 62 * u;
    return Rectangle{ GetScreenWidth() / 2.0f - w / 2, GetScreenHeight() - h - 24 * u, w, h };
}
Rectangle ClearRect() {
    float u = UIScale();
    float w = 190 * u, h = 56 * u;
    return Rectangle{ GetScreenWidth() / 2.0f - w / 2, GetScreenHeight() - h - 24 * u, w, h };
}

// ------------------------------------------------------------ update
void ReadInput() {
    static bool touchPrev = false;
    static double lastTap = -10.0;
    g_mp = GetMousePosition();
    bool touchNow = GetTouchPointCount() > 0;
    if (touchNow) g_mp = GetTouchPosition(0);
    g_tap = IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || (touchNow && !touchPrev);
    touchPrev = touchNow;
    double now = GetTime();
    if (g_tap) {
        if (now - lastTap < 0.30) g_tap = false;   // ignore duplicate touch+mouse events
        else lastTap = now;
    }
}

void UpdateCamera(float dt) {
    float target;
    if (g.state == State::Menu) {
        g.camAngle += dt * 0.15f;
        target = g.camAngle;
    } else {
        target = CurSeat() * PI_F / 2.0f;
    }
    float diff = target - g.camAngle;
    while (diff > PI_F)  diff -= 2 * PI_F;
    while (diff < -PI_F) diff += 2 * PI_F;
    g.camAngle += diff * std::min(1.0f, dt * 3.5f);

    float aspect = (float)GetScreenWidth() / (float)GetScreenHeight();
    float k = aspect < 1.5f ? 1.5f / aspect : 1.0f;
    k = Clampf(k, 1.0f, 2.4f);
    const float R = 11.0f * k, H = 15.0f * k;
    cam.position = Vector3{ sinf(g.camAngle) * R, H, cosf(g.camAngle) * R };
    cam.target = Vector3{ 0.0f, 0.0f, 0.0f };
    cam.up = Vector3{ 0.0f, 1.0f, 0.0f };
    cam.fovy = 45.0f;
    cam.projection = CAMERA_PERSPECTIVE;
}

void UpdateTiles(float dt) {
    for (int s = 0; s < 4; ++s) {
        for (int n = 1; n <= NUM_TILES; ++n) {
            float target = 0.0f;
            if (g.boards[s].open[n]) {
                target = OPEN_ANG;
                if (g.state != State::Menu && s == CurSeat() && (g.selected & (1u << n))) target = SEL_ANG;
            }
            g.angle[s][n] += (target - g.angle[s][n]) * std::min(1.0f, dt * 9.0f);
        }
    }
}

void Update(float dt) {
    ReadInput();
    UpdateCamera(dt);
    UpdateTiles(dt);

    const int seat = CurSeat();
    switch (g.state) {
    case State::Menu:
    case State::GameOver:
        break;

    case State::WaitRoll:
        if (IsBot(g.cur)) {
            g.botTimer -= dt;
            if (g.botTimer <= 0.0f) DoRoll();
        } else if (IsKeyPressed(KEY_SPACE)) {
            DoRoll();
        }
        break;

    case State::Rolling:
        g.rollT += dt / 1.1f;
        if (g.rollT >= 1.0f) { g.rollT = 1.0f; EnterChoose(); }
        break;

    case State::Choose:
        if (IsBot(g.cur)) {
            g.botTimer -= dt;
            if (g.botTimer <= 0.0f) {
                if (g.botStage == 0) {
                    g.selected = botPick(g.combos);
                    g.botStage = 1;
                    g.botTimer = 0.8f;
                } else {
                    ConfirmSelection();
                }
            }
        } else {
            if (IsKeyPressed(KEY_C)) g.selected = 0;
            if (g_tap && !CheckCollisionPointRec(g_mp, ClearRect())) {
                int hit = PickTile(seat, g_mp);
                if (hit) {
                    const uint16_t bit = (uint16_t)(1u << hit);
                    if (g.selected & bit) {
                        g.selected &= (uint16_t)~bit;
                    } else if (hit <= g.rollTotal - selectionSum(g.selected)) {
                        g.selected |= bit;
                    }
                    if (selectionSum(g.selected) == g.rollTotal) ConfirmSelection();
                }
            }
        }
        break;

    case State::Pause:
        g.timer -= dt;
        if (g.timer <= 0.0f) {
            if (g.pauseNext == PauseNext::EndTurn) EndTurn();
            else { g.state = State::WaitRoll; g.botTimer = 0.8f; }
        }
        break;
    }
}

// ------------------------------------------------------------ drawing: 3D
void DrawDie(int i) {
    if (i == 1 && g.oneDie) return;
    if (g.d1 == 0) return;
    const float t = g.rollT;
    const float e = 1.0f - (1.0f - t) * (1.0f - t);
    Vector3 p;
    p.x = g.dieStart[i].x + (g.dieEnd[i].x - g.dieStart[i].x) * e;
    p.z = g.dieStart[i].z + (g.dieEnd[i].z - g.dieStart[i].z) * e;
    p.y = g.dieEnd[i].y + fabsf(sinf(t * PI_F * 3.0f)) * (1.0f - t) * 2.2f;
    const float spin = powf(1.0f - t, 1.5f);
    const float ax = spin * g.dieSpin[i][0];
    const float az = spin * g.dieSpin[i][1];

    DrawCube(Vector3{ p.x, 0.48f, p.z }, 0.75f, 0.005f, 0.75f, Fade(BLACK, 0.25f));  // shadow

    rlPushMatrix();
    rlTranslatef(p.x, p.y, p.z);
    rlRotatef(g.dieYaw[i], 0, 1, 0);
    rlRotatef(ax, 1, 0, 0);
    rlRotatef(az, 0, 0, 1);
    DrawCube(Vector3{0, 0, 0}, 0.6f, 0.6f, 0.6f, Color{250,248,240,255});
    DrawCubeWires(Vector3{0, 0, 0}, 0.6f, 0.6f, 0.6f, Color{60,60,60,255});
    if (t >= 1.0f) {
        const int v = (i == 0) ? g.d1 : g.d2;
        const float a = 0.17f, y = 0.30f, r = 0.06f;
        auto pip = [&](float x, float z) { DrawSphere(Vector3{x, y, z}, r, BLACK); };
        if (v == 1 || v == 3 || v == 5) pip(0, 0);
        if (v >= 2) { pip(-a, -a); pip(a, a); }
        if (v >= 4) { pip(-a, a); pip(a, -a); }
        if (v == 6) { pip(-a, 0); pip(a, 0); }
    }
    rlPopMatrix();
}

void DrawScene() {
    DrawPlane(Vector3{0, 0, 0}, Vector2{60, 60}, Color{232,226,214,255});           // table
    DrawCube(Vector3{0, 0.225f, 0}, 13.8f, 0.45f, 13.8f, Color{150,100,55,255});    // wooden board
    DrawCubeWires(Vector3{0, 0.225f, 0}, 13.8f, 0.45f, 13.8f, Color{70,45,25,255});
    DrawCube(Vector3{0, 0.455f, 0}, 10.0f, 0.02f, 10.0f, Color{30,125,55,255});     // green felt

    const float pulse = 0.5f + 0.5f * sinf((float)GetTime() * 4.0f);
    for (int s = 0; s < 4; ++s) {
        bool active = false;
        for (int i = 0; i < g.numPlayers; ++i) if (g.seats[i] == s) active = true;
        Color c = ColorBrightness(SEAT_COL[s], active ? -0.15f : -0.6f);
        if (g.state != State::Menu && g.state != State::GameOver && s == CurSeat())
            c = ColorBrightness(SEAT_COL[s], 0.15f + 0.25f * pulse);

        rlPushMatrix();
        rlRotatef(s * 90.0f, 0, 1, 0);
        DrawCube(Vector3{0, 0.455f, 5.6f}, 9.6f, 0.02f, 1.5f, c);
        rlPopMatrix();

        for (int n = 1; n <= NUM_TILES; ++n) {
            const bool open = g.boards[s].open[n];
            const bool sel = (g.state != State::Menu) && s == CurSeat() && (g.selected & (1u << n));
            Color body = open ? (sel ? Color{255,160,0,255} : SEAT_COL[s]) : CLOSED_COL;
            rlPushMatrix();
            rlRotatef(s * 90.0f, 0, 1, 0);
            rlTranslatef((n - 6.5f) * TILE_STEP, HINGE_Y, HINGE_Z);
            rlRotatef(g.angle[s][n], 1, 0, 0);
            DrawCube(Vector3{0, 0.06f, -0.6f}, TILE_W, TILE_T, TILE_L, body);
            DrawCubeWires(Vector3{0, 0.06f, -0.6f}, TILE_W, TILE_T, TILE_L, Color{20,20,20,255});
            rlPopMatrix();
        }
    }
    DrawDie(0);
    DrawDie(1);
}

// ------------------------------------------------------------ drawing: 2D
void Txt(const char* s, float x, float y, int size, Color c) {
    int o = std::max(1, size / 14);
    DrawText(s, (int)x + o, (int)y + o, size, Fade(BLACK, 0.65f));
    DrawText(s, (int)x, (int)y, size, c);
}
void TxtC(const char* s, float cx, float y, int size, Color c) {
    Txt(s, cx - MeasureText(s, size) / 2.0f, y, size, c);
}

bool Btn(Rectangle r, const char* label, Color col, int fontSize) {
    const bool hover = CheckCollisionPointRec(g_mp, r);
    DrawRectangleRounded(Rectangle{r.x + 3, r.y + 4, r.width, r.height}, 0.3f, 8, Fade(BLACK, 0.4f));
    DrawRectangleRounded(r, 0.3f, 8, hover ? ColorBrightness(col, 0.2f) : col);
    TxtC(label, r.x + r.width / 2, r.y + (r.height - fontSize) / 2, fontSize, WHITE);
    if (g_tap && hover) { g_tap = false; return true; }
    return false;
}

void DrawTileNumbers() {
    for (int s = 0; s < 4; ++s) {
        const float phi = s * PI_F / 2.0f;
        for (int n = 1; n <= NUM_TILES; ++n) {
            if (!g.boards[s].open[n] || g.angle[s][n] < 22.0f) continue;
            Vector3 c = TileCenter(s, n, g.angle[s][n]);
            Vector2 p = GetWorldToScreen(c, cam);
            Vector3 r = Vector3{ c.x + 0.4f * cosf(phi), c.y, c.z - 0.4f * sinf(phi) };
            Vector2 p2 = GetWorldToScreen(r, cam);
            float halfW = hypotf(p2.x - p.x, p2.y - p.y);
            int fs = (int)Clampf(halfW * 1.5f, 10.0f, 52.0f);
            char buf[8];
            std::snprintf(buf, sizeof(buf), "%d", n);
            const bool sel = (g.state != State::Menu) && s == CurSeat() && (g.selected & (1u << n));
            TxtC(buf, p.x, p.y - fs / 2.0f, fs, sel ? BLACK : WHITE);
        }
    }
}

void DrawMenu() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    DrawRectangle(0, 0, (int)W, (int)H, Fade(BLACK, 0.45f));
    const float cx = W / 2;
    float y = H * 0.07f;
    TxtC("Q BOOL", cx, y, (int)(84 * u), Color{255,210,70,255});
    y += 100 * u;
    TxtC("3D dice & tiles board game  (2-4 players)", cx, y, (int)(24 * u), WHITE);
    y += 56 * u;

    TxtC("Players", cx, y, (int)(26 * u), WHITE);
    y += 38 * u;
    for (int i = 0; i < 3; ++i) {
        const int n = i + 2;
        Rectangle r{ cx + (i - 1.5f) * 84 * u + 5 * u, y, 74 * u, 56 * u };
        char b[4]; std::snprintf(b, sizeof(b), "%d", n);
        if (Btn(r, b, g.numPlayers == n ? Color{230,150,20,255} : Color{70,70,90,255}, (int)(30 * u)))
            g.numPlayers = n;
    }
    y += 80 * u;

    TxtC("Mode", cx, y, (int)(26 * u), WHITE);
    y += 38 * u;
    {
        Rectangle a{ cx - 190 * u, y, 180 * u, 56 * u };
        Rectangle b{ cx + 10 * u,  y, 180 * u, 56 * u };
        if (Btn(a, "Pass & Play", !g.vsComputer ? Color{230,150,20,255} : Color{70,70,90,255}, (int)(24 * u)))
            g.vsComputer = false;
        if (Btn(b, "vs Computer", g.vsComputer ? Color{230,150,20,255} : Color{70,70,90,255}, (int)(24 * u)))
            g.vsComputer = true;
    }
    y += 90 * u;
    Rectangle go{ cx - 120 * u, y, 240 * u, 70 * u };
    if (Btn(go, "START", Color{40,160,70,255}, (int)(36 * u)) || IsKeyPressed(KEY_ENTER)) StartGame();
    y += 90 * u;

    TxtC("Roll the dice, then close tiles that add up to the roll.", cx, y, (int)(18 * u), Color{230,230,230,255});
    TxtC("Can't move? Your open tiles are your score. Lowest score wins!", cx, y + 26 * u, (int)(18 * u), Color{230,230,230,255});
}

void DrawHUD() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth();
    const float H = (float)GetScreenHeight();
    const int seat = CurSeat();

    Txt("Q BOOL", 14 * u, 10 * u, (int)(30 * u), Color{255,210,70,255});

    // scoreboard (top-right)
    float bx = W - 210 * u, by = 10 * u;
    DrawRectangleRounded(Rectangle{bx - 8 * u, by - 4 * u, 206 * u, (g.numPlayers * 28 + 12) * u}, 0.15f, 6, Fade(BLACK, 0.45f));
    for (int i = 0; i < g.numPlayers; ++i) {
        const int s = g.seats[i];
        DrawRectangle((int)bx, (int)(by + (i * 28 + 4) * u), (int)(16 * u), (int)(16 * u), SEAT_COL[s]);
        char line[48];
        if (g.done[i]) std::snprintf(line, sizeof(line), "%s: score %d", SEAT_NAME[s], g.scores[i]);
        else           std::snprintf(line, sizeof(line), "%s: open %d", SEAT_NAME[s], g.boards[s].openSum());
        const bool isCur = (i == g.cur && g.state != State::GameOver);
        Txt(line, bx + 24 * u, by + (i * 28 + 2) * u, (int)(18 * u), isCur ? Color{255,230,120,255} : WHITE);
    }

    // turn banner
    char t[64];
    std::snprintf(t, sizeof(t), "%s's turn%s", SEAT_NAME[seat], IsBot(g.cur) ? " (computer)" : "");
    TxtC(t, W / 2, 12 * u, (int)(34 * u), SEAT_COL[seat].r > 200 && SEAT_COL[seat].g > 180 ? SEAT_COL[seat] : ColorBrightness(SEAT_COL[seat], 0.35f));

    // roll info
    if (g.rollTotal > 0 && g.rollT >= 1.0f) {
        char r[64];
        if (g.oneDie) std::snprintf(r, sizeof(r), "Roll: %d  (one die)", g.d1);
        else          std::snprintf(r, sizeof(r), "Roll: %d + %d = %d", g.d1, g.d2, g.rollTotal);
        TxtC(r, W / 2, 58 * u, (int)(28 * u), WHITE);
    }

    if (g.state == State::WaitRoll && !IsBot(g.cur)) {
        if (Btn(RollRect(), "ROLL", Color{220,120,20,255}, (int)(34 * u))) DoRoll();
    }
    if (g.state == State::Choose && !IsBot(g.cur)) {
        char h[80];
        std::snprintf(h, sizeof(h), "Tap tiles that add up to %d   (picked %d)", g.rollTotal, selectionSum(g.selected));
        TxtC(h, W / 2, H - 112 * u, (int)(22 * u), Color{255,235,150,255});
        if (Btn(ClearRect(), "CLEAR", Color{90,90,120,255}, (int)(26 * u))) g.selected = 0;
    }
    if (g.state == State::Pause && g.msg[0]) {
        const int fs = (int)(40 * u);
        const float w = MeasureText(g.msg, fs) + 60 * u;
        DrawRectangleRounded(Rectangle{W / 2 - w / 2, H / 2 - 40 * u, w, 80 * u}, 0.3f, 8, Fade(BLACK, 0.65f));
        TxtC(g.msg, W / 2, H / 2 - fs / 2.0f, fs, Color{255,225,110,255});
    }
#if defined(__EMSCRIPTEN__)
    if (H > W) TxtC("Tip: rotate your phone sideways", W / 2, H - 28 * u, (int)(16 * u), Fade(WHITE, 0.8f));
#endif
}

void DrawGameOver() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    DrawRectangle(0, 0, (int)W, (int)H, Fade(BLACK, 0.55f));
    int best = 1000;
    for (int i = 0; i < g.numPlayers; ++i) best = std::min(best, g.scores[i]);
    float y = H * 0.12f;
    TxtC("GAME OVER", W / 2, y, (int)(60 * u), Color{255,210,70,255});
    y += 90 * u;
    for (int i = 0; i < g.numPlayers; ++i) {
        const int s = g.seats[i];
        char line[64];
        std::snprintf(line, sizeof(line), "%s   %d%s", SEAT_NAME[s], g.scores[i], g.scores[i] == best ? "   WINNER!" : "");
        Color c = g.scores[i] == best ? Color{255,230,110,255} : WHITE;
        DrawRectangle((int)(W / 2 - 170 * u), (int)(y + 4 * u), (int)(22 * u), (int)(22 * u), SEAT_COL[s]);
        Txt(line, W / 2 - 135 * u, y, (int)(30 * u), c);
        y += 46 * u;
    }
    y += 24 * u;
    if (Btn(Rectangle{W / 2 - 130 * u, y, 260 * u, 66 * u}, "PLAY AGAIN", Color{40,160,70,255}, (int)(30 * u))
        || IsKeyPressed(KEY_ENTER)) ToMenu();
}

void Draw() {
    BeginDrawing();
    ClearBackground(Color{28,22,20,255});
    BeginMode3D(cam);
    DrawScene();
    EndMode3D();
    DrawTileNumbers();
    if (g.state == State::Menu)          DrawMenu();
    else if (g.state == State::GameOver) DrawGameOver();
    else                                 DrawHUD();
    EndDrawing();
}

void Frame() {
    float dt = GetFrameTime();
    if (dt > 0.05f) dt = 0.05f;
    Update(dt);
    Draw();
}

} // namespace

int main() {
    int w = 1280, h = 720;
#if defined(__EMSCRIPTEN__)
    w = EM_ASM_INT({ return window.innerWidth; });
    h = EM_ASM_INT({ return window.innerHeight; });
#endif
#if defined(__ANDROID__)
    w = 0; h = 0;   // 0,0 = use the whole phone/tablet screen
#endif
    SetConfigFlags(FLAG_MSAA_4X_HINT | FLAG_WINDOW_RESIZABLE | FLAG_VSYNC_HINT);
    InitWindow(w, h, "Q BOOL");
    SetTargetFPS(60);
    SetRandomSeed((unsigned int)std::time(nullptr));

    g.numPlayers = 4;
    for (int s = 0; s < 4; ++s)
        for (int n = 0; n <= NUM_TILES; ++n) g.angle[s][n] = g.boards[s].open[n] ? OPEN_ANG : 0.0f;
    cam.up = Vector3{0, 1, 0};

#if defined(__EMSCRIPTEN__)
    emscripten_set_main_loop(Frame, 0, 1);
#else
    while (!WindowShouldClose()) Frame();
#endif
    CloseWindow();
    return 0;
}
