// Unit tests for the pure game logic (no graphics). Run with: ctest
#include "game_logic.hpp"
#include <cmath>
#include <cstdio>
#include <cstdlib>

static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static uint16_t bit(int n) { return (uint16_t)(1u << n); }

int main() {
    Board b;
    CHECK(b.openCount() == 12 && !b.allShut());

    // dice 2 and 4: close 2+4, or close 6
    auto o = findOptions(b, 2, 4);
    CHECK(o.size() == 2 && o[0] == (bit(2) | bit(4)) && o[1] == bit(6));

    // the player closes 2 and 4, then rolls 3 and 4: 4 is closed -> only 3, or 7
    b.open[2] = false; b.open[4] = false;
    o = findOptions(b, 3, 4);
    CHECK(o.size() == 2 && o[0] == bit(3) && o[1] == bit(7));

    // doubles: close the tile, or the sum
    Board c;
    o = findOptions(c, 3, 3);
    CHECK(o.size() == 2 && o[0] == bit(3) && o[1] == bit(6));
    // double 6: tile 6 or tile 12
    o = findOptions(c, 6, 6);
    CHECK(o.size() == 2 && o[0] == bit(6) && o[1] == bit(12));

    // no move
    Board d; d.open.fill(false);
    CHECK(findOptions(d, 2, 3).empty() && d.allShut());
    Board e; e.open.fill(false); e.open[1] = true;     // only tile 1 left
    CHECK(findOptions(e, 3, 4).empty());
    CHECK(findOptions(e, 1, 4).size() == 1);

    // sum 7 closed, dice tiles open
    Board f; f.open[7] = false;
    o = findOptions(f, 3, 4);
    CHECK(o.size() == 1 && o[0] == (bit(3) | bit(4)));

    // DP sanity
    CHECK(std::fabs(expectedRolls(0)) < 1e-6f);
    const float full = expectedRolls(c.openMask());
    std::printf("expected rolls to shut the box (optimal): %.2f\n", full);
    CHECK(full > 5.0f && full < 200.0f);
    CHECK(expectedRolls(bit(1)) > 1.0f);

    // bots return a legal option
    auto opts = findOptions(c, 1, 4);
    for (int diff = 0; diff < 3; ++diff) {
        uint16_t p = botPick(c, opts, (Difficulty)diff, 0.7f);
        bool ok = false; for (auto x : opts) if (x == p) ok = true;
        CHECK(ok);
    }

    // Monte-Carlo: rolls needed to finish, per difficulty (lower is better)
    auto play = [](Difficulty diff, unsigned seed) {
        std::srand(seed);
        double total = 0; const int N = 3000;
        for (int g = 0; g < N; ++g) {
            Board bd; int rolls = 0;
            while (!bd.allShut() && rolls < 5000) {
                ++rolls;
                auto op = findOptions(bd, std::rand() % 6 + 1, std::rand() % 6 + 1);
                if (op.empty()) continue;
                uint16_t pick = botPick(bd, op, diff, (float)(std::rand() % 1000) / 1000.0f);
                for (int n = 1; n <= NUM_TILES; ++n) if (pick & (1u << n)) bd.open[n] = false;
            }
            total += rolls;
        }
        return total / N;
    };
    double easy = play(Difficulty::Easy, 1), normal = play(Difficulty::Normal, 1), hard = play(Difficulty::Hard, 1);
    std::printf("avg rolls to win  easy=%.2f normal=%.2f hard=%.2f (DP %.2f)\n", easy, normal, hard, full);
    CHECK(hard <= normal + 0.3);
    CHECK(normal <= easy + 0.3);
    CHECK(std::fabs(hard - full) < 1.5);

    if (fails == 0) std::printf("ALL TESTS PASSED\n");
    return fails == 0 ? 0 : 1;
}
