// Q BOOL - particle effects (sparks, confetti, dust puffs, floating light motes).
#pragma once
#include "raylib.h"
#include "raymath.h"
#include "rlgl.h"

#include <algorithm>
#include <cmath>
#include <vector>

namespace fx {

enum class Kind { Spark, Confetti, Puff, Mote };

struct Particle {
    Vector3 pos{}, vel{};
    float life = 0, maxLife = 1, size = 0.1f, rot = 0, rotV = 0;
    Color col{255, 255, 255, 255};
    Kind kind = Kind::Spark;
};

inline std::vector<Particle> list;

inline float Rnd(float a, float b) { return a + (float)GetRandomValue(0, 10000) / 10000.0f * (b - a); }

inline void Clear() { list.clear(); }

inline void Add(const Particle& p) { if (list.size() < 1400) list.push_back(p); }

// Gold / coloured sparks flying out of a point.
inline void Sparks(Vector3 p, int n, Color c) {
    for (int i = 0; i < n; ++i) {
        Particle q;
        q.kind = Kind::Spark;
        q.pos = p;
        const float a = Rnd(0.0f, 6.2831853f), s = Rnd(1.0f, 3.6f);
        q.vel = Vector3{ cosf(a) * s, Rnd(2.0f, 5.5f), sinf(a) * s };
        q.maxLife = q.life = Rnd(0.45f, 0.95f);
        q.size = Rnd(0.10f, 0.20f);
        q.col = c;
        Add(q);
    }
}

// Coloured paper falling from above the table.
inline void Confetti(int n, float spread = 6.5f) {
    static const Color pal[6] = { {255, 90, 90, 255}, {255, 210, 60, 255}, {80, 200, 120, 255},
                                  {80, 150, 255, 255}, {255, 130, 210, 255}, {255, 255, 255, 255} };
    for (int i = 0; i < n; ++i) {
        Particle q;
        q.kind = Kind::Confetti;
        q.pos = Vector3{ Rnd(-spread, spread), Rnd(7.0f, 12.0f), Rnd(-spread, spread) };
        q.vel = Vector3{ Rnd(-0.8f, 0.8f), Rnd(-1.5f, -0.2f), Rnd(-0.8f, 0.8f) };
        q.maxLife = q.life = Rnd(4.0f, 6.5f);
        q.size = Rnd(0.10f, 0.17f);
        q.rot = Rnd(0.0f, 6.28f);
        q.rotV = Rnd(-6.0f, 6.0f);
        q.col = pal[GetRandomValue(0, 5)];
        Add(q);
    }
}

// Dust cloud when a die hits the board.
inline void Puff(Vector3 p, int n) {
    for (int i = 0; i < n; ++i) {
        Particle q;
        q.kind = Kind::Puff;
        q.pos = Vector3{ p.x + Rnd(-0.25f, 0.25f), p.y, p.z + Rnd(-0.25f, 0.25f) };
        const float a = Rnd(0.0f, 6.2831853f), s = Rnd(0.3f, 1.1f);
        q.vel = Vector3{ cosf(a) * s, Rnd(0.1f, 0.5f), sinf(a) * s };
        q.maxLife = q.life = Rnd(0.5f, 0.9f);
        q.size = Rnd(0.25f, 0.45f);
        q.col = Color{ 235, 215, 180, 255 };
        Add(q);
    }
}

// Ambient dust floating in the light of the lamp.
inline void ResetMote(Particle& q, bool anyHeight) {
    q.kind = Kind::Mote;
    q.pos = Vector3{ Rnd(-8.0f, 8.0f), anyHeight ? Rnd(0.8f, 7.0f) : Rnd(0.8f, 1.6f), Rnd(-8.0f, 8.0f) };
    q.vel = Vector3{ Rnd(-0.12f, 0.12f), Rnd(0.03f, 0.16f), Rnd(-0.12f, 0.12f) };
    q.maxLife = q.life = Rnd(6.0f, 12.0f);
    q.size = Rnd(0.035f, 0.075f);
    q.col = Color{ 255, 226, 170, 255 };
}
inline void SeedMotes(int n = 55) {
    for (int i = 0; i < n; ++i) { Particle q; ResetMote(q, true); q.life = Rnd(0.5f, q.maxLife); Add(q); }
}

inline void Update(float dt) {
    for (size_t i = 0; i < list.size();) {
        Particle& p = list[i];
        p.life -= dt;
        if (p.life <= 0.0f) {
            if (p.kind == Kind::Mote) { ResetMote(p, false); ++i; continue; }
            list[i] = list.back();
            list.pop_back();
            continue;
        }
        switch (p.kind) {
        case Kind::Spark:
            p.vel.y -= 9.0f * dt;
            p.pos = Vector3Add(p.pos, Vector3Scale(p.vel, dt));
            if (p.pos.y < 0.5f) { p.pos.y = 0.5f; p.vel.y = fabsf(p.vel.y) * 0.3f; p.vel.x *= 0.6f; p.vel.z *= 0.6f; }
            break;
        case Kind::Confetti: {
            p.vel.y = std::max(p.vel.y - 2.2f * dt, -2.4f);
            p.vel.x += sinf(p.rot * 0.7f) * 1.4f * dt;
            p.vel.z += cosf(p.rot * 0.5f) * 1.4f * dt;
            p.rot += p.rotV * dt;
            p.pos = Vector3Add(p.pos, Vector3Scale(p.vel, dt));
            if (p.pos.y < 0.52f) { p.pos.y = 0.52f; p.vel = Vector3{ 0, 0, 0 }; p.rotV = 0.0f; p.life = std::min(p.life, 1.2f); }
            break;
        }
        case Kind::Puff:
            p.pos = Vector3Add(p.pos, Vector3Scale(p.vel, dt));
            p.vel = Vector3Scale(p.vel, 1.0f - std::min(1.0f, dt * 2.5f));
            p.size += dt * 0.5f;
            break;
        case Kind::Mote:
            p.pos = Vector3Add(p.pos, Vector3Scale(p.vel, dt));
            p.vel.x += sinf((float)GetTime() * 0.7f + p.pos.z) * 0.02f * dt;
            break;
        }
        ++i;
    }
}

inline void Quad(Vector3 c, Vector3 rv, Vector3 uv, float hw, float hh, Color col) {
    rlColor4ub(col.r, col.g, col.b, col.a);
    const Vector3 a = Vector3Add(c, Vector3Add(Vector3Scale(rv, -hw), Vector3Scale(uv,  hh)));
    const Vector3 b = Vector3Add(c, Vector3Add(Vector3Scale(rv, -hw), Vector3Scale(uv, -hh)));
    const Vector3 d = Vector3Add(c, Vector3Add(Vector3Scale(rv,  hw), Vector3Scale(uv, -hh)));
    const Vector3 e = Vector3Add(c, Vector3Add(Vector3Scale(rv,  hw), Vector3Scale(uv,  hh)));
    rlTexCoord2f(0.0f, 0.0f); rlVertex3f(a.x, a.y, a.z);
    rlTexCoord2f(0.0f, 1.0f); rlVertex3f(b.x, b.y, b.z);
    rlTexCoord2f(1.0f, 1.0f); rlVertex3f(d.x, d.y, d.z);
    rlTexCoord2f(1.0f, 0.0f); rlVertex3f(e.x, e.y, e.z);
}

// Draw all particles as camera-facing quads. Call inside BeginMode3D().
inline void Draw(const Camera3D& cam, const Texture2D& glow) {
    const Vector3 fwd = Vector3Normalize(Vector3Subtract(cam.target, cam.position));
    const Vector3 R = Vector3Normalize(Vector3CrossProduct(fwd, cam.up));
    const Vector3 U = Vector3CrossProduct(R, fwd);

    rlDrawRenderBatchActive();
    rlDisableDepthMask();
    rlDisableBackfaceCulling();

    // pass 0: soft glowing particles (additive), pass 1: puffs (normal alpha), pass 2: confetti paper
    for (int pass = 0; pass < 3; ++pass) {
        if (pass == 0) BeginBlendMode(BLEND_ADDITIVE);
        if (pass == 1) { EndBlendMode(); }
        rlSetTexture(pass == 2 ? 0 : glow.id);
        rlBegin(RL_QUADS);
        for (const Particle& p : list) {
            const float k = Clamp(p.life / p.maxLife, 0.0f, 1.0f);
            if (pass == 0 && (p.kind == Kind::Spark || p.kind == Kind::Mote)) {
                float a = (p.kind == Kind::Spark) ? k : 0.16f * sinf(3.14159f * (1.0f - k));
                Color c = p.col; c.a = (unsigned char)(255.0f * Clamp(a, 0.0f, 1.0f));
                const float s = p.size * (p.kind == Kind::Spark ? (0.6f + 0.8f * k) : 1.0f);
                Quad(p.pos, R, U, s, s, c);
            } else if (pass == 1 && p.kind == Kind::Puff) {
                Color c = p.col; c.a = (unsigned char)(255.0f * 0.38f * k);
                Quad(p.pos, R, U, p.size, p.size, c);
            } else if (pass == 2 && p.kind == Kind::Confetti) {
                const float cr = cosf(p.rot), sr = sinf(p.rot);
                const Vector3 rv = Vector3Add(Vector3Scale(R, cr), Vector3Scale(U, sr));
                const Vector3 uv = Vector3Add(Vector3Scale(R, -sr), Vector3Scale(U, cr));
                const float flip = 0.15f + 0.85f * fabsf(cosf(p.rot * 1.7f + 1.0f));
                Color c = p.col; c.a = (unsigned char)(255.0f * Clamp(k * 3.0f, 0.0f, 1.0f));
                Quad(p.pos, rv, uv, p.size, p.size * 0.55f * flip, c);
            }
        }
        rlEnd();
    }
    rlSetTexture(0);
    rlDrawRenderBatchActive();
    rlEnableBackfaceCulling();
    rlEnableDepthMask();
}

} // namespace fx
