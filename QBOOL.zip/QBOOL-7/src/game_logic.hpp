// Q BOOL - pure game logic (no graphics, no raylib) so it can be unit-tested.
//
// RULES
//  * Tiles 1..10 start open. Roll two dice (a, b).
//  * You may close the tile(s) of the dice  -> tile a and tile b (only those still open),
//    OR close the SUM tile a+b (if it is still open).
//  * Closed tiles stay closed. After a move you roll again (same player).
//  * If you cannot move at all, the turn passes to the next player.
//  * The first player to close all 10 tiles wins.  (A sum of 11 or 12 has no tile: it cannot be played.)
#pragma once
#include <array>
#include <cstdint>
#include <vector>

constexpr int NUM_TILES = 10;
constexpr unsigned MASK_SIZE = 1u << (NUM_TILES + 1);    // open-masks: bit n = tile n, bit 0 unused
constexpr unsigned MASK_ALL  = MASK_SIZE - 2u;           // bits 1..NUM_TILES

enum class Difficulty { Easy = 0, Normal = 1, Hard = 2 };

struct Board {
    std::array<bool, NUM_TILES + 1> open{};   // index 1..NUM_TILES

    Board() { reset(); }
    void reset() { open.fill(true); open[0] = false; }
    void shutAll() { open.fill(false); }

    int openCount() const {
        int c = 0;
        for (int n = 1; n <= NUM_TILES; ++n) if (open[n]) ++c;
        return c;
    }
    bool allShut() const { return openCount() == 0; }
    // Bit n set = tile n is still OPEN (bit 0 unused).
    uint16_t openMask() const {
        uint16_t m = 0;
        for (int n = 1; n <= NUM_TILES; ++n) if (open[n]) m |= (uint16_t)(1u << n);
        return m;
    }
};

// Legal moves for the dice (d1, d2). Each option is a bit mask: bit n set = tile n gets closed.
//   option "dice": the still-open tiles among d1 and d2 (one or two tiles)
//   option "sum" : tile d1+d2, if open
inline std::vector<uint16_t> findOptions(const Board& b, int d1, int d2) {
    std::vector<uint16_t> out;
    uint16_t dice = 0;
    if (d1 >= 1 && d1 <= NUM_TILES && b.open[d1]) dice |= (uint16_t)(1u << d1);
    if (d2 >= 1 && d2 <= NUM_TILES && b.open[d2]) dice |= (uint16_t)(1u << d2);
    if (dice) out.push_back(dice);
    const int total = d1 + d2;
    if (total >= 1 && total <= NUM_TILES && b.open[total]) {
        const uint16_t s = (uint16_t)(1u << total);
        if (s != dice) out.push_back(s);
    }
    return out;
}

// ---------------------------------------------------------------- AI
// Expected number of rolls a lone player needs to close every tile when playing
// optimally (dynamic programming over all 2^NUM_TILES boards). The Hard computer and the
// hint star use it: always pick the move that leaves the smallest expectation.
namespace detail {
inline const std::array<float, MASK_SIZE>& expectTable() {
    static const std::array<float, MASK_SIZE> table = [] {
        std::array<double, MASK_SIZE> e{};
        for (unsigned m = 2; m < MASK_SIZE; m += 2) {          // bit 0 is never set; m == 0 -> 0 rolls
            double stay = 0.0, sum = 0.0;                  // probability of "no move", weighted sum of moves
            for (int a = 1; a <= 6; ++a)
                for (int b = 1; b <= 6; ++b) {
                    unsigned dice = 0;
                    if (m & (1u << a)) dice |= 1u << a;
                    if (m & (1u << b)) dice |= 1u << b;
                    const int t = a + b;
                    bool any = false;
                    double best = 1e18;
                    if (dice) { any = true; best = e[m & ~dice]; }
                    if (t <= NUM_TILES && (m & (1u << t)) && (1u << t) != dice) {
                        any = true;
                        const double v = e[m & ~(1u << t)];
                        if (v < best) best = v;
                    }
                    if (!any) stay += 1.0 / 36.0;
                    else      sum += best / 36.0;
                }
            e[m] = (1.0 + sum) / (1.0 - stay);
        }
        std::array<float, MASK_SIZE> f{};
        for (size_t i = 0; i < f.size(); ++i) f[i] = (float)e[i];
        return f;
    }();
    return table;
}
} // namespace detail

// Expected rolls still needed to shut the box from this open-mask.
inline float expectedRolls(uint16_t openMask) { return detail::expectTable()[openMask & MASK_ALL]; }

// Index of the best option according to the optimal strategy (-1 if none).
inline int bestOptionIndex(const Board& b, const std::vector<uint16_t>& combos) {
    int best = -1;
    float bestV = 1e9f;
    const uint16_t m = b.openMask();
    for (size_t i = 0; i < combos.size(); ++i) {
        const float v = expectedRolls((uint16_t)(m & ~combos[i]));
        if (v < bestV) { bestV = v; best = (int)i; }
    }
    return best;
}

// Computer player. `rnd` is a random number in [0,1) supplied by the caller.
//   Easy   - picks at random
//   Normal - plays the optimal move but slips up ~35% of the time
//   Hard   - always plays the optimal move
inline uint16_t botPick(const Board& b, const std::vector<uint16_t>& combos, Difficulty d, float rnd) {
    if (combos.empty()) return 0;
    auto randomOne = [&](float r) {
        size_t i = (size_t)(r * (float)combos.size());
        return combos[i >= combos.size() ? combos.size() - 1 : i];
    };
    if (d == Difficulty::Easy) return randomOne(rnd);
    if (d == Difficulty::Normal && rnd < 0.35f) return randomOne(rnd / 0.35f);
    const int i = bestOptionIndex(b, combos);
    return combos[(size_t)(i < 0 ? 0 : i)];
}
