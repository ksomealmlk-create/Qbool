// Q BOOL - graphics module.
// Everything is generated at start-up (no image files): wood / felt / lacquer / stone
// textures, rounded meshes, an embedded UI font, a lit shader with real-time
// shadow mapping, glossy reflections and a warm hanging-lamp light.
#pragma once
#include "raylib.h"
#include "raymath.h"
#include "rlgl.h"
#include "font_data.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>

namespace gfx {

constexpr float PI_F = 3.14159265f;

inline float Clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

// ------------------------------------------------------------ procedural noise
inline float HashF(int x, int y, int seed) {
    unsigned h = (unsigned)x * 374761393u + (unsigned)y * 668265263u + (unsigned)seed * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    h ^= h >> 16;
    return (float)(h & 0xFFFFFFu) / 16777215.0f;
}
inline float SmoothF(float t) { return t * t * (3.0f - 2.0f * t); }
inline float VNoise(float x, float y, int px, int py, int seed) {
    const int xi = (int)floorf(x), yi = (int)floorf(y);
    const float fx = x - xi, fy = y - yi;
    const int x0 = ((xi % px) + px) % px, x1 = (((xi + 1) % px) + px) % px;
    const int y0 = ((yi % py) + py) % py, y1 = (((yi + 1) % py) + py) % py;
    const float a = HashF(x0, y0, seed), b = HashF(x1, y0, seed);
    const float c = HashF(x0, y1, seed), d = HashF(x1, y1, seed);
    const float u = SmoothF(fx), v = SmoothF(fy);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
inline float FBM(float x, float y, int px, int py, int oct, int seed) {   // tileable noise
    float sum = 0.0f, amp = 0.5f, norm = 0.0f;
    for (int o = 0; o < oct; ++o) {
        sum += amp * VNoise(x, y, px, py, seed + o);
        norm += amp;
        x *= 2.0f; y *= 2.0f; px *= 2; py *= 2; amp *= 0.5f;
    }
    return sum / norm;
}
inline unsigned char Byte(float v) { return (unsigned char)(Clampf(v, 0.0f, 1.0f) * 255.0f); }

inline Texture2D FinishTexture(Image img) {
    Texture2D t = LoadTextureFromImage(img);
    UnloadImage(img);
    GenTextureMipmaps(&t);
    SetTextureFilter(t, TEXTURE_FILTER_TRILINEAR);
    SetTextureWrap(t, TEXTURE_WRAP_REPEAT);
    return t;
}

inline Texture2D MakeWoodTex(int S) {
    Image img = GenImageColor(S, S, WHITE);
    Color* px = (Color*)img.data;
    for (int y = 0; y < S; ++y) {
        for (int x = 0; x < S; ++x) {
            const float u = (float)x / S, v = (float)y / S;
            const float warp   = FBM(u * 2.0f, v * 3.0f, 2, 3, 3, 11);
            const float rings  = 0.5f + 0.5f * sinf((v * 14.0f + warp * 5.0f) * 2.0f * PI_F);
            const float streak = FBM(u * 3.0f, v * 60.0f, 3, 60, 3, 23);
            const float pores  = FBM(u * 40.0f, v * 220.0f, 40, 220, 2, 77);
            float t = 0.38f * rings + 0.52f * streak + 0.10f * pores;
            t = t * 0.92f + HashF(x, y, 5) * 0.05f;
            const float r = 88.0f + (172.0f - 88.0f) * t;
            const float g = 54.0f + (116.0f - 54.0f) * t;
            const float b = 30.0f + (68.0f - 30.0f) * t;
            px[y * S + x] = Color{ Byte(r / 255.0f), Byte(g / 255.0f), Byte(b / 255.0f), 255 };
        }
    }
    return FinishTexture(img);
}
inline Texture2D MakeFeltTex(int S) {
    Image img = GenImageColor(S, S, WHITE);
    Color* px = (Color*)img.data;
    for (int y = 0; y < S; ++y)
        for (int x = 0; x < S; ++x) {
            const float u = (float)x / S, v = (float)y / S;
            const float n = 0.78f + 0.14f * HashF(x, y, 9) + 0.20f * (FBM(u * 8.0f, v * 8.0f, 8, 8, 3, 31) - 0.5f);
            const unsigned char c = Byte(n);
            px[y * S + x] = Color{ c, c, c, 255 };
        }
    return FinishTexture(img);
}
inline Texture2D MakePaintTex(int S) {          // lacquered wood grain (tinted by colour)
    Image img = GenImageColor(S, S, WHITE);
    Color* px = (Color*)img.data;
    for (int y = 0; y < S; ++y)
        for (int x = 0; x < S; ++x) {
            const float u = (float)x / S, v = (float)y / S;
            const float n = 0.86f + 0.14f * FBM(u * 2.0f, v * 40.0f, 2, 40, 3, 41) + 0.03f * HashF(x, y, 7);
            const unsigned char c = Byte(n);
            px[y * S + x] = Color{ c, c, c, 255 };
        }
    return FinishTexture(img);
}
inline Texture2D MakeStoneTex(int S) {          // mottled glazed stone (dice)
    Image img = GenImageColor(S, S, WHITE);
    Color* px = (Color*)img.data;
    for (int y = 0; y < S; ++y)
        for (int x = 0; x < S; ++x) {
            const float u = (float)x / S, v = (float)y / S;
            const float n = 0.70f + 0.30f * FBM(u * 6.0f, v * 6.0f, 6, 6, 4, 51) + 0.05f * (HashF(x, y, 3) - 0.5f);
            const unsigned char c = Byte(n);
            px[y * S + x] = Color{ c, c, c, 255 };
        }
    return FinishTexture(img);
}

// Soft radial sprite. black=true -> contact shadow, false -> white glow.
inline Texture2D MakeSoftTex(int S, bool black, float power) {
    Image img = GenImageColor(S, S, BLANK);
    Color* px = (Color*)img.data;
    for (int y = 0; y < S; ++y)
        for (int x = 0; x < S; ++x) {
            const float dx = (x + 0.5f) / S * 2.0f - 1.0f, dy = (y + 0.5f) / S * 2.0f - 1.0f;
            const float r = sqrtf(dx * dx + dy * dy);
            const float a = r >= 1.0f ? 0.0f : powf(1.0f - r, power);
            const unsigned char c = black ? 0 : 255;
            px[y * S + x] = Color{ c, c, c, Byte(a) };
        }
    Texture2D t = LoadTextureFromImage(img);
    UnloadImage(img);
    SetTextureFilter(t, TEXTURE_FILTER_BILINEAR);
    SetTextureWrap(t, TEXTURE_WRAP_CLAMP);
    return t;
}

// Dark edges for a cinematic look (drawn over the 3D view, under the UI).
inline Texture2D MakeVignetteTex(int S) {
    Image img = GenImageColor(S, S, BLANK);
    Color* px = (Color*)img.data;
    for (int y = 0; y < S; ++y)
        for (int x = 0; x < S; ++x) {
            const float dx = (x + 0.5f) / S * 2.0f - 1.0f, dy = (y + 0.5f) / S * 2.0f - 1.0f;
            const float r = sqrtf(dx * dx + dy * dy) / 1.4142f;
            const float a = SmoothF(Clampf((r - 0.42f) / 0.62f, 0.0f, 1.0f)) * 0.72f;
            px[y * S + x] = Color{ 6, 3, 2, Byte(a) };
        }
    Texture2D t = LoadTextureFromImage(img);
    UnloadImage(img);
    SetTextureFilter(t, TEXTURE_FILTER_BILINEAR);
    SetTextureWrap(t, TEXTURE_WRAP_CLAMP);
    return t;
}

// Atlas with the tile numbers (8 x 8 cells of 128 px). Variant 0 = white (open tile),
// 1 = dark (selected tile), 2 = engraved (closed tile). Cell index = variant * 12 + (n - 1).
inline Texture2D MakeNumberAtlas(Font f) {
    const int S = 1024, C = 128;
    Image img = GenImageColor(S, S, BLANK);
    for (int variant = 0; variant < 3; ++variant) {
        for (int n = 1; n <= 12; ++n) {
            const int idx = variant * 12 + (n - 1);
            const int cx = idx % 8, cy = idx / 8;
            char s[4];
            std::snprintf(s, sizeof(s), "%d", n);
            const float size = 80.0f;     // = font base size: no resampling blur
            const Vector2 m = MeasureTextEx(f, s, size, 0.0f);
            const Vector2 pos = { cx * (float)C + (C - m.x) * 0.5f, cy * (float)C + (C - m.y) * 0.5f };
            Color mainC, outC;
            if (variant == 0)      { mainC = Color{255, 255, 255, 255}; outC = Color{25, 16, 10, 235}; }
            else if (variant == 1) { mainC = Color{30, 20, 12, 255};    outC = Color{255, 232, 180, 215}; }
            else                   { mainC = Color{66, 44, 30, 255};    outC = Color{175, 135, 98, 140}; }
            static const int OX[8] = { -3, 0, 3, -3, 3, -3, 0, 3 };
            static const int OY[8] = { -3, -3, -3, 0, 0, 3, 3, 3 };
            for (int k = 0; k < 8; ++k)
                ImageDrawTextEx(&img, f, s, Vector2{ pos.x + OX[k], pos.y + OY[k] }, size, 0.0f, outC);
            ImageDrawTextEx(&img, f, s, pos, size, 0.0f, mainC);
        }
    }
    Texture2D t = LoadTextureFromImage(img);
    UnloadImage(img);
    GenTextureMipmaps(&t);
    SetTextureFilter(t, TEXTURE_FILTER_TRILINEAR);
    SetTextureWrap(t, TEXTURE_WRAP_CLAMP);
    return t;
}

// ------------------------------------------------------------ meshes
// Box with rounded edges: cube surface projected on an inner box + sphere radius r.
inline Mesh MakeRoundedBox(float sx, float sy, float sz, float r, int N, float uvSize) {
    Mesh m = {};
    const int vper = (N + 1) * (N + 1);
    m.vertexCount = 6 * vper;
    m.triangleCount = 6 * N * N * 2;
    m.vertices  = (float*)MemAlloc(m.vertexCount * 3 * sizeof(float));
    m.normals   = (float*)MemAlloc(m.vertexCount * 3 * sizeof(float));
    m.texcoords = (float*)MemAlloc(m.vertexCount * 2 * sizeof(float));
    m.indices   = (unsigned short*)MemAlloc(m.triangleCount * 3 * sizeof(unsigned short));
    const float half[3] = { sx * 0.5f, sy * 0.5f, sz * 0.5f };
    int vi = 0, ii = 0;
    for (int f = 0; f < 6; ++f) {
        const int axis = f / 2;
        const float sign = (f % 2) ? -1.0f : 1.0f;
        const int a1 = (axis + 1) % 3, a2 = (axis + 2) % 3;
        const int base = f * vper;
        for (int j = 0; j <= N; ++j) {
            for (int i = 0; i <= N; ++i) {
                const float s = -1.0f + 2.0f * i / N, t = -1.0f + 2.0f * j / N;
                float p[3];
                p[axis] = sign;
                p[a1] = sinf(s * PI_F * 0.5f);
                p[a2] = sinf(t * PI_F * 0.5f);
                float pos[3], nrm[3], d[3];
                float len = 0.0f;
                for (int k = 0; k < 3; ++k) {
                    const float q = p[k] * half[k];
                    const float lim = half[k] - r;
                    const float in = Clampf(q, -lim, lim);
                    d[k] = q - in;
                    pos[k] = in;
                    len += d[k] * d[k];
                }
                len = sqrtf(len);
                for (int k = 0; k < 3; ++k) nrm[k] = 0.0f;
                if (len > 1e-5f) { for (int k = 0; k < 3; ++k) nrm[k] = d[k] / len; }
                else nrm[axis] = sign;
                for (int k = 0; k < 3; ++k) pos[k] += nrm[k] * r;
                m.vertices[vi * 3 + 0] = pos[0];
                m.vertices[vi * 3 + 1] = pos[1];
                m.vertices[vi * 3 + 2] = pos[2];
                m.normals[vi * 3 + 0] = nrm[0];
                m.normals[vi * 3 + 1] = nrm[1];
                m.normals[vi * 3 + 2] = nrm[2];
                m.texcoords[vi * 2 + 0] = pos[a1] / uvSize;
                m.texcoords[vi * 2 + 1] = pos[a2] / uvSize;
                ++vi;
            }
        }
        for (int j = 0; j < N; ++j) {
            for (int i = 0; i < N; ++i) {
                const int v00 = base + j * (N + 1) + i, v10 = v00 + 1;
                const int v01 = v00 + (N + 1), v11 = v01 + 1;
                if (sign > 0) {
                    m.indices[ii++] = (unsigned short)v00; m.indices[ii++] = (unsigned short)v10; m.indices[ii++] = (unsigned short)v11;
                    m.indices[ii++] = (unsigned short)v00; m.indices[ii++] = (unsigned short)v11; m.indices[ii++] = (unsigned short)v01;
                } else {
                    m.indices[ii++] = (unsigned short)v00; m.indices[ii++] = (unsigned short)v11; m.indices[ii++] = (unsigned short)v10;
                    m.indices[ii++] = (unsigned short)v00; m.indices[ii++] = (unsigned short)v01; m.indices[ii++] = (unsigned short)v11;
                }
            }
        }
    }
    UploadMesh(&m, false);
    return m;
}

// ------------------------------------------------------------ shaders
// GLSL 330 on desktop, GLSL 100 (ES2) on Android / Web.
#if defined(__ANDROID__) || defined(__EMSCRIPTEN__)
inline const char* VS_HEAD = "#version 100\n#define ATTR attribute\n#define VOUT varying\n";
inline const char* FS_HEAD = "#version 100\n#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n#define VIN varying\n#define TEX texture2D\n#define FRAGOUT\n#define SETCOL(c) gl_FragColor = (c)\n";
#else
inline const char* VS_HEAD = "#version 330\n#define ATTR in\n#define VOUT out\n";
inline const char* FS_HEAD = "#version 330\n#define VIN in\n#define TEX texture\n#define FRAGOUT out vec4 finalColor;\n#define SETCOL(c) finalColor = (c)\n";
#endif

inline const char* VS_LIT = R"GLSL(
ATTR vec3 vertexPosition;
ATTR vec2 vertexTexCoord;
ATTR vec3 vertexNormal;
uniform mat4 mvp;
uniform mat4 matModel;
uniform mat4 matNormal;
uniform mat4 lightVP;
VOUT vec3 fragPos;
VOUT vec2 fragUV;
VOUT vec3 fragN;
VOUT vec4 fragLS;
void main() {
    fragPos = vec3(matModel * vec4(vertexPosition, 1.0));
    fragUV = vertexTexCoord;
    fragN = normalize(vec3(matNormal * vec4(vertexNormal, 0.0)));
    fragLS = lightVP * vec4(fragPos + fragN * 0.035, 1.0);
    gl_Position = mvp * vec4(vertexPosition, 1.0);
}
)GLSL";

inline const char* FS_LIT = R"GLSL(
VIN vec3 fragPos;
VIN vec2 fragUV;
VIN vec3 fragN;
VIN vec4 fragLS;
uniform sampler2D texture0;
uniform sampler2D shadowMap;
uniform vec4 colDiffuse;
uniform vec3 viewPos;
uniform vec3 lightDir;
uniform vec3 matParams;     // x = reflectivity / specular strength, y = shininess, z = metalness
uniform float uvScale;
uniform vec3 glow;
uniform float shadowOn;
uniform float shadowTexel;
FRAGOUT

float unpackDepth(vec4 c) {
    return dot(c, vec4(1.0, 1.0 / 255.0, 1.0 / 65025.0, 1.0 / 16581375.0));
}

float shadowFactor(vec3 N, vec3 L) {
    if (shadowOn < 0.5) return 1.0;
    vec3 p = fragLS.xyz / fragLS.w * 0.5 + 0.5;
    if (p.x < 0.003 || p.x > 0.997 || p.y < 0.003 || p.y > 0.997 || p.z > 0.999) return 1.0;
    float ndl = max(dot(N, L), 0.0);
    float bias = 0.0010 + 0.0035 * (1.0 - ndl);
    float lit = 0.0;
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            float d = unpackDepth(TEX(shadowMap, p.xy + vec2(float(i), float(j)) * shadowTexel));
            lit += (p.z - bias > d) ? 0.0 : 1.0;
        }
    }
    return lit / 9.0;
}

void main() {
    vec3 N = normalize(fragN);
    vec3 V = normalize(viewPos - fragPos);
    vec3 albedo = TEX(texture0, fragUV * uvScale).rgb * colDiffuse.rgb;
    vec3 L1 = normalize(lightDir);
    vec3 L2 = normalize(vec3(-0.55, 0.45, -0.45));

    float sh = shadowFactor(N, L1);
    float d1 = max(dot(N, L1), 0.0) * sh;
    float d2 = max(dot(N, L2), 0.0);

    // warm lamp hanging above the table centre (soft, no shadows)
    vec3 Lp = vec3(0.0, 9.0, 0.0) - fragPos;
    float dist = length(Lp);
    vec3 Ll = Lp / dist;
    float dl = max(dot(N, Ll), 0.0) / (1.0 + 0.012 * dist * dist);
    float pool = 1.0 - 0.55 * smoothstep(7.0, 24.0, length(fragPos.xz));   // light pool on the table

    float hemi = 0.5 + 0.5 * N.y;
    vec3 amb = mix(vec3(0.20, 0.17, 0.15), vec3(0.40, 0.42, 0.48), hemi);

    vec3 H = normalize(L1 + V);
    float spec = pow(max(dot(N, H), 0.0), matParams.y) * matParams.x * step(0.001, d1);

    // glossy environment reflection (analytic sky + soft-box + lamp)
    vec3 R = reflect(-V, N);
    float up = smoothstep(-0.15, 0.75, R.y);
    vec3 env = mix(vec3(0.07, 0.05, 0.04), vec3(0.50, 0.57, 0.70), up);
    env += vec3(1.0, 0.93, 0.82) * pow(max(dot(R, L1), 0.0), 18.0) * 1.1 * mix(0.35, 1.0, sh);
    env += vec3(1.0, 0.82, 0.55) * pow(max(dot(R, Ll), 0.0), 40.0) * 0.6;
    float fres = pow(1.0 - max(dot(N, V), 0.0), 5.0);
    float refl = matParams.x * (0.06 + 0.94 * fres);
    vec3 reflCol = mix(vec3(1.0), albedo * 2.2, matParams.z);

    vec3 col = albedo * (amb + vec3(1.00, 0.93, 0.82) * d1 + vec3(0.20, 0.26, 0.36) * d2 + vec3(1.0, 0.78, 0.50) * dl * 0.55);
    col += vec3(1.0, 0.96, 0.88) * spec;
    col += env * reflCol * refl * 0.8;
    col += glow;
    col *= pool;
    col = col / (1.0 + 0.12 * col);
    col = clamp(col, 0.0, 1.0);
    col = mix(col, col * col * (3.0 - 2.0 * col), 0.20);   // gentle contrast curve
    SETCOL(vec4(col, 1.0));
}
)GLSL";

inline const char* VS_DEPTH = R"GLSL(
ATTR vec3 vertexPosition;
uniform mat4 mvp;
void main() {
    gl_Position = mvp * vec4(vertexPosition, 1.0);
}
)GLSL";

inline const char* FS_DEPTH = R"GLSL(
FRAGOUT
vec4 packDepth(float d) {
    vec4 e = vec4(1.0, 255.0, 65025.0, 16581375.0) * d;
    e = fract(e);
    e -= e.yzww * vec4(1.0 / 255.0, 1.0 / 255.0, 1.0 / 255.0, 0.0);
    return e;
}
void main() {
    SETCOL(packDepth(gl_FragCoord.z));
}
)GLSL";

// ------------------------------------------------------------ graphics state
struct Gfx {
    bool ok = false;          // lit shader compiled
    bool shadowOk = false;    // shadow map available
    Shader lit = {}, depth = {};
    int locView = -1, locLight = -1, locParams = -1, locUV = -1, locGlow = -1;
    int locLightVP = -1, locShadowOn = -1, locTexel = -1;
    Material mat = {}, matDepth = {};
    Texture2D wood = {}, felt = {}, paint = {}, stone = {}, blob = {}, glow = {}, vignette = {}, numbers = {};
    RenderTexture2D shadowRT = {};
    int shadowSize = 1024;
    Font font = {};
    bool shadowPass = false;
    Mesh plane = {}, board = {}, rimLong = {}, rimShort = {}, feltBox = {}, strip = {};
    Mesh tile = {}, die = {}, rod = {}, pip = {}, cap = {}, inlayX = {}, inlayZ = {};
    Mesh discBig = {}, discSmall = {};
};
inline Gfx gx;
inline bool shadowsEnabled = true;     // user setting

inline void InitGraphics() {
#if defined(__ANDROID__) || defined(__EMSCRIPTEN__)
    const int texBig = 512;
    gx.shadowSize = 1024;
#else
    const int texBig = 1024;
    gx.shadowSize = 2048;
#endif

    // UI font (embedded)
    {
        int cps[98];
        for (int i = 0; i < 95; ++i) cps[i] = 32 + i;
        cps[95] = 0x2605; cps[96] = 0x25B6; cps[97] = 0x2713;
        gx.font = LoadFontFromMemory(".ttf", UI_FONT_DATA, UI_FONT_SIZE, 80, cps, 98);
        if (gx.font.texture.id == 0) gx.font = GetFontDefault();
        else SetTextureFilter(gx.font.texture, TEXTURE_FILTER_BILINEAR);
    }

    // shaders
    {
        const std::string vs = std::string(VS_HEAD) + VS_LIT;
        const std::string fs = std::string(FS_HEAD) + FS_LIT;
        gx.lit = LoadShaderFromMemory(vs.c_str(), fs.c_str());
        gx.ok = gx.lit.id > 0 && gx.lit.id != rlGetShaderIdDefault();
        gx.mat = LoadMaterialDefault();
        if (gx.ok) {
            gx.lit.locs[SHADER_LOC_MATRIX_MODEL]   = GetShaderLocation(gx.lit, "matModel");
            gx.lit.locs[SHADER_LOC_MATRIX_NORMAL]  = GetShaderLocation(gx.lit, "matNormal");
            gx.lit.locs[SHADER_LOC_VECTOR_VIEW]    = GetShaderLocation(gx.lit, "viewPos");
            gx.lit.locs[SHADER_LOC_COLOR_DIFFUSE]  = GetShaderLocation(gx.lit, "colDiffuse");
            gx.lit.locs[SHADER_LOC_MAP_DIFFUSE]    = GetShaderLocation(gx.lit, "texture0");
            gx.lit.locs[SHADER_LOC_MAP_METALNESS]  = GetShaderLocation(gx.lit, "shadowMap");   // texture slot 1
            gx.locView     = GetShaderLocation(gx.lit, "viewPos");
            gx.locLight    = GetShaderLocation(gx.lit, "lightDir");
            gx.locParams   = GetShaderLocation(gx.lit, "matParams");
            gx.locUV       = GetShaderLocation(gx.lit, "uvScale");
            gx.locGlow     = GetShaderLocation(gx.lit, "glow");
            gx.locLightVP  = GetShaderLocation(gx.lit, "lightVP");
            gx.locShadowOn = GetShaderLocation(gx.lit, "shadowOn");
            gx.locTexel    = GetShaderLocation(gx.lit, "shadowTexel");
            gx.mat.shader = gx.lit;
        }
        const std::string dvs = std::string(VS_HEAD) + VS_DEPTH;
        const std::string dfs = std::string(FS_HEAD) + FS_DEPTH;
        gx.depth = LoadShaderFromMemory(dvs.c_str(), dfs.c_str());
        const bool depthOk = gx.depth.id > 0 && gx.depth.id != rlGetShaderIdDefault();
        gx.matDepth = LoadMaterialDefault();
        if (depthOk) gx.matDepth.shader = gx.depth;
        if (gx.ok && depthOk) {
            gx.shadowRT = LoadRenderTexture(gx.shadowSize, gx.shadowSize);
            if (gx.shadowRT.id > 0) {
                SetTextureFilter(gx.shadowRT.texture, TEXTURE_FILTER_POINT);   // packed depth must not be filtered
                SetTextureWrap(gx.shadowRT.texture, TEXTURE_WRAP_CLAMP);
                gx.mat.maps[MATERIAL_MAP_METALNESS].texture = gx.shadowRT.texture;
                gx.shadowOk = true;
            }
        }
    }

    // textures
    gx.wood  = MakeWoodTex(texBig);
    gx.felt  = MakeFeltTex(256);
    gx.paint = MakePaintTex(256);
    gx.stone = MakeStoneTex(256);
    gx.blob  = MakeSoftTex(128, true, 1.6f);
    gx.glow  = MakeSoftTex(128, false, 2.4f);
    gx.vignette = MakeVignetteTex(256);
    gx.numbers  = MakeNumberAtlas(gx.font);

    // meshes
    gx.plane    = GenMeshPlane(60.0f, 60.0f, 1, 1);
    gx.board    = MakeRoundedBox(13.8f, 0.45f, 13.8f, 0.10f, 24, 3.5f);
    gx.rimLong  = MakeRoundedBox(13.8f, 0.18f, 0.40f, 0.06f, 20, 3.5f);
    gx.rimShort = MakeRoundedBox(0.40f, 0.18f, 13.0f, 0.06f, 20, 3.5f);
    gx.feltBox  = MakeRoundedBox(10.1f, 0.04f, 10.1f, 0.015f, 12, 1.6f);
    gx.strip    = MakeRoundedBox(9.6f, 0.04f, 1.5f, 0.015f, 12, 1.6f);
    gx.tile     = MakeRoundedBox(0.86f, 0.12f, 1.2f, 0.035f, 14, 1.2f);
    gx.die      = MakeRoundedBox(0.6f, 0.6f, 0.6f, 0.075f, 20, 0.6f);
    gx.cap      = MakeRoundedBox(0.58f, 0.34f, 0.58f, 0.09f, 12, 0.6f);
    gx.inlayX   = MakeRoundedBox(12.8f, 0.05f, 0.07f, 0.02f, 8, 2.0f);
    gx.inlayZ   = MakeRoundedBox(0.07f, 0.05f, 12.8f, 0.02f, 8, 2.0f);
    gx.rod      = GenMeshCylinder(0.05f, 9.7f, 24);
    gx.pip      = GenMeshCylinder(0.052f, 0.04f, 20);
    gx.discBig   = GenMeshCylinder(2.55f, 0.012f, 72);
    gx.discSmall = GenMeshCylinder(2.47f, 0.012f, 72);
}

// Draw one mesh with the lit shader (or, during the shadow pass, with the depth shader).
inline void DrawLit(const Mesh& m, const Texture2D& tex, Color tint, float spec, float shin,
                    float uvScale = 1.0f, float metal = 0.0f,
                    float gr = 0.0f, float gg = 0.0f, float gb = 0.0f) {
    if (gx.shadowPass) {
        DrawMesh(m, gx.matDepth, MatrixIdentity());
        return;
    }
    gx.mat.maps[MATERIAL_MAP_DIFFUSE].texture = tex;
    gx.mat.maps[MATERIAL_MAP_DIFFUSE].color = tint;
    if (gx.ok) {
        float p[3] = { spec, shin, metal };
        float gl[3] = { gr, gg, gb };
        SetShaderValue(gx.lit, gx.locParams, p, SHADER_UNIFORM_VEC3);
        SetShaderValue(gx.lit, gx.locUV, &uvScale, SHADER_UNIFORM_FLOAT);
        SetShaderValue(gx.lit, gx.locGlow, gl, SHADER_UNIFORM_VEC3);
    }
    DrawMesh(m, gx.mat, MatrixIdentity());
}

// Soft contact shadow lying on a horizontal surface.
inline void DrawBlob(float x, float y, float z, float rx, float rz, float alpha) {
    rlSetTexture(gx.blob.id);
    rlBegin(RL_QUADS);
    rlColor4f(1.0f, 1.0f, 1.0f, alpha);
    rlNormal3f(0.0f, 1.0f, 0.0f);
    rlTexCoord2f(0.0f, 0.0f); rlVertex3f(x - rx, y, z - rz);
    rlTexCoord2f(0.0f, 1.0f); rlVertex3f(x - rx, y, z + rz);
    rlTexCoord2f(1.0f, 1.0f); rlVertex3f(x + rx, y, z + rz);
    rlTexCoord2f(1.0f, 0.0f); rlVertex3f(x + rx, y, z - rz);
    rlEnd();
    rlSetTexture(0);
}

// 3D tile number: a textured quad lying on the top face of a tile (call inside the tile transform).
inline void DrawNumberQuad(int n, int variant) {
    const int idx = variant * 12 + (n - 1);
    const float cs = 128.0f / 1024.0f;
    const float u0 = (idx % 8) * cs, v0 = (idx / 8) * cs, u1 = u0 + cs, v1 = v0 + cs;
    const float y = 0.064f, hs = 0.34f, zc = -0.06f;
    rlSetTexture(gx.numbers.id);
    rlBegin(RL_QUADS);
    rlColor4f(1.0f, 1.0f, 1.0f, 1.0f);
    rlNormal3f(0.0f, 1.0f, 0.0f);
    rlTexCoord2f(u0, v0); rlVertex3f(-hs, y, zc - hs);
    rlTexCoord2f(u0, v1); rlVertex3f(-hs, y, zc + hs);
    rlTexCoord2f(u1, v1); rlVertex3f( hs, y, zc + hs);
    rlTexCoord2f(u1, v0); rlVertex3f( hs, y, zc - hs);
    rlEnd();
    rlSetTexture(0);
}

} // namespace gfx
