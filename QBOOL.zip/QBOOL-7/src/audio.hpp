// Q BOOL - procedural audio. Every sound effect and the background music are
// synthesised at start-up, so the game needs no audio files at all.
#pragma once
#include "raylib.h"
#include <cmath>
#include <cstdint>
#include <vector>

namespace audio {

constexpr int   RATE = 22050;
constexpr float TAU  = 6.28318530718f;

struct Bank {
    bool ready = false;
    bool sfxOn = true;
    bool musicOn = true;
    Sound click{}, clack{}, rattle{}, thud{}, win{}, sad{}, fanfare{}, music{};
};
inline Bank bank;

namespace detail {
inline uint32_t& seed() { static uint32_t s = 12345u; return s; }
inline float noise() {                       // white noise in [-1,1]
    uint32_t& s = seed();
    s = s * 1664525u + 1013904223u;
    return ((float)(s >> 8) / 8388607.5f) - 1.0f;
}
inline float clamp1(float v) { return v < -1.0f ? -1.0f : (v > 1.0f ? 1.0f : v); }

template <class F>
Sound Synth(float seconds, F fn) {
    const int n = (int)(seconds * RATE);
    Wave w = {};
    w.frameCount = (unsigned int)n;
    w.sampleRate = RATE;
    w.sampleSize = 16;
    w.channels   = 1;
    w.data       = MemAlloc((unsigned int)(n * (int)sizeof(int16_t)));
    int16_t* d = (int16_t*)w.data;
    for (int i = 0; i < n; ++i) {
        const float t = (float)i / RATE;
        d[i] = (int16_t)(clamp1(fn(t, t / seconds)) * 30000.0f);
    }
    Sound s = LoadSoundFromWave(w);
    UnloadWave(w);
    return s;
}
inline float env(float t, float attack, float decay) {       // fast attack, exponential decay
    const float a = t < attack ? t / attack : 1.0f;
    return a * expf(-t * decay);
}
inline float sine(float f, float t) { return sinf(TAU * f * t); }
} // namespace detail

inline void Init() {
    InitAudioDevice();
    if (!IsAudioDeviceReady()) return;
    using namespace detail;

    // UI click
    bank.click = Synth(0.09f, [](float t, float) {
        return 0.6f * env(t, 0.001f, 55.0f) * (sine(1250.0f, t) + 0.4f * sine(2500.0f, t));
    });
    // wooden tile clack
    bank.clack = Synth(0.22f, [](float t, float) {
        const float body = sine(190.0f, t) * env(t, 0.001f, 24.0f) + 0.5f * sine(430.0f, t) * env(t, 0.001f, 40.0f);
        const float tick = noise() * env(t, 0.0005f, 220.0f);
        return 0.75f * body + 0.45f * tick;
    });
    // dice rattle: a shower of short noise grains
    bank.rattle = Synth(1.05f, [](float t, float p) {
        const float rate = 38.0f * (1.0f - 0.8f * p);
        const float ph = fmodf(t * rate, 1.0f);
        const float grain = expf(-ph * 14.0f);
        const float amp = (1.0f - p) * (1.0f - p) * 0.9f + 0.05f;
        return amp * grain * (0.7f * noise() + 0.3f * sine(1700.0f + 900.0f * noise(), t));
    });
    // dice landing thud
    bank.thud = Synth(0.28f, [](float t, float) {
        return 0.9f * env(t, 0.002f, 16.0f) * sine(95.0f - 120.0f * t, t) + 0.25f * noise() * env(t, 0.0005f, 120.0f);
    });
    // happy arpeggio
    bank.win = Synth(1.25f, [](float t, float) {
        const float notes[5] = { 523.25f, 659.25f, 783.99f, 1046.5f, 1318.5f };
        float out = 0.0f;
        for (int k = 0; k < 5; ++k) {
            const float tt = t - 0.11f * k;
            if (tt < 0.0f) continue;
            out += 0.32f * env(tt, 0.004f, 3.2f) * (sine(notes[k], tt) + 0.25f * sine(notes[k] * 2.0f, tt));
        }
        return out;
    });
    // sad descending tones
    bank.sad = Synth(0.9f, [](float t, float) {
        const float a = env(t, 0.01f, 3.5f) * sine(311.1f, t);
        const float tt = t - 0.28f;
        const float b = tt > 0 ? env(tt, 0.01f, 3.0f) * sine(233.1f, tt) : 0.0f;
        return 0.5f * (a + b);
    });
    // big fanfare for "shut the box"
    bank.fanfare = Synth(2.2f, [](float t, float) {
        const float notes[8] = { 392.0f, 523.25f, 659.25f, 783.99f, 1046.5f, 783.99f, 1046.5f, 1568.0f };
        float out = 0.0f;
        for (int k = 0; k < 8; ++k) {
            const float tt = t - 0.15f * k;
            if (tt < 0.0f) continue;
            const float f = notes[k];
            out += 0.26f * env(tt, 0.006f, 2.2f) * (sine(f, tt) + 0.5f * sine(f * 2.0f, tt) + 0.2f * sine(f * 3.0f, tt));
        }
        return out;
    });
    // ambient pad: Am - F - C - G, 2 s per chord, 8 s loop that fades to silence at both ends
    bank.music = Synth(8.0f, [](float t, float) {
        const float chords[4][3] = { {220.0f, 261.63f, 329.63f}, {174.61f, 220.0f, 261.63f},
                                     {261.63f, 329.63f, 392.0f}, {196.0f, 246.94f, 293.66f} };
        const int ci = (int)(t / 2.0f) % 4;
        const float tc = t - ci * 2.0f;
        float e = sinf(3.14159265f * tc / 2.0f);
        e *= e;
        float out = 0.0f;
        for (int k = 0; k < 3; ++k) {
            const float f = chords[ci][k];
            out += 0.11f * e * (sine(f, t) + 0.35f * sine(f * 2.0f, t) + 0.12f * sine(f * 3.0f, t));
        }
        out += 0.13f * e * sine(chords[ci][0] * 0.5f, t);                       // bass
        const float bt = fmodf(t, 0.5f);                                         // soft bell arpeggio
        const int ni = ((int)(t / 0.5f)) % 3;
        out += 0.07f * env(bt, 0.004f, 5.0f) * e * sine(chords[ci][ni] * 2.0f, t);
        return out;
    });
    SetSoundVolume(bank.music, 0.55f);
    bank.ready = true;
}

inline void Play(Sound& s, float vol = 1.0f, float pitch = 1.0f) {
    if (!bank.ready || !bank.sfxOn) return;
    SetSoundVolume(s, vol);
    SetSoundPitch(s, pitch);
    PlaySound(s);
}

inline void Update() {                       // keep the music looping
    if (!bank.ready) return;
    if (bank.musicOn) {
        if (!IsSoundPlaying(bank.music)) PlaySound(bank.music);
    } else if (IsSoundPlaying(bank.music)) {
        StopSound(bank.music);
    }
}

inline void Shutdown() {
    if (!bank.ready) return;
    UnloadSound(bank.click);  UnloadSound(bank.clack);   UnloadSound(bank.rattle);
    UnloadSound(bank.thud);   UnloadSound(bank.win);     UnloadSound(bank.sad);
    UnloadSound(bank.fanfare); UnloadSound(bank.music);
    CloseAudioDevice();
    bank.ready = false;
}

} // namespace audio
