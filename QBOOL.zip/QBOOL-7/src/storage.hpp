// Q BOOL - save-game storage: a file on desktop / Android, localStorage in the browser.
#pragma once
#include "economy.hpp"

#include <cstdio>
#include <cstdlib>
#include <string>

#if defined(__EMSCRIPTEN__)
#include <emscripten/emscripten.h>
#endif

namespace storage {

#if defined(__EMSCRIPTEN__)

inline bool Load(eco::Save& s) {
    int32_t a[eco::SAVE_INTS];
    for (int i = 0; i < eco::SAVE_INTS; ++i)
        a[i] = EM_ASM_INT({ try { var v = window.localStorage.getItem('qbool' + $0); return v ? (parseInt(v, 10) | 0) : 0; } catch (e) { return 0; } }, i);
    return eco::FromInts(a, s);
}

inline void Store(const eco::Save& s) {
    int32_t a[eco::SAVE_INTS];
    eco::ToInts(s, a);
    for (int i = 0; i < eco::SAVE_INTS; ++i)
        EM_ASM({ try { window.localStorage.setItem('qbool' + $0, String($1)); } catch (e) { } }, i, a[i]);
}

#else

inline std::string Path() {
#if defined(__ANDROID__)
    return "/data/data/com.qbool.game/qbool.sav";            // the app's private folder
#else
    const char* appdata = std::getenv("APPDATA");             // Windows
    const char* home    = std::getenv("HOME");                // Linux / macOS
    if (appdata && *appdata) return std::string(appdata) + "/qbool.sav";
    if (home && *home)       return std::string(home) + "/.qbool.sav";
    return "qbool.sav";
#endif
}

inline bool Load(eco::Save& s) {
    std::FILE* f = std::fopen(Path().c_str(), "rb");
    if (!f) return false;
    int32_t a[eco::SAVE_INTS] = {};
    const size_t n = std::fread(a, sizeof(int32_t), (size_t)eco::SAVE_INTS, f);   // an old save has 19
    std::fclose(f);
    if (n < (size_t)eco::SAVE_INTS_V1) return false;
    return eco::FromInts(a, s, (int)n);
}

inline void Store(const eco::Save& s) {
    int32_t a[eco::SAVE_INTS];
    eco::ToInts(s, a);
    std::FILE* f = std::fopen(Path().c_str(), "wb");
    if (!f) return;
    std::fwrite(a, sizeof(int32_t), (size_t)eco::SAVE_INTS, f);
    std::fclose(f);
}

#endif

} // namespace storage
