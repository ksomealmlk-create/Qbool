// Q BOOL - 3D tile-closing dice board game (2-4 players), C++ + raylib.
// One roll per turn. Close the two dice tiles (e.g. 2 and 3) OR just their sum (5).
// When you can't move, your open tiles are your score. Lowest score wins!
#include "raylib.h"
#include "raymath.h"
#include "rlgl.h"

#include "audio.hpp"
#include "fx.hpp"
#include "game_logic.hpp"
#include "gfx.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <string>
#include <vector>

#if defined(__EMSCRIPTEN__)
#include <emscripten/emscripten.h>
#endif

#if !defined(__EMSCRIPTEN__) && !defined(__ANDROID__)
#define QB_DESKTOP 1
#endif

namespace {

using gfx::gx;
using gfx::Clampf;
using gfx::PI_F;

// ------------------------------------------------------------ constants
const float HINGE_Y   = 0.47f;
const float HINGE_Z   = 6.2f;
const float TILE_STEP = 0.8f;
const float OPEN_ANG  = 68.0f;
const float SEL_ANG   = 38.0f;

const Color SEAT_COL[4]  = { Color{50,110,230,255}, Color{225,55,55,255},
                             Color{45,175,85,255},  Color{240,200,40,255} };
const char* SEAT_NAME[4] = { "BLUE", "RED", "GREEN", "YELLOW" };
const Color GOLD_COL         = Color{255,210,70,255};
const Color BTN_ON       = Color{230,150,20,255};
const Color BTN_OFF      = Color{70,70,90,255};
const Color BTN_GO       = Color{40,160,70,255};

enum class State   { Menu, WaitRoll, Rolling, Choose, Delay, RoundOver };
enum class Overlay { None, Help, Settings, Pause };

struct Game {
    State state = State::Menu;
    Overlay overlay = Overlay::None;
    Overlay overlayBack = Overlay::None;       // where "back" goes from Help / Settings

    // match options
    int numPlayers = 4;
    bool vsComputer = false;
    Difficulty diff = Difficulty::Normal;
    int rounds = 1;
    bool hints = true;
    bool quit = false;

    // match state
    int seats[4] = {0, 1, 2, 3};     // turn index -> seat
    Board boards[4];                 // indexed by SEAT
    float angle[4][NUM_TILES + 1] = {};
    int scores[4] = {0, 0, 0, 0};    // this round, indexed by turn index
    int totals[4] = {0, 0, 0, 0};    // whole match, indexed by turn index
    bool done[4] = {false, false, false, false};
    int cur = 0;                     // current turn index
    int round = 1;
    bool matchOver = false;

    // dice
    int d1 = 0, d2 = 0, rollTotal = 0;
    bool oneDie = false;
    float rollT = 1.0f;
    int bounceMark = 3;
    Vector3 dieStart[2] = {}, dieEnd[2] = {};
    float dieYaw[2] = {0, 0};
    float dieSpin[2][2] = {};

    // choosing
    uint16_t selected = 0;
    uint16_t preview = 0;            // option under the mouse pointer
    std::vector<uint16_t> combos;
    int hintIdx = -1;
    float botTimer = 0.0f;
    int botStage = 0;

    float timer = 0.0f;
    char msg[96] = "";

    // camera / effects
    float camAngle = 0.0f;
    float camDiff = 0.0f;            // how far the camera still has to turn (radians)
    float shake = 0.0f;
    float celebrate = 0.0f;
    float celebrateTick = 0.0f;
};

Game g;
Camera3D cam;
Vector2 g_mp = {0, 0};
bool g_tap = false;
Matrix g_lightVP = {};

int CurSeat() { return g.seats[g.cur]; }
bool IsBot(int turnIdx) { return g.vsComputer && turnIdx != 0; }
float UIScale() {
    float u = std::min(GetScreenWidth() / 960.0f, GetScreenHeight() / 540.0f);
    return std::max(0.55f, std::min(u, 2.2f));
}
float Rnd01() { return (float)GetRandomValue(0, 9999) / 10000.0f; }
void Beep(Sound& s, float vol = 1.0f, float pitch = 1.0f) { audio::Play(s, vol, pitch); }

// ------------------------------------------------------------ game flow
void StartRound() {
    const int n = g.numPlayers;
    if (n == 2)      { g.seats[0] = 0; g.seats[1] = 2; }
    else             { for (int i = 0; i < n; ++i) g.seats[i] = i; }
    bool active[4] = {false, false, false, false};
    for (int i = 0; i < n; ++i) active[g.seats[i]] = true;
    for (int s = 0; s < 4; ++s) {
        g.boards[s].reset();
        if (!active[s]) g.boards[s].shutAll();
        for (int t = 0; t <= NUM_TILES; ++t) g.angle[s][t] = 0.0f;
    }
    for (int i = 0; i < 4; ++i) { g.scores[i] = 0; g.done[i] = false; }
    g.cur = (g.round - 1) % n;                 // the starting player rotates every round
    g.selected = 0; g.preview = 0;
    g.rollT = 1.0f; g.bounceMark = 3;
    g.d1 = g.d2 = 0;
    g.rollTotal = 0;
    g.msg[0] = 0;
    g.matchOver = false;
    g.celebrate = 0.0f;
    g.botTimer = 1.1f;
    g.state = State::WaitRoll;
}

void StartMatch() {
    g.round = 1;
    for (int i = 0; i < 4; ++i) g.totals[i] = 0;
    StartRound();
}

void ToMenu() {
    for (int s = 0; s < 4; ++s) g.boards[s].reset();
    g.selected = 0; g.preview = 0;
    g.rollT = 1.0f; g.bounceMark = 3;
    g.d1 = g.d2 = 0;
    g.rollTotal = 0;
    g.cur = 0;
    g.msg[0] = 0;
    g.celebrate = 0.0f;
    g.overlay = Overlay::None;
    g.state = State::Menu;
}

Vector3 DicePos(int i, float t) {
    const float e = 1.0f - (1.0f - t) * (1.0f - t);
    Vector3 p;
    p.x = g.dieStart[i].x + (g.dieEnd[i].x - g.dieStart[i].x) * e;
    p.z = g.dieStart[i].z + (g.dieEnd[i].z - g.dieStart[i].z) * e;
    p.y = g.dieEnd[i].y + fabsf(sinf(t * PI_F * 3.0f)) * (1.0f - t) * 2.2f;
    return p;
}

void DiceImpact(float strength) {
    Beep(audio::bank.thud, 0.45f + 0.55f * strength, 0.85f + 0.3f * (1.0f - strength));
    g.shake = std::max(g.shake, 0.07f * strength);
    for (int i = 0; i < 2; ++i) {
        if (i == 1 && g.oneDie) continue;
        const Vector3 p = DicePos(i, g.rollT);
        fx::Puff(Vector3{ p.x, 0.52f, p.z }, 2 + (int)(4.0f * strength));
    }
}

void DoRoll() {
    const int seat = CurSeat();
    g.oneDie = g.boards[seat].highShut();
    g.d1 = GetRandomValue(1, 6);
    g.d2 = g.oneDie ? 0 : GetRandomValue(1, 6);
    g.rollTotal = g.d1 + g.d2;
    g.rollT = 0.0f;
    g.bounceMark = 0;

    const float phi = seat * PI_F / 2.0f;
    const float sx = sinf(phi), sz = cosf(phi);
    for (int i = 0; i < 2; ++i) {
        float jx = GetRandomValue(-30, 30) / 100.0f;
        float jz = GetRandomValue(-30, 30) / 100.0f;
        if (g.oneDie) {
            g.dieEnd[i] = Vector3{ 0.0f + jx, 0.765f, 0.0f + jz };
        } else {
            g.dieEnd[i] = Vector3{ (i == 0 ? -0.95f : 0.95f) + jx, 0.765f,
                                   (i == 0 ? 0.3f : -0.3f) + jz };
        }
        g.dieStart[i] = Vector3{ sx * 8.0f + (i == 0 ? -0.8f : 0.8f) * sz, 3.2f,
                                 sz * 8.0f - (i == 0 ? -0.8f : 0.8f) * sx };
        g.dieYaw[i] = (float)GetRandomValue(0, 359);
        g.dieSpin[i][0] = (GetRandomValue(0, 1) ? 1.0f : -1.0f) * (700.0f + GetRandomValue(0, 400));
        g.dieSpin[i][1] = (GetRandomValue(0, 1) ? 1.0f : -1.0f) * (600.0f + GetRandomValue(0, 400));
    }
    g.selected = 0; g.preview = 0;
    g.msg[0] = 0;
    g.state = State::Rolling;
    Beep(audio::bank.rattle, 0.9f, 0.95f + 0.1f * Rnd01());
}

void EnterChoose() {
    const int seat = CurSeat();
    g.combos = findOptions(g.boards[seat], g.d1, g.d2);
    g.selected = 0; g.preview = 0;
    g.hintIdx = -1;
    if (g.combos.empty()) {
        g.scores[g.cur] = g.boards[seat].openSum();
        g.done[g.cur] = true;
        std::snprintf(g.msg, sizeof(g.msg), "No move!  %s scores %d", SEAT_NAME[seat], g.scores[g.cur]);
        g.state = State::Delay;
        g.timer = 2.2f;
        Beep(audio::bank.sad);
    } else {
        if (g.hints && !IsBot(g.cur)) g.hintIdx = bestOptionIndex(g.boards[seat], g.combos);
        g.state = State::Choose;
        g.botTimer = 0.9f + 0.5f * Rnd01();
        g.botStage = 0;
    }
}

void FinishRound() {
    for (int i = 0; i < g.numPlayers; ++i) g.totals[i] += g.scores[i];
    g.matchOver = (g.round >= g.rounds);
    g.state = State::RoundOver;
    g.celebrate = 4.5f;
    Beep(audio::bank.win);
}

void EndTurn() {
    g.selected = 0; g.preview = 0;
    g.msg[0] = 0;
    g.d1 = g.d2 = 0;          // dice leave the table between turns
    g.rollTotal = 0;
    g.rollT = 1.0f; g.bounceMark = 3;
    for (int k = 1; k <= g.numPlayers; ++k) {
        const int c = (g.cur + k) % g.numPlayers;
        if (!g.done[c]) {
            g.cur = c;
            g.state = State::WaitRoll;
            g.botTimer = 1.0f;
            return;
        }
    }
    FinishRound();
}

Vector3 TileCenter(int seat, int n, float angDeg) {
    const float lx = (n - 6.5f) * TILE_STEP;
    const float th = angDeg * PI_F / 180.0f;
    const float ly = HINGE_Y + 0.6f * sinf(th) + 0.06f * cosf(th);
    const float lz = HINGE_Z - 0.6f * cosf(th) + 0.06f * sinf(th);
    const float phi = seat * PI_F / 2.0f;
    return Vector3{ lx * cosf(phi) + lz * sinf(phi), ly, -lx * sinf(phi) + lz * cosf(phi) };
}

void ConfirmSelection() {
    const int seat = CurSeat();
    int closedCount = 0;
    for (int n = 1; n <= NUM_TILES; ++n) {
        if (g.selected & (1u << n)) {
            const Vector3 c = TileCenter(seat, n, g.angle[seat][n]);
            fx::Sparks(c, 14, Color{255, 205, 90, 255});
            g.boards[seat].open[n] = false;
            Beep(audio::bank.clack, 0.8f, 0.9f + 0.25f * Rnd01());
            ++closedCount;
        }
    }
    (void)closedCount;
    g.selected = 0; g.preview = 0;
    g.shake = std::max(g.shake, 0.03f);
    if (g.boards[seat].allShut()) {
        g.scores[g.cur] = 0;
        g.done[g.cur] = true;
        std::snprintf(g.msg, sizeof(g.msg), "SHUT THE BOX!  %s scores 0", SEAT_NAME[seat]);
        g.state = State::Delay;
        g.timer = 2.8f;
        g.celebrate = 3.0f;
        Beep(audio::bank.fanfare);
    } else {
        g.msg[0] = 0;
        g.state = State::Delay;
        g.timer = 1.0f;
    }
}

// Returns the open tile (1..12) of `seat` nearest to the pointer, or 0.
int PickTile(int seat, Vector2 mp) {
    int best = 0;
    float bestD = 1e9f;
    const float phi = seat * PI_F / 2.0f;
    for (int n = 1; n <= NUM_TILES; ++n) {
        if (!g.boards[seat].open[n]) continue;
        Vector3 c = TileCenter(seat, n, g.angle[seat][n]);
        Vector2 s = GetWorldToScreen(c, cam);
        Vector3 r = Vector3{ c.x + 0.4f * cosf(phi), c.y, c.z - 0.4f * sinf(phi) };
        Vector2 s2 = GetWorldToScreen(r, cam);
        float halfW = hypotf(s2.x - s.x, s2.y - s.y);
        float d = hypotf(mp.x - s.x, mp.y - s.y);
        if (d < halfW * 1.25f && d < bestD) { bestD = d; best = n; }
    }
    return best;
}

Rectangle RollRect() {
    float u = UIScale();
    float w = 230 * u, h = 62 * u;
    return Rectangle{ GetScreenWidth() / 2.0f - w / 2, GetScreenHeight() - h - 24 * u, w, h };
}
Rectangle OptionRect(int i, int n) {
    float u = UIScale();
    float w = 250 * u, h = 58 * u, gap = 18 * u;
    float total = n * w + (n - 1) * gap;
    return Rectangle{ GetScreenWidth() / 2.0f - total / 2 + i * (w + gap),
                      GetScreenHeight() - h - 24 * u, w, h };
}
Rectangle PauseBtnRect() {
    float u = UIScale();
    return Rectangle{ 14 * u, 50 * u, 46 * u, 46 * u };
}

// ------------------------------------------------------------ update
void ReadInput() {
    static bool touchPrev = false;
    static double lastTap = -10.0;
    g_mp = GetMousePosition();
    bool touchNow = GetTouchPointCount() > 0;
    if (touchNow) g_mp = GetTouchPosition(0);
    g_tap = IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || (touchNow && !touchPrev);
    touchPrev = touchNow;
    double now = GetTime();
    if (g_tap) {
        if (now - lastTap < 0.30) g_tap = false;   // ignore duplicate touch+mouse events
        else { lastTap = now; Beep(audio::bank.click, 0.35f); }
    }
}

void UpdateCamera(float dt) {
    float target;
    if (g.state == State::Menu || g.state == State::RoundOver) {
        g.camAngle += dt * 0.15f;
        target = g.camAngle;
    } else {
        target = CurSeat() * PI_F / 2.0f;
    }
    float diff = target - g.camAngle;
    while (diff > PI_F)  diff -= 2 * PI_F;
    while (diff < -PI_F) diff += 2 * PI_F;
    g.camDiff = diff;
    g.camAngle += diff * std::min(1.0f, dt * 3.5f);

    float aspect = (float)GetScreenWidth() / (float)GetScreenHeight();
    float k = aspect < 1.5f ? 1.5f / aspect : 1.0f;
    k = Clampf(k, 1.0f, 2.4f);
    const float R = 11.0f * k, H = 15.0f * k;
    const float t = (float)GetTime();
    g.shake = std::max(0.0f, g.shake - dt * 0.35f);
    cam.position = Vector3{ sinf(g.camAngle) * R + (Rnd01() - 0.5f) * g.shake * 2.0f,
                            H + sinf(t * 0.5f) * 0.10f + (Rnd01() - 0.5f) * g.shake * 2.0f,
                            cosf(g.camAngle) * R + (Rnd01() - 0.5f) * g.shake * 2.0f };
    cam.target = Vector3{ 0.0f, 0.0f, 0.0f };
    cam.up = Vector3{ 0.0f, 1.0f, 0.0f };
    cam.fovy = 45.0f;
    cam.projection = CAMERA_PERSPECTIVE;
}

void UpdateTiles(float dt) {
    for (int s = 0; s < 4; ++s) {
        for (int n = 1; n <= NUM_TILES; ++n) {
            float target = 0.0f;
            if (g.boards[s].open[n]) {
                target = OPEN_ANG;
                const bool playing = g.state != State::Menu && g.state != State::RoundOver;
                if (playing && s == CurSeat() && ((g.selected | g.preview) & (1u << n))) target = SEL_ANG;
            }
            g.angle[s][n] += (target - g.angle[s][n]) * std::min(1.0f, dt * 9.0f);
        }
    }
}

void UpdateCelebration(float dt) {
    if (g.celebrate > 0.0f) {
        g.celebrate -= dt;
        g.celebrateTick -= dt;
        if (g.celebrateTick <= 0.0f) { fx::Confetti(10); g.celebrateTick = 0.05f; }
    }
}

void HandleBackKey() {
    const bool back = IsKeyPressed(KEY_ESCAPE) || IsKeyPressed(KEY_BACK);
    if (!back) return;
    if (g.overlay == Overlay::Pause) g.overlay = Overlay::None;
    else if (g.overlay == Overlay::Help || g.overlay == Overlay::Settings) g.overlay = g.overlayBack;
    else if (g.state == State::Menu) {
#if defined(QB_DESKTOP) || defined(__ANDROID__)
        g.quit = true;
#endif
    } else g.overlay = Overlay::Pause;
}

void Update(float dt) {
    ReadInput();
    audio::Update();
    fx::Update(dt);
    UpdateCamera(dt);
    UpdateTiles(dt);
    HandleBackKey();
#if defined(QB_DESKTOP)
    if (IsKeyPressed(KEY_F11)) ToggleFullscreen();
#endif
    if (g.overlay != Overlay::None) return;          // game is frozen behind menus
    UpdateCelebration(dt);

    const int seat = CurSeat();
    switch (g.state) {
    case State::Menu:
    case State::RoundOver:
        break;

    case State::WaitRoll: {
        const bool camReady = fabsf(g.camDiff) < 0.12f;
        if (IsBot(g.cur)) {
            g.botTimer -= dt;
            if (g.botTimer <= 0.0f && camReady) DoRoll();
        } else if (camReady && IsKeyPressed(KEY_SPACE)) {
            DoRoll();
        }
        break;
    }

    case State::Rolling: {
        g.rollT += dt / 1.1f;
        if (g.rollT >= 1.0f) g.rollT = 1.0f;
        const int mk = std::min(3, (int)(g.rollT * 3.0f));
        while (g.bounceMark < mk) {                  // one impact per bounce
            ++g.bounceMark;
            DiceImpact(g.bounceMark == 1 ? 1.0f : (g.bounceMark == 2 ? 0.6f : 0.35f));
        }
        if (g.rollT >= 1.0f) EnterChoose();
        break;
    }

    case State::Choose:
        if (IsBot(g.cur)) {
            g.botTimer -= dt;
            if (g.botTimer <= 0.0f) {
                if (g.botStage == 0) {
                    g.selected = botPick(g.boards[seat], g.combos, g.diff, Rnd01());
                    g.botStage = 1;
                    g.botTimer = 0.8f;
                } else {
                    ConfirmSelection();
                }
            }
        } else {
            const int n = (int)g.combos.size();
            if (IsKeyPressed(KEY_ONE) && n >= 1)   { g.selected = g.combos[0]; ConfirmSelection(); break; }
            if (IsKeyPressed(KEY_TWO) && n >= 2)   { g.selected = g.combos[1]; ConfirmSelection(); break; }
            g.preview = 0;
#if !defined(__ANDROID__)
            {
                const int over = PickTile(seat, g_mp);
                if (over) for (uint16_t c : g.combos) if (c & (1u << over)) g.preview = c;
            }
#endif
            if (g_tap) {
                bool onButton = false;
                for (int i = 0; i < n; ++i)
                    if (CheckCollisionPointRec(g_mp, OptionRect(i, n))) onButton = true;
                if (!onButton) {
                    const int hit = PickTile(seat, g_mp);
                    if (hit) {
                        for (int i = 0; i < n; ++i) {
                            if (g.combos[i] & (1u << hit)) { g.selected = g.combos[i]; ConfirmSelection(); break; }
                        }
                    }
                }
            }
        }
        break;

    case State::Delay:
        g.timer -= dt;
        if (g.timer <= 0.0f) EndTurn();
        break;
    }
}

// ------------------------------------------------------------ drawing: 3D
const Color DIE_COL = Color{ 52, 94, 168, 255 };     // blue glazed dice, white pips
const Color PIP_COL = Color{ 244, 242, 234, 255 };

void DrawPipFace(int value) {   // pips on the +Y face of a die (local space)
    const float a = 0.15f, base = 0.263f;
    auto pip = [&](float x, float z) {
        rlPushMatrix();
        rlTranslatef(x, base, z);
        gfx::DrawLit(gx.pip, gx.paint, PIP_COL, 0.25f, 16.0f);
        rlPopMatrix();
    };
    if (value == 1 || value == 3 || value == 5) pip(0, 0);
    if (value >= 2) { pip(-a, -a); pip(a, a); }
    if (value >= 4) { pip(-a, a); pip(a, -a); }
    if (value == 6) { pip(-a, 0); pip(a, 0); }
}

void DrawDie(int i) {
    if (i == 1 && g.oneDie) return;
    if (g.d1 == 0) return;
    const float t = g.rollT;
    const Vector3 p = DicePos(i, t);
    const float spin = powf(1.0f - t, 1.5f);
    const float ax = spin * g.dieSpin[i][0];
    const float az = spin * g.dieSpin[i][1];

    const int v = (i == 0) ? g.d1 : g.d2;       // value on the top face
    int rest[4], rn = 0;
    for (int k = 1; k <= 6; ++k) if (k != v && k != 7 - v) rest[rn++] = k;
    const int fa = rest[0];
    const int fb = (rest[1] != 7 - fa) ? rest[1] : rest[2];
    // face index: 0 +Y, 1 -Y, 2 +X, 3 -X, 4 +Z, 5 -Z
    const int val[6] = { v, 7 - v, fa, 7 - fa, fb, 7 - fb };

    rlPushMatrix();
    rlTranslatef(p.x, p.y, p.z);
    rlRotatef(g.dieYaw[i], 0, 1, 0);
    rlRotatef(ax, 1, 0, 0);
    rlRotatef(az, 0, 0, 1);
    gfx::DrawLit(gx.die, gx.stone, DIE_COL, 0.9f, 70.0f);
    if (!gx.shadowPass) {
        for (int f = 0; f < 6; ++f) {
            rlPushMatrix();
            if (f == 1)      rlRotatef(180, 1, 0, 0);
            else if (f == 2) rlRotatef(-90, 0, 0, 1);
            else if (f == 3) rlRotatef(90, 0, 0, 1);
            else if (f == 4) rlRotatef(90, 1, 0, 0);
            else if (f == 5) rlRotatef(-90, 1, 0, 0);
            DrawPipFace(val[f]);
            rlPopMatrix();
        }
    }
    rlPopMatrix();
}

void DrawDieShadow(int i, float strength) {
    if (i == 1 && g.oneDie) return;
    if (g.d1 == 0) return;
    const Vector3 p = DicePos(i, g.rollT);
    const float h = p.y - 0.765f;
    const float k = 1.0f / (1.0f + h * 1.4f);
    gfx::DrawBlob(p.x + 0.10f, 0.4745f, p.z + 0.12f, 0.62f + h * 0.18f, 0.62f + h * 0.18f, 0.62f * k * strength);
}

Vector3 LightDirNow() {
    const float ca = cosf(g.camAngle), sa = sinf(g.camAngle);
    const float lx0 = -0.45f, lz0 = 0.55f;     // light follows the camera: key light front-left
    return Vector3Normalize(Vector3{ lx0 * ca + lz0 * sa, 1.0f, -lx0 * sa + lz0 * ca });
}

void DrawScene() {
    const bool sp = gx.shadowPass;
    const bool shadowsOn = gx.shadowOk && gfx::shadowsEnabled;

    if (!sp && gx.ok) {
        const Vector3 L = LightDirNow();
        float Lv[3] = { L.x, L.y, L.z };
        float V[3] = { cam.position.x, cam.position.y, cam.position.z };
        float on = shadowsOn ? 1.0f : 0.0f;
        float texel = 1.0f / (float)gx.shadowSize;
        SetShaderValue(gx.lit, gx.locLight, Lv, SHADER_UNIFORM_VEC3);
        SetShaderValue(gx.lit, gx.locView, V, SHADER_UNIFORM_VEC3);
        SetShaderValue(gx.lit, gx.locShadowOn, &on, SHADER_UNIFORM_FLOAT);
        SetShaderValue(gx.lit, gx.locTexel, &texel, SHADER_UNIFORM_FLOAT);
        SetShaderValueMatrix(gx.lit, gx.locLightVP, g_lightVP);
    }

    // table
    if (!sp) gfx::DrawLit(gx.plane, gx.wood, Color{ 112, 86, 74, 255 }, 0.15f, 14.0f, 14.0f);

    // wooden board
    rlPushMatrix(); rlTranslatef(0, 0.225f, 0);
    gfx::DrawLit(gx.board, gx.wood, Color{ 214, 160, 110, 255 }, 0.45f, 32.0f);
    rlPopMatrix();
    const float rimY = 0.50f;
    const float zs[2] = { -6.7f, 6.7f };
    for (int k = 0; k < 2; ++k) {
        rlPushMatrix(); rlTranslatef(0, rimY, zs[k]);
        gfx::DrawLit(gx.rimLong, gx.wood, Color{ 196, 140, 94, 255 }, 0.5f, 36.0f);
        rlPopMatrix();
        rlPushMatrix(); rlTranslatef(zs[k], rimY, 0);
        gfx::DrawLit(gx.rimShort, gx.wood, Color{ 196, 140, 94, 255 }, 0.5f, 36.0f);
        rlPopMatrix();
    }
    // brass corner caps
    for (int a = 0; a < 2; ++a)
        for (int b = 0; b < 2; ++b) {
            rlPushMatrix(); rlTranslatef(zs[a], 0.55f, zs[b]);
            gfx::DrawLit(gx.cap, gx.paint, Color{ 214, 170, 70, 255 }, 1.0f, 60.0f, 1.0f, 1.0f);
            rlPopMatrix();
        }

    if (!sp) {
        // brass inlay frame
        for (int k = 0; k < 2; ++k) {
            rlPushMatrix(); rlTranslatef(0, 0.468f, zs[k] * 0.96f);
            gfx::DrawLit(gx.inlayX, gx.paint, Color{ 214, 170, 70, 255 }, 1.0f, 60.0f, 1.0f, 1.0f);
            rlPopMatrix();
            rlPushMatrix(); rlTranslatef(zs[k] * 0.96f, 0.468f, 0);
            gfx::DrawLit(gx.inlayZ, gx.paint, Color{ 214, 170, 70, 255 }, 1.0f, 60.0f, 1.0f, 1.0f);
            rlPopMatrix();
        }
        // green felt in the middle + golden ring = the dice arena
        rlPushMatrix(); rlTranslatef(0, 0.445f, 0);
        gfx::DrawLit(gx.feltBox, gx.felt, Color{ 34, 118, 62, 255 }, 0.04f, 6.0f);
        rlPopMatrix();
        rlPushMatrix(); rlTranslatef(0, 0.465f, 0);
        gfx::DrawLit(gx.discBig, gx.paint, Color{ 214, 170, 70, 255 }, 1.0f, 60.0f, 1.0f, 1.0f);
        rlPopMatrix();
        rlPushMatrix(); rlTranslatef(0, 0.467f, 0);
        gfx::DrawLit(gx.discSmall, gx.felt, Color{ 26, 96, 50, 255 }, 0.05f, 6.0f, 2.0f);
        rlPopMatrix();
    }

    const float pulse = 0.5f + 0.5f * sinf((float)GetTime() * 4.0f);
    const bool choosing = (g.state == State::Choose);
    uint16_t eligible = 0;
    if (choosing) for (uint16_t c : g.combos) eligible |= c;
    uint16_t hinted = 0;
    if (choosing && g.hintIdx >= 0 && g.hintIdx < (int)g.combos.size()) hinted = g.combos[(size_t)g.hintIdx];

    for (int s = 0; s < 4; ++s) {
        bool active = false;
        for (int i = 0; i < g.numPlayers; ++i) if (g.seats[i] == s) active = true;
        const bool playing = g.state != State::Menu && g.state != State::RoundOver;
        const bool isCur = playing && s == CurSeat();
        Color c = ColorBrightness(SEAT_COL[s], active ? -0.20f : -0.65f);
        if (isCur) c = ColorBrightness(SEAT_COL[s], 0.10f + 0.20f * pulse);

        rlPushMatrix();
        rlRotatef(s * 90.0f, 0, 1, 0);

        if (!sp) {
            // coloured felt strip for this seat
            rlPushMatrix(); rlTranslatef(0, 0.45f, 5.6f);
            gfx::DrawLit(gx.strip, gx.felt, c, 0.05f, 6.0f);
            rlPopMatrix();
        }

        // brass hinge rod
        rlPushMatrix();
        rlTranslatef(-4.85f, HINGE_Y + 0.03f, HINGE_Z + 0.03f);
        rlRotatef(-90.0f, 0, 0, 1);
        gfx::DrawLit(gx.rod, gx.paint, Color{ 214, 170, 70, 255 }, 1.0f, 60.0f, 1.0f, 1.0f);
        rlPopMatrix();

        for (int n = 1; n <= NUM_TILES; ++n) {
            const bool open = g.boards[s].open[n];
            const bool sel = playing && s == CurSeat() && ((g.selected | g.preview) & (1u << n));
            const bool elig = isCur && (eligible & (1u << n)) && !IsBot(g.cur);
            const bool hint = isCur && (hinted & (1u << n)) && !IsBot(g.cur);
            rlPushMatrix();
            rlTranslatef((n - 6.5f) * TILE_STEP, HINGE_Y, HINGE_Z);
            rlRotatef(g.angle[s][n], 1, 0, 0);
            rlTranslatef(0.0f, 0.06f, -0.6f);
            if (open) {
                Color body = sel ? Color{ 255, 168, 40, 255 } : SEAT_COL[s];
                float gl = elig ? 0.10f + 0.16f * pulse : 0.0f;
                if (hint) gl += 0.10f + 0.12f * pulse;
                gfx::DrawLit(gx.tile, gx.paint, body, 1.0f, 70.0f, 1.0f, 0.0f, gl, gl * 0.85f, gl * 0.3f);
                if (!sp && g.angle[s][n] > 8.0f) gfx::DrawNumberQuad(n, sel ? 1 : 0);
            } else {
                gfx::DrawLit(gx.tile, gx.wood, Color{ 120, 84, 60, 255 }, 0.25f, 14.0f);
                if (!sp && g.state != State::Menu && active) gfx::DrawNumberQuad(n, 2);
            }
            rlPopMatrix();
        }
        rlPopMatrix();
    }
    DrawDie(0);
    DrawDie(1);

    if (!sp) {
        // soft contact shadows (drawn last, without writing depth)
        const float k = (shadowsOn) ? 0.55f : 1.0f;
        rlDrawRenderBatchActive();
        rlDisableDepthMask();
        gfx::DrawBlob(0.2f, 0.03f, 0.3f, 10.5f, 10.5f, 0.55f);     // board on table
        DrawDieShadow(0, k);
        DrawDieShadow(1, k);
        rlDrawRenderBatchActive();
        rlEnableDepthMask();
    }
}

// Render the scene from the light into an RGBA-packed depth texture.
void RenderShadowMap() {
    Camera3D lc = {};
    const Vector3 L = LightDirNow();
    lc.position = Vector3Scale(L, 22.0f);
    lc.target = Vector3{ 0.0f, 0.0f, 0.0f };
    lc.up = Vector3{ 0.0f, 1.0f, 0.0f };
    lc.fovy = 22.0f;                                  // orthographic height in world units
    lc.projection = CAMERA_ORTHOGRAPHIC;

    BeginTextureMode(gx.shadowRT);
    ClearBackground(WHITE);                           // 1.0 = "infinitely far"
    rlSetClipPlanes(4.0, 44.0);
    BeginMode3D(lc);
    g_lightVP = MatrixMultiply(rlGetMatrixModelview(), rlGetMatrixProjection());
    rlDrawRenderBatchActive();
    rlDisableColorBlend();                            // the alpha channel carries depth bits
    gx.shadowPass = true;
    DrawScene();
    gx.shadowPass = false;
    rlDrawRenderBatchActive();
    rlEnableColorBlend();
    EndMode3D();
    EndTextureMode();
}

// ------------------------------------------------------------ drawing: 2D
void Txt(const char* s, float x, float y, float size, Color c) {
    const float o = std::max(1.0f, size / 16.0f);
    DrawTextEx(gx.font, s, Vector2{ x + o, y + o }, size, size * 0.02f, Fade(BLACK, 0.65f));
    DrawTextEx(gx.font, s, Vector2{ x, y }, size, size * 0.02f, c);
}
float TxtW(const char* s, float size) { return MeasureTextEx(gx.font, s, size, size * 0.02f).x; }
void TxtC(const char* s, float cx, float y, float size, Color c) { Txt(s, cx - TxtW(s, size) / 2.0f, y, size, c); }

bool Btn(Rectangle r, const char* label, Color col, float fontSize, bool enabled = true) {
    const bool hover = enabled && CheckCollisionPointRec(g_mp, r);
    if (!enabled) col = ColorBrightness(col, -0.5f);
    DrawRectangleRounded(Rectangle{r.x + 3, r.y + 5, r.width, r.height}, 0.3f, 8, Fade(BLACK, 0.4f));
    DrawRectangleRounded(r, 0.3f, 8, hover ? ColorBrightness(col, 0.2f) : col);
    DrawRectangleRounded(Rectangle{r.x + 2, r.y + 2, r.width - 4, r.height * 0.48f}, 0.5f, 8, Fade(WHITE, 0.13f));
    TxtC(label, r.x + r.width / 2, r.y + (r.height - fontSize) / 2 - fontSize * 0.08f, fontSize, enabled ? WHITE : Color{160,160,160,255});
    if (enabled && g_tap && hover) { g_tap = false; return true; }
    return false;
}

void DrawVignette() {
    DrawTexturePro(gx.vignette, Rectangle{ 0, 0, (float)gx.vignette.width, (float)gx.vignette.height },
                   Rectangle{ 0, 0, (float)GetScreenWidth(), (float)GetScreenHeight() },
                   Vector2{ 0, 0 }, 0.0f, WHITE);
}

void DrawMenu() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    const float cx = W / 2;
    DrawRectangle(0, 0, (int)W, (int)H, Fade(BLACK, 0.42f));

    TxtC("Q BOOL", cx, 10 * u, 78 * u, GOLD_COL);
    TxtC("3D dice & tiles board game", cx, 96 * u, 22 * u, WHITE);

    auto label = [&](const char* s, float y) { Txt(s, cx - 340 * u, y + 11 * u, 24 * u, Color{235,235,235,255}); };
    const float bh = 48 * u;
    float y = 142 * u;

    label("Players", y);
    for (int i = 0; i < 3; ++i) {
        const int n = i + 2;
        char b[4]; std::snprintf(b, sizeof(b), "%d", n);
        if (Btn(Rectangle{ cx - 90 * u + i * 112 * u, y, 100 * u, bh }, b, g.numPlayers == n ? BTN_ON : BTN_OFF, 28 * u))
            g.numPlayers = n;
    }
    y += 62 * u;

    label("Mode", y);
    if (Btn(Rectangle{ cx - 90 * u,  y, 168 * u, bh }, "Pass & Play", !g.vsComputer ? BTN_ON : BTN_OFF, 20 * u)) g.vsComputer = false;
    if (Btn(Rectangle{ cx + 88 * u,  y, 168 * u, bh }, "vs Computer", g.vsComputer ? BTN_ON : BTN_OFF, 20 * u)) g.vsComputer = true;
    y += 62 * u;

    label("Computer", y);
    static const char* DN[3] = { "Easy", "Normal", "Hard" };
    for (int i = 0; i < 3; ++i) {
        const bool sel = (int)g.diff == i;
        if (Btn(Rectangle{ cx - 90 * u + i * 112 * u, y, 100 * u, bh }, DN[i], sel ? BTN_ON : BTN_OFF, 20 * u, g.vsComputer))
            g.diff = (Difficulty)i;
    }
    y += 62 * u;

    label("Rounds", y);
    static const int RN[3] = { 1, 3, 5 };
    for (int i = 0; i < 3; ++i) {
        char b[4]; std::snprintf(b, sizeof(b), "%d", RN[i]);
        if (Btn(Rectangle{ cx - 90 * u + i * 112 * u, y, 100 * u, bh }, b, g.rounds == RN[i] ? BTN_ON : BTN_OFF, 28 * u))
            g.rounds = RN[i];
    }
    y += 70 * u;

    if (Btn(Rectangle{ cx - 130 * u, y, 260 * u, 64 * u }, "START", BTN_GO, 36 * u) || IsKeyPressed(KEY_ENTER)) StartMatch();
    y += 78 * u;

#if defined(QB_DESKTOP)
    const int nb = 3;
#else
    const int nb = 2;
#endif
    const float bw = 170 * u, gap = 14 * u;
    float bx = cx - (nb * bw + (nb - 1) * gap) / 2;
    if (Btn(Rectangle{ bx, y, bw, 44 * u }, "HOW TO PLAY", Color{60,90,140,255}, 18 * u)) { g.overlay = Overlay::Help; g.overlayBack = Overlay::None; }
    bx += bw + gap;
    if (Btn(Rectangle{ bx, y, bw, 44 * u }, "SETTINGS", Color{60,90,140,255}, 18 * u)) { g.overlay = Overlay::Settings; g.overlayBack = Overlay::None; }
#if defined(QB_DESKTOP)
    bx += bw + gap;
    if (Btn(Rectangle{ bx, y, bw, 44 * u }, "QUIT", Color{150,50,50,255}, 18 * u)) g.quit = true;
#endif
}

void DrawHUD() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth();
    const float H = (float)GetScreenHeight();
    const int seat = CurSeat();

    Txt("Q BOOL", 14 * u, 8 * u, 30 * u, GOLD_COL);
    if (g.rounds > 1) {
        char rb[32]; std::snprintf(rb, sizeof(rb), "Round %d / %d", g.round, g.rounds);
        Txt(rb, 16 * u, 100 * u, 17 * u, Color{235,235,235,255});
    }
    if (Btn(PauseBtnRect(), "II", Color{40,40,55,255}, 22 * u)) g.overlay = Overlay::Pause;

    // scoreboard (top-right)
    const float bw = (g.rounds > 1 ? 280.0f : 222.0f) * u;
    float bx = W - bw - 6 * u, by = 10 * u;
    DrawRectangleRounded(Rectangle{bx - 8 * u, by - 4 * u, bw, (g.numPlayers * 28 + 12) * u}, 0.15f, 6, Fade(BLACK, 0.5f));
    for (int i = 0; i < g.numPlayers; ++i) {
        const int s = g.seats[i];
        DrawRectangle((int)bx, (int)(by + (i * 28 + 4) * u), (int)(16 * u), (int)(16 * u), SEAT_COL[s]);
        char line[64];
        if (g.done[i]) std::snprintf(line, sizeof(line), "%s: score %d", SEAT_NAME[s], g.scores[i]);
        else           std::snprintf(line, sizeof(line), "%s: open %d", SEAT_NAME[s], g.boards[s].openSum());
        if (g.rounds > 1) {
            char t2[24]; std::snprintf(t2, sizeof(t2), "  [%d]", g.totals[i]);
            std::strncat(line, t2, sizeof(line) - std::strlen(line) - 1);
        }
        const bool isCur = (i == g.cur);
        Txt(line, bx + 24 * u, by + (i * 28 + 3) * u, 16 * u, isCur ? Color{255,230,120,255} : WHITE);
    }

    // turn banner
    char t[64];
    std::snprintf(t, sizeof(t), "%s's turn%s", SEAT_NAME[seat], IsBot(g.cur) ? " (CPU)" : "");
    TxtC(t, W / 2, 10 * u, 28 * u, SEAT_COL[seat].r > 200 && SEAT_COL[seat].g > 180 ? SEAT_COL[seat] : ColorBrightness(SEAT_COL[seat], 0.35f));

    // roll info
    if (g.rollTotal > 0 && g.rollT >= 1.0f) {
        char r[64];
        if (g.oneDie) std::snprintf(r, sizeof(r), "Roll: %d  (one die)", g.d1);
        else          std::snprintf(r, sizeof(r), "Roll: %d + %d = %d", g.d1, g.d2, g.rollTotal);
        TxtC(r, W / 2, 50 * u, 26 * u, WHITE);
    }

    if (g.state == State::WaitRoll && !IsBot(g.cur) && fabsf(g.camDiff) < 0.12f) {
        if (Btn(RollRect(), "ROLL", Color{220,120,20,255}, 34 * u)) DoRoll();
    }
    if (g.state == State::Choose && !IsBot(g.cur)) {
        const int n = (int)g.combos.size();
        TxtC("Choose one", W / 2, H - 112 * u, 22 * u, Color{255,235,150,255});
        int picked = -1;
        for (int i = 0; i < n; ++i) {
            char lab[40];
            int a1 = 0, a2 = 0;
            for (int tt = 1; tt <= NUM_TILES; ++tt) if (g.combos[i] & (1u << tt)) { if (!a1) a1 = tt; else a2 = tt; }
            const char* star = (i == g.hintIdx) ? "\xE2\x98\x85 " : "";
            if (a2) std::snprintf(lab, sizeof(lab), "%sClose %d + %d", star, a1, a2);
            else    std::snprintf(lab, sizeof(lab), "%sClose %d", star, a1);
            if (Btn(OptionRect(i, n), lab, i == 0 ? Color{40,140,200,255} : Color{200,120,30,255}, 26 * u))
                picked = i;
        }
        if (picked >= 0) { g.selected = g.combos[(size_t)picked]; ConfirmSelection(); }
    }
    if (g.state == State::Delay && g.msg[0]) {
        const float fs = 40 * u;
        const float w = TxtW(g.msg, fs) + 60 * u;
        DrawRectangleRounded(Rectangle{W / 2 - w / 2, H / 2 - 44 * u, w, 88 * u}, 0.3f, 8, Fade(BLACK, 0.68f));
        TxtC(g.msg, W / 2, H / 2 - fs / 2.0f - 2 * u, fs, Color{255,225,110,255});
    }
#if defined(__EMSCRIPTEN__)
    if (H > W) TxtC("Tip: rotate your phone sideways", W / 2, H - 28 * u, 16 * u, Fade(WHITE, 0.8f));
#endif
}

void DrawRoundOver() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    const float cx = W / 2;
    DrawRectangle(0, 0, (int)W, (int)H, Fade(BLACK, 0.55f));

    const bool multi = g.rounds > 1;
    int key[4];
    int best = 100000;
    for (int i = 0; i < g.numPlayers; ++i) {
        key[i] = g.matchOver ? g.totals[i] : g.scores[i];
        best = std::min(best, key[i]);
    }
    int winners = 0;
    for (int i = 0; i < g.numPlayers; ++i) if (key[i] == best) ++winners;

    char title[48];
    if (!multi)           std::snprintf(title, sizeof(title), "GAME OVER");
    else if (g.matchOver) std::snprintf(title, sizeof(title), "MATCH OVER");
    else                  std::snprintf(title, sizeof(title), "ROUND %d COMPLETE", g.round);
    float y = H * 0.07f;
    TxtC(title, cx, y, 58 * u, GOLD_COL);
    y += 84 * u;

    if (multi) {
        Txt("Round", cx + 60 * u, y, 18 * u, Color{210,210,210,255});
        Txt("Total", cx + 160 * u, y, 18 * u, Color{210,210,210,255});
        y += 28 * u;
    }
    for (int i = 0; i < g.numPlayers; ++i) {
        const int s = g.seats[i];
        const bool win = key[i] == best;
        Color c = win ? Color{255,230,110,255} : WHITE;
        DrawRectangle((int)(cx - 250 * u), (int)(y + 5 * u), (int)(22 * u), (int)(22 * u), SEAT_COL[s]);
        Txt(SEAT_NAME[s], cx - 215 * u, y, 30 * u, c);
        char b[16];
        std::snprintf(b, sizeof(b), "%d", g.scores[i]);
        Txt(b, cx + (multi ? 60 : 40) * u, y, 30 * u, c);
        if (multi) { std::snprintf(b, sizeof(b), "%d", g.totals[i]); Txt(b, cx + 160 * u, y, 30 * u, c); }
        if (win && (g.matchOver || !multi)) Txt(winners > 1 ? "TIE" : "WINNER!", cx + (multi ? 230 : 110) * u, y + 2 * u, 24 * u, Color{255,235,130,255});
        y += 46 * u;
    }
    y += 22 * u;

    if (g.matchOver) {
        if (Btn(Rectangle{ cx - 275 * u, y, 260 * u, 62 * u }, "REMATCH", BTN_GO, 30 * u) || IsKeyPressed(KEY_ENTER)) StartMatch();
        if (Btn(Rectangle{ cx + 15 * u,  y, 260 * u, 62 * u }, "MENU", Color{70,70,110,255}, 30 * u)) ToMenu();
    } else {
        if (Btn(Rectangle{ cx - 275 * u, y, 260 * u, 62 * u }, "NEXT ROUND", BTN_GO, 30 * u) || IsKeyPressed(KEY_ENTER)) { ++g.round; StartRound(); }
        if (Btn(Rectangle{ cx + 15 * u,  y, 260 * u, 62 * u }, "MENU", Color{70,70,110,255}, 30 * u)) ToMenu();
    }
}

void Panel(float u, float w, float h, const char* title) {
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    DrawRectangle(0, 0, (int)W, (int)H, Fade(BLACK, 0.68f));
    Rectangle r{ W / 2 - w * u / 2, H / 2 - h * u / 2, w * u, h * u };
    DrawRectangleRounded(Rectangle{ r.x + 5, r.y + 8, r.width, r.height }, 0.05f, 10, Fade(BLACK, 0.5f));
    DrawRectangleRounded(r, 0.05f, 10, Color{34,28,26,250});
    DrawRectangleRounded(Rectangle{ r.x + 3 * u, r.y + 3 * u, r.width - 6 * u, r.height - 6 * u }, 0.05f, 10, Color{48,40,36,255});
    TxtC(title, W / 2, r.y + 14 * u, 40 * u, GOLD_COL);
}

void DrawHelp() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    Panel(u, 860, 470, "HOW TO PLAY");
    static const char* LINES[] = {
        "1. Roll the two dice ONCE each turn (ROLL button or SPACE).",
        "2. Close BOTH dice tiles (e.g. 2 and 3) OR only their sum (5).",
        "    Doubles (3 and 3): you can only close the sum (6).",
        "3. When tiles 7-12 are all closed you roll ONE die.",
        "4. No legal move? You are out - your open tiles = your score.",
        "5. Close every tile = SHUT THE BOX = 0 points!",
        "6. Lowest score wins. Play 3 or 5 rounds for a full match.",
        "",
        "Tap a tile or a button to choose.",
        "Keys: SPACE roll | 1 / 2 choose | ESC pause | F11 fullscreen",
        "A gold star marks the best move when Hints are ON.",
    };
    float fs = 19 * u;
    float maxw = 0.0f;
    for (const char* l : LINES) maxw = std::max(maxw, TxtW(l, fs));
    if (maxw > 800 * u) fs *= 800 * u / maxw;
    float y = H / 2 - 470 * u / 2 + 74 * u;
    for (const char* l : LINES) { Txt(l, W / 2 - 400 * u, y, fs, Color{235,235,235,255}); y += fs * 1.42f; }
    if (Btn(Rectangle{ W / 2 - 100 * u, H / 2 + 470 * u / 2 - 66 * u, 200 * u, 52 * u }, "BACK", BTN_GO, 26 * u)) g.overlay = g.overlayBack;
}

bool Toggle(Rectangle r, const char* name, bool on) {
    char b[64];
    std::snprintf(b, sizeof(b), "%s:  %s", name, on ? "ON" : "OFF");
    return Btn(r, b, on ? Color{40,130,70,255} : Color{110,60,60,255}, 24 * UIScale());
}

void DrawSettings() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    Panel(u, 560, 470, "SETTINGS");
    float y = H / 2 - 470 * u / 2 + 74 * u;
    const float x = W / 2 - 220 * u, w = 440 * u, h = 50 * u, step = 60 * u;
    if (Toggle(Rectangle{ x, y, w, h }, "Sound effects", audio::bank.sfxOn)) audio::bank.sfxOn = !audio::bank.sfxOn;
    y += step;
    if (Toggle(Rectangle{ x, y, w, h }, "Music", audio::bank.musicOn)) audio::bank.musicOn = !audio::bank.musicOn;
    y += step;
    if (Toggle(Rectangle{ x, y, w, h }, "Shadows", gfx::shadowsEnabled && gx.shadowOk)) { if (gx.shadowOk) gfx::shadowsEnabled = !gfx::shadowsEnabled; }
    y += step;
    if (Toggle(Rectangle{ x, y, w, h }, "Hints (best move)", g.hints)) g.hints = !g.hints;
    y += step;
#if defined(QB_DESKTOP)
    if (Toggle(Rectangle{ x, y, w, h }, "Fullscreen", IsWindowFullscreen())) ToggleFullscreen();
#endif
    if (Btn(Rectangle{ W / 2 - 100 * u, H / 2 + 470 * u / 2 - 66 * u, 200 * u, 52 * u }, "BACK", BTN_GO, 26 * u)) g.overlay = g.overlayBack;
}

void DrawPause() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    Panel(u, 460, 460, "PAUSED");
    float y = H / 2 - 460 * u / 2 + 74 * u;
    const float x = W / 2 - 170 * u, w = 340 * u, h = 52 * u, step = 62 * u;
    if (Btn(Rectangle{ x, y, w, h }, "RESUME", BTN_GO, 26 * u)) g.overlay = Overlay::None;
    y += step;
    if (Btn(Rectangle{ x, y, w, h }, "RESTART MATCH", Color{200,120,30,255}, 24 * u)) { g.overlay = Overlay::None; StartMatch(); }
    y += step;
    if (Btn(Rectangle{ x, y, w, h }, "SETTINGS", Color{60,90,140,255}, 24 * u)) { g.overlay = Overlay::Settings; g.overlayBack = Overlay::Pause; }
    y += step;
    if (Btn(Rectangle{ x, y, w, h }, "HOW TO PLAY", Color{60,90,140,255}, 24 * u)) { g.overlay = Overlay::Help; g.overlayBack = Overlay::Pause; }
    y += step;
    if (Btn(Rectangle{ x, y, w, h }, "MAIN MENU", Color{150,50,50,255}, 24 * u)) ToMenu();
}

void Draw() {
    BeginDrawing();
    if (gx.shadowOk && gfx::shadowsEnabled) RenderShadowMap();
    ClearBackground(Color{22,17,15,255});
    rlSetClipPlanes(1.0, 120.0);
    BeginMode3D(cam);
    DrawScene();
    fx::Draw(cam, gx.glow);
    EndMode3D();
    DrawVignette();

    const bool tap = g_tap;
    if (g.overlay != Overlay::None) g_tap = false;       // base UI is inert behind menus
    if (g.state == State::Menu)           DrawMenu();
    else if (g.state == State::RoundOver) DrawRoundOver();
    else                                  DrawHUD();
    g_tap = tap;

    switch (g.overlay) {
    case Overlay::Help:     DrawHelp(); break;
    case Overlay::Settings: DrawSettings(); break;
    case Overlay::Pause:    DrawPause(); break;
    case Overlay::None:     break;
    }
    EndDrawing();
}

void Frame() {
    float dt = GetFrameTime();
    if (dt > 0.05f) dt = 0.05f;
    Update(dt);
    Draw();
}

} // namespace

int main() {
    int w = 1280, h = 720;
#if defined(__EMSCRIPTEN__)
    w = EM_ASM_INT({ return window.innerWidth; });
    h = EM_ASM_INT({ return window.innerHeight; });
#endif
#if defined(__ANDROID__)
    w = 0; h = 0;   // 0,0 = use the whole phone/tablet screen
#endif
    SetConfigFlags(FLAG_MSAA_4X_HINT | FLAG_WINDOW_RESIZABLE | FLAG_VSYNC_HINT);
    InitWindow(w, h, "Q BOOL");
    SetExitKey(KEY_NULL);            // ESC / Back opens the pause menu instead of quitting
    SetTargetFPS(60);
    SetRandomSeed((unsigned int)std::time(nullptr));

    // first frame while the textures are being generated
    BeginDrawing();
    ClearBackground(Color{28,22,20,255});
    DrawText("Q BOOL", GetScreenWidth() / 2 - MeasureText("Q BOOL", 60) / 2, GetScreenHeight() / 2 - 50, 60, Color{255,210,70,255});
    DrawText("loading...", GetScreenWidth() / 2 - MeasureText("loading...", 24) / 2, GetScreenHeight() / 2 + 20, 24, WHITE);
    EndDrawing();

    audio::Init();
    gfx::InitGraphics();
    fx::SeedMotes();

    g.numPlayers = 4;
    for (int s = 0; s < 4; ++s)
        for (int n = 0; n <= NUM_TILES; ++n) g.angle[s][n] = g.boards[s].open[n] ? OPEN_ANG : 0.0f;
    cam.up = Vector3{0, 1, 0};
    g_lightVP = MatrixIdentity();

#if defined(__EMSCRIPTEN__)
    emscripten_set_main_loop(Frame, 0, 1);
#else
    while (!WindowShouldClose() && !g.quit) Frame();
#endif
    audio::Shutdown();
    CloseWindow();
    return 0;
}
