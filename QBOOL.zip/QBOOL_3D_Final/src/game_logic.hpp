// Q BOOL - pure game logic (no graphics, no raylib) so it can be unit-tested.
#pragma once
#include <array>
#include <cstdint>
#include <vector>

constexpr int NUM_TILES = 12;

enum class Difficulty { Easy = 0, Normal = 1, Hard = 2 };

struct Board {
    std::array<bool, NUM_TILES + 1> open{};   // index 1..12

    Board() { reset(); }
    void reset() { open.fill(true); open[0] = false; }
    void shutAll() { open.fill(false); }

    int openSum() const {
        int s = 0;
        for (int n = 1; n <= NUM_TILES; ++n) if (open[n]) s += n;
        return s;
    }
    bool allShut() const { return openSum() == 0; }
    // When tiles 7..12 are all shut, the player rolls ONE die only.
    bool highShut() const {
        for (int n = 7; n <= NUM_TILES; ++n) if (open[n]) return false;
        return true;
    }
    // Bit n set = tile n is still OPEN (bit 0 unused).
    uint16_t openMask() const {
        uint16_t m = 0;
        for (int n = 1; n <= NUM_TILES; ++n) if (open[n]) m |= (uint16_t)(1u << n);
        return m;
    }
};

// Q BOOL rule: ONE roll per turn. With dice a and b you may either
//   (1) close tile a AND tile b (two different open tiles), or
//   (2) close the single tile a+b (if open).
// With one die (tiles 7..12 shut) you close tile a only.
// Each option is a bit mask: bit n set = tile n is closed.
inline std::vector<uint16_t> findOptions(const Board& b, int d1, int d2) {
    std::vector<uint16_t> out;
    if (d2 == 0) {
        if (d1 >= 1 && d1 <= NUM_TILES && b.open[d1]) out.push_back((uint16_t)(1u << d1));
        return out;
    }
    if (d1 != d2 && b.open[d1] && b.open[d2])
        out.push_back((uint16_t)((1u << d1) | (1u << d2)));
    const int total = d1 + d2;
    if (total >= 1 && total <= NUM_TILES && b.open[total])
        out.push_back((uint16_t)(1u << total));
    return out;
}

inline int selectionSum(uint16_t bits) {
    int s = 0;
    for (int n = 1; n <= NUM_TILES; ++n) if (bits & (1u << n)) s += n;
    return s;
}

// ---------------------------------------------------------------- AI
// Exact expected final score (open-tile sum) for ONE player who plays optimally
// from a given set of open tiles, computed once with dynamic programming over
// all 2^12 boards. Used by the "Hard" computer and by the hint feature.
namespace detail {
inline int sumOfMask(uint16_t m) {
    int s = 0;
    for (int n = 1; n <= NUM_TILES; ++n) if (m & (1u << n)) s += n;
    return s;
}
inline bool highShutMask(uint16_t m) { return (m >> 7) == 0; }   // bits 7..12 clear

inline const std::array<float, 8192>& expectTable() {
    static const std::array<float, 8192> table = [] {
        std::array<float, 8192> e{};
        // Removing tiles always yields a numerically smaller mask, so ascending order works.
        for (unsigned m = 0; m < 8192; m += 2) {          // bit 0 is never set
            if (m == 0) { e[m] = 0.0f; continue; }
            double total = 0.0;
            if (highShutMask((uint16_t)m)) {               // one die
                for (int d = 1; d <= 6; ++d) {
                    double best = (double)sumOfMask((uint16_t)m);
                    if (m & (1u << d)) best = e[m & ~(1u << d)];
                    total += best / 6.0;
                }
            } else {
                for (int a = 1; a <= 6; ++a)
                    for (int b = 1; b <= 6; ++b) {
                        double best = (double)sumOfMask((uint16_t)m);   // no move: score what is open
                        if (a != b && (m & (1u << a)) && (m & (1u << b))) {
                            const double v = e[m & ~((1u << a) | (1u << b))];
                            if (v < best) best = v;
                        }
                        const int t = a + b;
                        if (t <= NUM_TILES && (m & (1u << t))) {
                            const double v = e[m & ~(1u << t)];
                            if (v < best) best = v;
                        }
                        total += best / 36.0;
                    }
            }
            e[m] = (float)total;
        }
        return e;
    }();
    return table;
}
} // namespace detail

// Expected final score if the player now holds this open-mask and rolls.
inline float expectedScore(uint16_t openMask) { return detail::expectTable()[openMask & 0x1FFE]; }

// Probability that the next roll still gives at least one legal move.
inline float survivalChance(uint16_t m) {
    if (m == 0) return 1.0f;
    int ok = 0, all = 0;
    if (detail::highShutMask(m)) {
        for (int d = 1; d <= 6; ++d) { ++all; if (m & (1u << d)) ++ok; }
    } else {
        for (int a = 1; a <= 6; ++a)
            for (int b = 1; b <= 6; ++b) {
                ++all;
                const int t = a + b;
                if ((a != b && (m & (1u << a)) && (m & (1u << b))) || (t <= NUM_TILES && (m & (1u << t)))) ++ok;
            }
    }
    return (float)ok / (float)all;
}

// Index of the best option according to the optimal strategy (-1 if none).
inline int bestOptionIndex(const Board& b, const std::vector<uint16_t>& combos) {
    int best = -1;
    float bestV = 1e9f;
    const uint16_t m = b.openMask();
    for (size_t i = 0; i < combos.size(); ++i) {
        const uint16_t after = (uint16_t)(m & ~combos[i]);
        const float v = (after == 0) ? -1.0f : expectedScore(after);   // shutting the box is best
        if (v < bestV) { bestV = v; best = (int)i; }
    }
    return best;
}

// Computer player. `rnd` is a random number in [0,1) supplied by the caller.
//   Easy   - picks at random
//   Normal - greedy (close the biggest tiles first) but slips up ~35% of the time
//   Hard   - optimal (minimises the exact expected final score)
inline uint16_t botPick(const Board& b, const std::vector<uint16_t>& combos, Difficulty d, float rnd) {
    if (combos.empty()) return 0;
    if (d == Difficulty::Easy) {
        size_t i = (size_t)(rnd * (float)combos.size());
        if (i >= combos.size()) i = combos.size() - 1;
        return combos[i];
    }
    if (d == Difficulty::Hard) {
        const int i = bestOptionIndex(b, combos);
        return combos[(size_t)(i < 0 ? 0 : i)];
    }
    if (rnd < 0.35f) {                       // human-like mistake
        size_t i = (size_t)((rnd / 0.35f) * (float)combos.size());
        return combos[i >= combos.size() ? combos.size() - 1 : i];
    }
    uint16_t best = combos[0];
    long bestScore = -1;
    for (uint16_t c : combos) {
        long sc = 0;
        for (int n = 1; n <= NUM_TILES; ++n) if (c & (1u << n)) sc += (long)n * n;
        if (sc > bestScore) { bestScore = sc; best = c; }
    }
    return best;
}
