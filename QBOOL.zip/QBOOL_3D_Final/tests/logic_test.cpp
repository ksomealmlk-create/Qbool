// Unit tests for the pure game logic (no graphics). Run with: ctest
#include "game_logic.hpp"
#include <cmath>
#include <cstdio>
#include <cstdlib>

static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)

int main() {
    Board b;
    CHECK(b.openSum() == 78);
    CHECK(!b.highShut());
    CHECK(!b.allShut());

    // two different dice -> two options
    auto o = findOptions(b, 2, 3);
    CHECK(o.size() == 2);
    CHECK(o[0] == (uint16_t)((1u << 2) | (1u << 3)));
    CHECK(o[1] == (uint16_t)(1u << 5));
    // doubles -> only the sum
    o = findOptions(b, 3, 3);
    CHECK(o.size() == 1 && o[0] == (uint16_t)(1u << 6));
    // sum above 12 is impossible with two d6 (max 12) - 6+6 closes 12
    o = findOptions(b, 6, 6);
    CHECK(o.size() == 1 && o[0] == (uint16_t)(1u << 12));

    // closed tiles are not available
    b.open[5] = false; b.open[2] = false;
    o = findOptions(b, 2, 3);
    CHECK(o.empty());

    // one-die mode
    Board c; for (int n = 7; n <= 12; ++n) c.open[n] = false;
    CHECK(c.highShut());
    o = findOptions(c, 4, 0);
    CHECK(o.size() == 1 && o[0] == (uint16_t)(1u << 4));
    c.open[4] = false;
    CHECK(findOptions(c, 4, 0).empty());

    // shut everything
    Board d; d.shutAll();
    CHECK(d.allShut() && d.openSum() == 0);

    // DP sanity
    CHECK(std::fabs(expectedScore(0)) < 1e-6f);
    Board full;
    const float e = expectedScore(full.openMask());
    std::printf("optimal expected score from a fresh board: %.3f\n", e);
    CHECK(e > 0.0f && e < 78.0f);
    // fewer open tiles can never have a higher expectation than the open sum
    for (unsigned m = 2; m < 8192; m += 2) CHECK(expectedScore((uint16_t)m) <= (float)detail::sumOfMask((uint16_t)m) + 1e-4f);
    // survival chance of the full board is 100% (2..12 all reachable? 1+1 doubles -> tile 2)
    CHECK(survivalChance(full.openMask()) > 0.99f);

    // bots always return one of the options
    Board f;
    auto opts = findOptions(f, 1, 4);
    for (int diff = 0; diff < 3; ++diff) {
        uint16_t p = botPick(f, opts, (Difficulty)diff, 0.7f);
        bool ok = false; for (auto x : opts) if (x == p) ok = true;
        CHECK(ok);
    }
    // hard bot: given a board where closing the sum leaves a much better position
    CHECK(bestOptionIndex(f, opts) >= 0);

    // Monte-Carlo: hard bot should not do worse than easy bot on average
    auto play = [](Difficulty diff, unsigned seed) {
        std::srand(seed);
        double total = 0; const int N = 4000;
        for (int g = 0; g < N; ++g) {
            Board bd;
            while (true) {
                bool one = bd.highShut();
                int a = std::rand() % 6 + 1, bb = one ? 0 : std::rand() % 6 + 1;
                auto op = findOptions(bd, a, bb);
                if (op.empty()) { total += bd.openSum(); break; }
                uint16_t pick = botPick(bd, op, diff, (float)(std::rand() % 1000) / 1000.0f);
                for (int n = 1; n <= NUM_TILES; ++n) if (pick & (1u << n)) bd.open[n] = false;
                if (bd.allShut()) break;
            }
        }
        return total / N;
    };
    double easy = play(Difficulty::Easy, 1), normal = play(Difficulty::Normal, 1), hard = play(Difficulty::Hard, 1);
    std::printf("avg score  easy=%.2f  normal=%.2f  hard=%.2f  (DP optimum %.2f)\n", easy, normal, hard, e);
    CHECK(hard <= normal + 0.1);
    CHECK(normal <= easy + 0.1);
    CHECK(std::fabs(hard - e) < 1.5);   // simulation agrees with the exact DP

    if (fails == 0) std::printf("ALL TESTS PASSED\n");
    return fails == 0 ? 0 : 1;
}
