// Arabic text support for raylib (letter joining + right-to-left ordering).
// raylib does not shape Arabic by itself, so we convert the normal text to
// "presentation forms" and reverse it into visual order before drawing.
#pragma once
#include <string>
#include <vector>

namespace ar {

struct Form { unsigned base, iso, fin, ini, med; };
static const Form FORMS[] = {
    {0x0621,0xFE80,0x0000,0x0000,0x0000},
    {0x0622,0xFE81,0xFE82,0x0000,0x0000},
    {0x0623,0xFE83,0xFE84,0x0000,0x0000},
    {0x0624,0xFE85,0xFE86,0x0000,0x0000},
    {0x0625,0xFE87,0xFE88,0x0000,0x0000},
    {0x0626,0xFE89,0xFE8A,0xFE8B,0xFE8C},
    {0x0627,0xFE8D,0xFE8E,0x0000,0x0000},
    {0x0628,0xFE8F,0xFE90,0xFE91,0xFE92},
    {0x0629,0xFE93,0xFE94,0x0000,0x0000},
    {0x062A,0xFE95,0xFE96,0xFE97,0xFE98},
    {0x062B,0xFE99,0xFE9A,0xFE9B,0xFE9C},
    {0x062C,0xFE9D,0xFE9E,0xFE9F,0xFEA0},
    {0x062D,0xFEA1,0xFEA2,0xFEA3,0xFEA4},
    {0x062E,0xFEA5,0xFEA6,0xFEA7,0xFEA8},
    {0x062F,0xFEA9,0xFEAA,0x0000,0x0000},
    {0x0630,0xFEAB,0xFEAC,0x0000,0x0000},
    {0x0631,0xFEAD,0xFEAE,0x0000,0x0000},
    {0x0632,0xFEAF,0xFEB0,0x0000,0x0000},
    {0x0633,0xFEB1,0xFEB2,0xFEB3,0xFEB4},
    {0x0634,0xFEB5,0xFEB6,0xFEB7,0xFEB8},
    {0x0635,0xFEB9,0xFEBA,0xFEBB,0xFEBC},
    {0x0636,0xFEBD,0xFEBE,0xFEBF,0xFEC0},
    {0x0637,0xFEC1,0xFEC2,0xFEC3,0xFEC4},
    {0x0638,0xFEC5,0xFEC6,0xFEC7,0xFEC8},
    {0x0639,0xFEC9,0xFECA,0xFECB,0xFECC},
    {0x063A,0xFECD,0xFECE,0xFECF,0xFED0},
    {0x0641,0xFED1,0xFED2,0xFED3,0xFED4},
    {0x0642,0xFED5,0xFED6,0xFED7,0xFED8},
    {0x0643,0xFED9,0xFEDA,0xFEDB,0xFEDC},
    {0x0644,0xFEDD,0xFEDE,0xFEDF,0xFEE0},
    {0x0645,0xFEE1,0xFEE2,0xFEE3,0xFEE4},
    {0x0646,0xFEE5,0xFEE6,0xFEE7,0xFEE8},
    {0x0647,0xFEE9,0xFEEA,0xFEEB,0xFEEC},
    {0x0648,0xFEED,0xFEEE,0x0000,0x0000},
    {0x0649,0xFEEF,0xFEF0,0xFBE8,0xFBE9},
    {0x064A,0xFEF1,0xFEF2,0xFEF3,0xFEF4},
    {0x067E,0xFB56,0xFB57,0xFB58,0xFB59},
    {0x0686,0xFB7A,0xFB7B,0xFB7C,0xFB7D},
    {0x0698,0xFB8A,0xFB8B,0x0000,0x0000},
    {0x06A4,0xFB6A,0xFB6B,0xFB6C,0xFB6D},
    {0x06A9,0xFB8E,0xFB8F,0xFB90,0xFB91},
    {0x06AF,0xFB92,0xFB93,0xFB94,0xFB95},
    {0x06CC,0xFBFC,0xFBFD,0xFBFE,0xFBFF},
};

inline const Form* Find(unsigned c) {
    for (const Form& f : FORMS) if (f.base == c) return &f;
    return nullptr;
}

inline std::vector<unsigned> Decode(const std::string& s) {
    std::vector<unsigned> out;
    for (size_t i = 0; i < s.size();) {
        unsigned char c = (unsigned char)s[i];
        unsigned cp; int n;
        if (c < 0x80)              { cp = c;        n = 1; }
        else if ((c >> 5) == 0x6)  { cp = c & 0x1F; n = 2; }
        else if ((c >> 4) == 0xE)  { cp = c & 0x0F; n = 3; }
        else if ((c >> 3) == 0x1E) { cp = c & 0x07; n = 4; }
        else                       { cp = '?';      n = 1; }
        for (int k = 1; k < n && i + k < s.size(); ++k) cp = (cp << 6) | ((unsigned char)s[i + k] & 0x3F);
        out.push_back(cp);
        i += n;
    }
    return out;
}

inline void Encode(unsigned cp, std::string& out) {
    if (cp < 0x80) out += (char)cp;
    else if (cp < 0x800) { out += (char)(0xC0 | (cp >> 6)); out += (char)(0x80 | (cp & 0x3F)); }
    else if (cp < 0x10000) { out += (char)(0xE0 | (cp >> 12)); out += (char)(0x80 | ((cp >> 6) & 0x3F)); out += (char)(0x80 | (cp & 0x3F)); }
    else { out += (char)(0xF0 | (cp >> 18)); out += (char)(0x80 | ((cp >> 12) & 0x3F)); out += (char)(0x80 | ((cp >> 6) & 0x3F)); out += (char)(0x80 | (cp & 0x3F)); }
}

// Arabic letters (they need shaping + right-to-left).
inline bool IsLetter(unsigned c) { return c >= 0x0621 && c <= 0x06FF && c != 0x060C && c != 0x061B && c != 0x061F; }
inline bool IsArabicAny(unsigned c) { return (c >= 0x0600 && c <= 0x06FF) || (c >= 0xFB50 && c <= 0xFDFF) || (c >= 0xFE70 && c <= 0xFEFF); }
// Strong left-to-right: Latin letters and digits.
inline bool IsLtr(unsigned c) { return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'); }

// 1) joining: logical letters -> presentation forms (still in logical order)
inline std::vector<unsigned> Join(const std::vector<unsigned>& in) {
    std::vector<unsigned> out;
    const size_t n = in.size();
    for (size_t i = 0; i < n; ++i) {
        const unsigned c = in[i];
        const Form* f = Find(c);
        if (!f) { out.push_back(c); continue; }
        // does the previous letter connect to us?
        bool prevJoins = false;
        if (i > 0) { const Form* p = Find(in[i - 1]); prevJoins = p && p->ini; }
        // lam + alef ligature
        if (c == 0x0644 && i + 1 < n) {
            unsigned a = in[i + 1], iso = 0, fin = 0;
            if (a == 0x0622) { iso = 0xFEF5; fin = 0xFEF6; }
            else if (a == 0x0623) { iso = 0xFEF7; fin = 0xFEF8; }
            else if (a == 0x0625) { iso = 0xFEF9; fin = 0xFEFA; }
            else if (a == 0x0627) { iso = 0xFEFB; fin = 0xFEFC; }
            if (iso) { out.push_back(prevJoins ? fin : iso); ++i; continue; }
        }
        bool nextJoins = false;
        if (f->ini && i + 1 < n) { const Form* x = Find(in[i + 1]); nextJoins = x && x->fin; }
        unsigned g;
        if (prevJoins && nextJoins && f->med) g = f->med;
        else if (prevJoins && f->fin)         g = f->fin;
        else if (nextJoins && f->ini)         g = f->ini;
        else                                  g = f->iso ? f->iso : c;
        out.push_back(g);
    }
    return out;
}

inline unsigned Mirror(unsigned c) {
    switch (c) { case '(': return ')'; case ')': return '('; case '[': return ']'; case ']': return '['; case '<': return '>'; case '>': return '<'; }
    return c;
}

// 2) ordering: logical -> visual (right-to-left paragraph)
inline std::vector<unsigned> Reorder(const std::vector<unsigned>& in) {
    const size_t n = in.size();
    std::vector<int> cls(n);                       // 0 = LTR, 1 = RTL
    std::vector<bool> neutral(n, false);
    for (size_t i = 0; i < n; ++i) {
        if (IsLtr(in[i])) cls[i] = 0;
        else if (IsArabicAny(in[i]) && !(in[i] == 0x060C || in[i] == 0x061B || in[i] == 0x061F)) cls[i] = 1;
        else { cls[i] = 1; neutral[i] = true; }
    }
    // neutrals between two LTR characters belong to the LTR run ("2 + 3 = 5")
    for (size_t i = 0; i < n;) {
        if (!neutral[i]) { ++i; continue; }
        size_t j = i;
        while (j < n && neutral[j]) ++j;
        const bool leftLtr  = i > 0 && !neutral[i - 1] && cls[i - 1] == 0;
        const bool rightLtr = j < n && !neutral[j] && cls[j] == 0;
        if (leftLtr && rightLtr) for (size_t k = i; k < j; ++k) cls[k] = 0;
        i = j;
    }
    // split into runs, output runs from last to first
    std::vector<std::pair<size_t, size_t>> runs;
    for (size_t i = 0; i < n;) {
        size_t j = i;
        while (j < n && cls[j] == cls[i]) ++j;
        runs.push_back({i, j});
        i = j;
    }
    std::vector<unsigned> out;
    for (size_t r = runs.size(); r-- > 0;) {
        const size_t a = runs[r].first, b = runs[r].second;
        if (cls[a] == 0) { for (size_t k = a; k < b; ++k) out.push_back(in[k]); }
        else             { for (size_t k = b; k-- > a;) out.push_back(Mirror(in[k])); }
    }
    return out;
}

// Text without Arabic letters is returned unchanged (English UI).
inline std::string Shape(const std::string& s) {
    const std::vector<unsigned> cps = Decode(s);
    bool any = false;
    for (unsigned c : cps) if (IsLetter(c)) { any = true; break; }
    if (!any) return s;
    const std::vector<unsigned> vis = Reorder(Join(cps));
    std::string out;
    for (unsigned c : vis) Encode(c, out);
    return out;
}

} // namespace ar
