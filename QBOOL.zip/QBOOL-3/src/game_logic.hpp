// Q BOOL - pure game logic (no graphics), easy to test.
#pragma once
#include <array>
#include <cstdint>
#include <vector>

constexpr int NUM_TILES = 12;

struct Board {
    std::array<bool, NUM_TILES + 1> open{};   // index 1..12

    Board() { reset(); }
    void reset() { open.fill(true); open[0] = false; }
    void shutAll() { open.fill(false); }

    int openSum() const {
        int s = 0;
        for (int n = 1; n <= NUM_TILES; ++n) if (open[n]) s += n;
        return s;
    }
    bool allShut() const { return openSum() == 0; }
    // When tiles 7..12 are all shut, the player rolls ONE die only.
    bool highShut() const {
        for (int n = 7; n <= NUM_TILES; ++n) if (open[n]) return false;
        return true;
    }
};

// Q BOOL rule: ONE roll per turn. With dice a and b you may either
//   (1) close tile a AND tile b (two different open tiles), or
//   (2) close the single tile a+b (if open).
// With one die (tiles 7..12 shut) you close tile a only.
// Each option is a bit mask: bit n set = tile n is closed.
inline std::vector<uint16_t> findOptions(const Board& b, int d1, int d2) {
    std::vector<uint16_t> out;
    if (d2 == 0) {
        if (d1 >= 1 && d1 <= NUM_TILES && b.open[d1]) out.push_back((uint16_t)(1u << d1));
        return out;
    }
    if (d1 != d2 && b.open[d1] && b.open[d2])
        out.push_back((uint16_t)((1u << d1) | (1u << d2)));
    const int total = d1 + d2;
    if (total >= 1 && total <= NUM_TILES && b.open[total])
        out.push_back((uint16_t)(1u << total));
    return out;
}

// Computer player: prefers closing the biggest tiles (lowest leftover score).
inline uint16_t botPick(const std::vector<uint16_t>& combos) {
    uint16_t best = 0;
    long bestScore = -1;
    for (uint16_t c : combos) {
        long sc = 0;
        for (int n = 1; n <= NUM_TILES; ++n) if (c & (1u << n)) sc += (long)n * n;
        if (sc > bestScore) { bestScore = sc; best = c; }
    }
    return best;
}

inline int selectionSum(uint16_t bits) {
    int s = 0;
    for (int n = 1; n <= NUM_TILES; ++n) if (bits & (1u << n)) s += n;
    return s;
}
