// Q BOOL - 3D tile-closing dice board game (2-4 players), C++ + raylib.
// One roll per turn. Close the two dice tiles (e.g. 2 and 3) OR just their sum (5).
// When you can't move, your open tiles are your score. Lowest score wins!
#include "raylib.h"
#include "raymath.h"
#include "rlgl.h"
#include "game_logic.hpp"
#include "arabic_text.hpp"
#include "font_data.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <ctime>
#include <string>
#include <vector>

#if defined(__EMSCRIPTEN__)
#include <emscripten/emscripten.h>
#endif

namespace {

// ------------------------------------------------------------ constants
const float PI_F      = 3.14159265f;
const float HINGE_Y   = 0.47f;
const float HINGE_Z   = 6.2f;
const float TILE_W    = 0.7f;
const float TILE_L    = 1.2f;
const float TILE_T    = 0.12f;
const float TILE_STEP = 0.8f;
const float OPEN_ANG  = 68.0f;
const float SEL_ANG   = 38.0f;

const Color SEAT_COL[4]  = { Color{50,110,230,255}, Color{225,55,55,255},
                             Color{45,175,85,255},  Color{240,200,40,255} };
const char* SEAT_NAME[4] = { "BLUE", "RED", "GREEN", "YELLOW" };
const char* SEAT_NAME_AR[4] = { "الأزرق", "الأحمر", "الأخضر", "الأصفر" };
const Color CLOSED_COL   = Color{70,55,45,255};

enum class State { Menu, WaitRoll, Rolling, Choose, Pause, GameOver };
enum class PauseNext { GoRoll, EndTurn };

struct Game {
    State state = State::Menu;
    int numPlayers = 4;
    bool vsComputer = false;

    int seats[4] = {0, 1, 2, 3};     // turn index -> seat
    Board boards[4];                 // indexed by SEAT
    float angle[4][NUM_TILES + 1] = {};
    int scores[4] = {0, 0, 0, 0};    // indexed by turn index
    bool done[4] = {false, false, false, false};
    int cur = 0;                     // current turn index

    int d1 = 1, d2 = 1, rollTotal = 2;
    bool oneDie = false;
    float rollT = 1.0f;
    Vector3 dieStart[2] = {}, dieEnd[2] = {};
    float dieYaw[2] = {0, 0};
    float dieSpin[2][2] = {};

    uint16_t selected = 0;
    std::vector<uint16_t> combos;
    float botTimer = 0.0f;
    int botStage = 0;

    float timer = 0.0f;
    PauseNext pauseNext = PauseNext::GoRoll;
    int msgKind = 0;                 // 0 = none, 1 = "no move", 2 = "shut the box"
    int msgSeat = 0, msgScore = 0;

    float camAngle = 0.0f;
    float camDiff = 0.0f;            // how far the camera still has to turn (radians)
};

Game g;
Camera3D cam;
Vector2 g_mp = {0, 0};
bool g_tap = false;
bool g_ar = true;          // true = Arabic, false = English
bool g_hints = true;       // blinking hints on/off
bool g_settings = false;   // settings screen open
double g_backT = -10.0;    // time of the last "back" press (double back = main menu)

int CurSeat() { return g.seats[g.cur]; }
bool IsBot(int turnIdx) { return g.vsComputer && turnIdx != 0; }
float UIScale() {
    float u = std::min(GetScreenWidth() / 960.0f, GetScreenHeight() / 540.0f);
    return std::max(0.55f, std::min(u, 2.2f));
}
float Clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
// Pick the English or Arabic text depending on the chosen language.
const char* T(const char* en, const char* ar) { return g_ar ? ar : en; }
const char* SeatName(int s) { return g_ar ? SEAT_NAME_AR[s] : SEAT_NAME[s]; }


// ------------------------------------------------------------ realistic graphics
// Everything is generated at start-up (no image files needed): wood, felt,
// lacquer and stone textures, rounded meshes and a lit shader.
float HashF(int x, int y, int seed) {
    unsigned h = (unsigned)x * 374761393u + (unsigned)y * 668265263u + (unsigned)seed * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    h ^= h >> 16;
    return (float)(h & 0xFFFFFFu) / 16777215.0f;
}
float SmoothF(float t) { return t * t * (3.0f - 2.0f * t); }
float VNoise(float x, float y, int px, int py, int seed) {
    const int xi = (int)floorf(x), yi = (int)floorf(y);
    const float fx = x - xi, fy = y - yi;
    const int x0 = ((xi % px) + px) % px, x1 = (((xi + 1) % px) + px) % px;
    const int y0 = ((yi % py) + py) % py, y1 = (((yi + 1) % py) + py) % py;
    const float a = HashF(x0, y0, seed), b = HashF(x1, y0, seed);
    const float c = HashF(x0, y1, seed), d = HashF(x1, y1, seed);
    const float u = SmoothF(fx), v = SmoothF(fy);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
float FBM(float x, float y, int px, int py, int oct, int seed) {   // tileable noise
    float sum = 0.0f, amp = 0.5f, norm = 0.0f;
    for (int o = 0; o < oct; ++o) {
        sum += amp * VNoise(x, y, px, py, seed + o);
        norm += amp;
        x *= 2.0f; y *= 2.0f; px *= 2; py *= 2; amp *= 0.5f;
    }
    return sum / norm;
}
unsigned char Byte(float v) { return (unsigned char)(Clampf(v, 0.0f, 1.0f) * 255.0f); }

Texture2D FinishTexture(Image img) {
    Texture2D t = LoadTextureFromImage(img);
    UnloadImage(img);
    GenTextureMipmaps(&t);
    SetTextureFilter(t, TEXTURE_FILTER_TRILINEAR);
    SetTextureWrap(t, TEXTURE_WRAP_REPEAT);
    return t;
}

Texture2D MakeWoodTex(int S) {
    Image img = GenImageColor(S, S, WHITE);
    Color* px = (Color*)img.data;
    for (int y = 0; y < S; ++y) {
        for (int x = 0; x < S; ++x) {
            const float u = (float)x / S, v = (float)y / S;
            const float warp = FBM(u * 2.0f, v * 3.0f, 2, 3, 3, 11);
            const float rings = 0.5f + 0.5f * sinf((v * 14.0f + warp * 5.0f) * 2.0f * PI_F);
            const float streak = FBM(u * 3.0f, v * 60.0f, 3, 60, 3, 23);
            float t = 0.40f * rings + 0.60f * streak;
            t = t * 0.92f + HashF(x, y, 5) * 0.05f;
            const float r = 88.0f + (172.0f - 88.0f) * t;
            const float g = 54.0f + (116.0f - 54.0f) * t;
            const float b = 30.0f + (68.0f - 30.0f) * t;
            px[y * S + x] = Color{ Byte(r / 255.0f), Byte(g / 255.0f), Byte(b / 255.0f), 255 };
        }
    }
    return FinishTexture(img);
}
Texture2D MakeFeltTex(int S) {
    Image img = GenImageColor(S, S, WHITE);
    Color* px = (Color*)img.data;
    for (int y = 0; y < S; ++y)
        for (int x = 0; x < S; ++x) {
            const float u = (float)x / S, v = (float)y / S;
            const float n = 0.78f + 0.14f * HashF(x, y, 9) + 0.20f * (FBM(u * 8.0f, v * 8.0f, 8, 8, 3, 31) - 0.5f);
            const unsigned char c = Byte(n);
            px[y * S + x] = Color{ c, c, c, 255 };
        }
    return FinishTexture(img);
}
Texture2D MakePaintTex(int S) {          // lacquered wood grain (tinted by colour)
    Image img = GenImageColor(S, S, WHITE);
    Color* px = (Color*)img.data;
    for (int y = 0; y < S; ++y)
        for (int x = 0; x < S; ++x) {
            const float u = (float)x / S, v = (float)y / S;
            const float n = 0.86f + 0.14f * FBM(u * 2.0f, v * 40.0f, 2, 40, 3, 41) + 0.03f * HashF(x, y, 7);
            const unsigned char c = Byte(n);
            px[y * S + x] = Color{ c, c, c, 255 };
        }
    return FinishTexture(img);
}
Texture2D MakeStoneTex(int S) {          // mottled glazed stone (dice)
    Image img = GenImageColor(S, S, WHITE);
    Color* px = (Color*)img.data;
    for (int y = 0; y < S; ++y)
        for (int x = 0; x < S; ++x) {
            const float u = (float)x / S, v = (float)y / S;
            const float n = 0.70f + 0.30f * FBM(u * 6.0f, v * 6.0f, 6, 6, 4, 51) + 0.05f * (HashF(x, y, 3) - 0.5f);
            const unsigned char c = Byte(n);
            px[y * S + x] = Color{ c, c, c, 255 };
        }
    return FinishTexture(img);
}

// Box with rounded edges: cube surface projected on an inner box + sphere radius r.
Mesh MakeRoundedBox(float sx, float sy, float sz, float r, int N, float uvSize) {
    Mesh m = {};
    const int vper = (N + 1) * (N + 1);
    m.vertexCount = 6 * vper;
    m.triangleCount = 6 * N * N * 2;
    m.vertices  = (float*)MemAlloc(m.vertexCount * 3 * sizeof(float));
    m.normals   = (float*)MemAlloc(m.vertexCount * 3 * sizeof(float));
    m.texcoords = (float*)MemAlloc(m.vertexCount * 2 * sizeof(float));
    m.indices   = (unsigned short*)MemAlloc(m.triangleCount * 3 * sizeof(unsigned short));
    const float half[3] = { sx * 0.5f, sy * 0.5f, sz * 0.5f };
    int vi = 0, ii = 0;
    for (int f = 0; f < 6; ++f) {
        const int axis = f / 2;
        const float sign = (f % 2) ? -1.0f : 1.0f;
        const int a1 = (axis + 1) % 3, a2 = (axis + 2) % 3;
        const int base = f * vper;
        for (int j = 0; j <= N; ++j) {
            for (int i = 0; i <= N; ++i) {
                const float s = -1.0f + 2.0f * i / N, t = -1.0f + 2.0f * j / N;
                float p[3];
                p[axis] = sign;
                p[a1] = sinf(s * PI_F * 0.5f);
                p[a2] = sinf(t * PI_F * 0.5f);
                float pos[3], nrm[3], d[3];
                float len = 0.0f;
                for (int k = 0; k < 3; ++k) {
                    const float q = p[k] * half[k];
                    const float lim = half[k] - r;
                    const float in = Clampf(q, -lim, lim);
                    d[k] = q - in;
                    pos[k] = in;
                    len += d[k] * d[k];
                }
                len = sqrtf(len);
                for (int k = 0; k < 3; ++k) nrm[k] = 0.0f;
                if (len > 1e-5f) { for (int k = 0; k < 3; ++k) nrm[k] = d[k] / len; }
                else nrm[axis] = sign;
                for (int k = 0; k < 3; ++k) pos[k] += nrm[k] * r;
                m.vertices[vi * 3 + 0] = pos[0];
                m.vertices[vi * 3 + 1] = pos[1];
                m.vertices[vi * 3 + 2] = pos[2];
                m.normals[vi * 3 + 0] = nrm[0];
                m.normals[vi * 3 + 1] = nrm[1];
                m.normals[vi * 3 + 2] = nrm[2];
                m.texcoords[vi * 2 + 0] = pos[a1] / uvSize;
                m.texcoords[vi * 2 + 1] = pos[a2] / uvSize;
                ++vi;
            }
        }
        for (int j = 0; j < N; ++j) {
            for (int i = 0; i < N; ++i) {
                const int v00 = base + j * (N + 1) + i, v10 = v00 + 1;
                const int v01 = v00 + (N + 1), v11 = v01 + 1;
                if (sign > 0) {
                    m.indices[ii++] = (unsigned short)v00; m.indices[ii++] = (unsigned short)v10; m.indices[ii++] = (unsigned short)v11;
                    m.indices[ii++] = (unsigned short)v00; m.indices[ii++] = (unsigned short)v11; m.indices[ii++] = (unsigned short)v01;
                } else {
                    m.indices[ii++] = (unsigned short)v00; m.indices[ii++] = (unsigned short)v11; m.indices[ii++] = (unsigned short)v10;
                    m.indices[ii++] = (unsigned short)v00; m.indices[ii++] = (unsigned short)v01; m.indices[ii++] = (unsigned short)v11;
                }
            }
        }
    }
    UploadMesh(&m, false);
    return m;
}

// GLSL 330 on desktop, GLSL 100 (ES2) on Android / Web.
#if defined(__ANDROID__) || defined(__EMSCRIPTEN__)
const char* VS_HEAD = "#version 100\n#define ATTR attribute\n#define VOUT varying\n";
const char* FS_HEAD = "#version 100\n#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n#define VIN varying\n#define TEX texture2D\n#define FRAGOUT\n#define SETCOL(c) gl_FragColor = (c)\n";
#else
const char* VS_HEAD = "#version 330\n#define ATTR in\n#define VOUT out\n";
const char* FS_HEAD = "#version 330\n#define VIN in\n#define TEX texture\n#define FRAGOUT out vec4 finalColor;\n#define SETCOL(c) finalColor = (c)\n";
#endif

const char* VS_BODY = R"GLSL(
ATTR vec3 vertexPosition;
ATTR vec2 vertexTexCoord;
ATTR vec3 vertexNormal;
uniform mat4 mvp;
uniform mat4 matModel;
uniform mat4 matNormal;
VOUT vec3 fragPos;
VOUT vec2 fragUV;
VOUT vec3 fragN;
void main() {
    fragPos = vec3(matModel * vec4(vertexPosition, 1.0));
    fragUV = vertexTexCoord;
    fragN = normalize(vec3(matNormal * vec4(vertexNormal, 0.0)));
    gl_Position = mvp * vec4(vertexPosition, 1.0);
}
)GLSL";

const char* FS_BODY = R"GLSL(
VIN vec3 fragPos;
VIN vec2 fragUV;
VIN vec3 fragN;
uniform sampler2D texture0;
uniform vec4 colDiffuse;
uniform vec3 viewPos;
uniform vec3 lightDir;
uniform vec2 matParams;   // x = specular strength, y = shininess
uniform float uvScale;
uniform vec3 glow;
FRAGOUT
void main() {
    vec3 N = normalize(fragN);
    vec3 V = normalize(viewPos - fragPos);
    vec3 albedo = TEX(texture0, fragUV * uvScale).rgb * colDiffuse.rgb;
    vec3 L1 = normalize(lightDir);
    vec3 L2 = normalize(vec3(-0.55, 0.45, -0.45));
    float d1 = max(dot(N, L1), 0.0);
    float d2 = max(dot(N, L2), 0.0);
    float hemi = 0.5 + 0.5 * N.y;
    vec3 amb = mix(vec3(0.20, 0.17, 0.15), vec3(0.40, 0.42, 0.48), hemi);
    vec3 H = normalize(L1 + V);
    float spec = pow(max(dot(N, H), 0.0), matParams.y) * matParams.x * step(0.001, d1);
    float fres = pow(1.0 - max(dot(N, V), 0.0), 4.0) * 0.10 * matParams.x;
    vec3 col = albedo * (amb + vec3(1.00, 0.93, 0.82) * d1 + vec3(0.20, 0.26, 0.36) * d2);
    col += vec3(1.0, 0.96, 0.88) * spec + vec3(fres) + glow;
    col = col / (1.0 + 0.12 * col);
    SETCOL(vec4(col, 1.0));
}
)GLSL";

struct Gfx {
    bool ok = false;
    Shader lit = {};
    int locView = -1, locLight = -1, locParams = -1, locUV = -1, locGlow = -1;
    Material mat = {};
    Texture2D wood = {}, felt = {}, paint = {}, stone = {}, blob = {};
    Mesh plane = {}, board = {}, rimLong = {}, rimShort = {}, feltBox = {}, strip = {};
    Mesh tile = {}, die = {}, rod = {}, pip = {};
};
Gfx gx;

void InitGraphics() {
    const std::string vs = std::string(VS_HEAD) + VS_BODY;
    const std::string fs = std::string(FS_HEAD) + FS_BODY;
    gx.lit = LoadShaderFromMemory(vs.c_str(), fs.c_str());
    gx.ok = gx.lit.id > 0 && gx.lit.id != rlGetShaderIdDefault();
    gx.mat = LoadMaterialDefault();
    if (gx.ok) {
        gx.lit.locs[SHADER_LOC_MATRIX_MODEL]  = GetShaderLocation(gx.lit, "matModel");
        gx.lit.locs[SHADER_LOC_MATRIX_NORMAL] = GetShaderLocation(gx.lit, "matNormal");
        gx.lit.locs[SHADER_LOC_VECTOR_VIEW]   = GetShaderLocation(gx.lit, "viewPos");
        gx.lit.locs[SHADER_LOC_COLOR_DIFFUSE] = GetShaderLocation(gx.lit, "colDiffuse");
        gx.lit.locs[SHADER_LOC_MAP_DIFFUSE]   = GetShaderLocation(gx.lit, "texture0");
        gx.locView   = GetShaderLocation(gx.lit, "viewPos");
        gx.locLight  = GetShaderLocation(gx.lit, "lightDir");
        gx.locParams = GetShaderLocation(gx.lit, "matParams");
        gx.locUV     = GetShaderLocation(gx.lit, "uvScale");
        gx.locGlow   = GetShaderLocation(gx.lit, "glow");
        gx.mat.shader = gx.lit;
    }

    gx.wood  = MakeWoodTex(512);
    gx.felt  = MakeFeltTex(256);
    gx.paint = MakePaintTex(256);
    gx.stone = MakeStoneTex(256);
    {
        Image b = GenImageGradientRadial(128, 128, 0.15f, Color{0, 0, 0, 255}, Color{0, 0, 0, 0});
        gx.blob = LoadTextureFromImage(b);
        UnloadImage(b);
        SetTextureFilter(gx.blob, TEXTURE_FILTER_BILINEAR);
    }

    gx.plane    = GenMeshPlane(60.0f, 60.0f, 1, 1);
    gx.board    = MakeRoundedBox(13.8f, 0.45f, 13.8f, 0.10f, 24, 3.5f);
    gx.rimLong  = MakeRoundedBox(13.8f, 0.18f, 0.40f, 0.06f, 20, 3.5f);
    gx.rimShort = MakeRoundedBox(0.40f, 0.18f, 13.0f, 0.06f, 20, 3.5f);
    gx.feltBox  = MakeRoundedBox(10.1f, 0.04f, 10.1f, 0.015f, 12, 1.6f);
    gx.strip    = MakeRoundedBox(9.6f, 0.04f, 1.5f, 0.015f, 12, 1.6f);
    gx.tile     = MakeRoundedBox(TILE_W, TILE_T, TILE_L, 0.035f, 14, 1.2f);
    gx.die      = MakeRoundedBox(0.6f, 0.6f, 0.6f, 0.075f, 20, 0.6f);
    gx.rod      = GenMeshCylinder(0.05f, 9.7f, 14);
    gx.pip      = GenMeshCylinder(0.052f, 0.04f, 16);
}

void DrawLit(const Mesh& m, const Texture2D& tex, Color tint, float spec, float shin,
             float uvScale = 1.0f, float gr = 0.0f, float gg = 0.0f, float gb = 0.0f) {
    gx.mat.maps[MATERIAL_MAP_DIFFUSE].texture = tex;
    gx.mat.maps[MATERIAL_MAP_DIFFUSE].color = tint;
    if (gx.ok) {
        float p[2] = { spec, shin };
        float gl[3] = { gr, gg, gb };
        SetShaderValue(gx.lit, gx.locParams, p, SHADER_UNIFORM_VEC2);
        SetShaderValue(gx.lit, gx.locUV, &uvScale, SHADER_UNIFORM_FLOAT);
        SetShaderValue(gx.lit, gx.locGlow, gl, SHADER_UNIFORM_VEC3);
    }
    DrawMesh(m, gx.mat, MatrixIdentity());
}

// Soft contact shadow lying on a horizontal surface.
void DrawBlob(float x, float y, float z, float rx, float rz, float alpha) {
    rlSetTexture(gx.blob.id);
    rlBegin(RL_QUADS);
    rlColor4f(1.0f, 1.0f, 1.0f, alpha);
    rlNormal3f(0.0f, 1.0f, 0.0f);
    rlTexCoord2f(0.0f, 0.0f); rlVertex3f(x - rx, y, z - rz);
    rlTexCoord2f(0.0f, 1.0f); rlVertex3f(x - rx, y, z + rz);
    rlTexCoord2f(1.0f, 1.0f); rlVertex3f(x + rx, y, z + rz);
    rlTexCoord2f(1.0f, 0.0f); rlVertex3f(x + rx, y, z - rz);
    rlEnd();
    rlSetTexture(0);
}

// ------------------------------------------------------------ game flow
void StartGame() {
    const int n = g.numPlayers;
    if (n == 2)      { g.seats[0] = 0; g.seats[1] = 2; }
    else             { for (int i = 0; i < n; ++i) g.seats[i] = i; }
    bool active[4] = {false, false, false, false};
    for (int i = 0; i < n; ++i) active[g.seats[i]] = true;
    for (int s = 0; s < 4; ++s) {
        g.boards[s].reset();
        if (!active[s]) g.boards[s].shutAll();
        for (int t = 0; t <= NUM_TILES; ++t) g.angle[s][t] = 0.0f;
    }
    for (int i = 0; i < 4; ++i) { g.scores[i] = 0; g.done[i] = false; }
    g.cur = 0;
    g.selected = 0;
    g.rollT = 1.0f;
    g.d1 = g.d2 = 0;
    g.rollTotal = 0;
    g.msgKind = 0;
    g.botTimer = 0.9f;
    g.state = State::WaitRoll;
}

void ToMenu() {
    for (int s = 0; s < 4; ++s) g.boards[s].reset();
    g.selected = 0;
    g.rollT = 1.0f;
    g.d1 = g.d2 = 0;
    g.rollTotal = 0;
    g.cur = 0;
    g.msgKind = 0;
    g.state = State::Menu;
}

void DoRoll() {
    const int seat = CurSeat();
    g.oneDie = g.boards[seat].highShut();
    g.d1 = GetRandomValue(1, 6);
    g.d2 = g.oneDie ? 0 : GetRandomValue(1, 6);
    g.rollTotal = g.d1 + g.d2;
    g.rollT = 0.0f;

    const float phi = seat * PI_F / 2.0f;
    const float sx = sinf(phi), sz = cosf(phi);
    for (int i = 0; i < 2; ++i) {
        float jx = GetRandomValue(-30, 30) / 100.0f;
        float jz = GetRandomValue(-30, 30) / 100.0f;
        if (g.oneDie) {
            g.dieEnd[i] = Vector3{ 0.0f + jx, 0.765f, 0.0f + jz };
        } else {
            g.dieEnd[i] = Vector3{ (i == 0 ? -0.95f : 0.95f) + jx, 0.765f,
                                   (i == 0 ? 0.3f : -0.3f) + jz };
        }
        g.dieStart[i] = Vector3{ sx * 8.0f + (i == 0 ? -0.8f : 0.8f) * sz, 3.2f,
                                 sz * 8.0f - (i == 0 ? -0.8f : 0.8f) * sx };
        g.dieYaw[i] = (float)GetRandomValue(0, 359);
        g.dieSpin[i][0] = (GetRandomValue(0, 1) ? 1.0f : -1.0f) * (700.0f + GetRandomValue(0, 400));
        g.dieSpin[i][1] = (GetRandomValue(0, 1) ? 1.0f : -1.0f) * (600.0f + GetRandomValue(0, 400));
    }
    g.selected = 0;
    g.msgKind = 0;
    g.state = State::Rolling;
}

void EnterChoose() {
    const int seat = CurSeat();
    g.combos = findOptions(g.boards[seat], g.d1, g.d2);
    g.selected = 0;
    if (g.combos.empty()) {
        g.scores[g.cur] = g.boards[seat].openSum();
        g.done[g.cur] = true;
        g.msgKind = 1; g.msgSeat = seat; g.msgScore = g.scores[g.cur];
        g.state = State::Pause;
        g.pauseNext = PauseNext::EndTurn;
        g.timer = 2.2f;
    } else {
        g.state = State::Choose;
        g.botTimer = 1.0f;
        g.botStage = 0;
    }
}

void EndTurn() {
    g.selected = 0;
    g.msgKind = 0;
    g.d1 = g.d2 = 0;          // dice leave the table between turns
    g.rollTotal = 0;
    g.rollT = 1.0f;
    for (int k = 1; k <= g.numPlayers; ++k) {
        const int c = (g.cur + k) % g.numPlayers;
        if (!g.done[c]) {
            g.cur = c;
            g.state = State::WaitRoll;
            g.botTimer = 1.0f;
            return;
        }
    }
    g.state = State::GameOver;
}

void ConfirmSelection() {
    const int seat = CurSeat();
    for (int n = 1; n <= NUM_TILES; ++n)
        if (g.selected & (1u << n)) g.boards[seat].open[n] = false;
    g.selected = 0;
    if (g.boards[seat].allShut()) {
        g.scores[g.cur] = 0;
        g.done[g.cur] = true;
        g.msgKind = 2; g.msgSeat = seat; g.msgScore = 0;
        g.state = State::Pause;
        g.pauseNext = PauseNext::EndTurn;
        g.timer = 2.6f;
    } else {
        g.msgKind = 0;
        g.state = State::Pause;
        g.pauseNext = PauseNext::EndTurn;
        g.timer = 1.0f;
    }
}

// ------------------------------------------------------------ geometry
Vector3 TileCenter(int seat, int n, float angDeg) {
    const float lx = (n - 6.5f) * TILE_STEP;
    const float th = angDeg * PI_F / 180.0f;
    const float ly = HINGE_Y + 0.6f * sinf(th) + 0.06f * cosf(th);
    const float lz = HINGE_Z - 0.6f * cosf(th) + 0.06f * sinf(th);
    const float phi = seat * PI_F / 2.0f;
    return Vector3{ lx * cosf(phi) + lz * sinf(phi), ly, -lx * sinf(phi) + lz * cosf(phi) };
}

// Returns the open tile (1..12) of `seat` nearest to the pointer, or 0.
int PickTile(int seat, Vector2 mp) {
    int best = 0;
    float bestD = 1e9f;
    const float phi = seat * PI_F / 2.0f;
    for (int n = 1; n <= NUM_TILES; ++n) {
        if (!g.boards[seat].open[n]) continue;
        Vector3 c = TileCenter(seat, n, g.angle[seat][n]);
        Vector2 s = GetWorldToScreen(c, cam);
        Vector3 r = Vector3{ c.x + 0.4f * cosf(phi), c.y, c.z - 0.4f * sinf(phi) };
        Vector2 s2 = GetWorldToScreen(r, cam);
        float halfW = hypotf(s2.x - s.x, s2.y - s.y);
        float d = hypotf(mp.x - s.x, mp.y - s.y);
        if (d < halfW * 1.25f && d < bestD) { bestD = d; best = n; }
    }
    return best;
}

Rectangle RollRect() {
    float u = UIScale();
    float w = 230 * u, h = 62 * u;
    return Rectangle{ GetScreenWidth() / 2.0f - w / 2, GetScreenHeight() - h - 24 * u, w, h };
}
Rectangle SettingsBtnRect() {
    float u = UIScale();
    return Rectangle{ 14 * u, 52 * u, 150 * u, 42 * u };
}
Rectangle OptionRect(int i, int n) {
    float u = UIScale();
    float w = 250 * u, h = 58 * u, gap = 18 * u;
    float total = n * w + (n - 1) * gap;
    return Rectangle{ GetScreenWidth() / 2.0f - total / 2 + i * (w + gap),
                      GetScreenHeight() - h - 24 * u, w, h };
}

// ------------------------------------------------------------ update
void ReadInput() {
    static bool touchPrev = false;
    static double lastTap = -10.0;
    g_mp = GetMousePosition();
    bool touchNow = GetTouchPointCount() > 0;
    if (touchNow) g_mp = GetTouchPosition(0);
    g_tap = IsMouseButtonPressed(MOUSE_BUTTON_LEFT) || (touchNow && !touchPrev);
    touchPrev = touchNow;
    double now = GetTime();
    if (g_tap) {
        if (now - lastTap < 0.30) g_tap = false;   // ignore duplicate touch+mouse events
        else lastTap = now;
    }
}

void UpdateCamera(float dt) {
    float target;
    if (g.state == State::Menu) {
        g.camAngle += dt * 0.15f;
        target = g.camAngle;
    } else {
        target = CurSeat() * PI_F / 2.0f;
    }
    float diff = target - g.camAngle;
    while (diff > PI_F)  diff -= 2 * PI_F;
    while (diff < -PI_F) diff += 2 * PI_F;
    g.camDiff = diff;
    g.camAngle += diff * std::min(1.0f, dt * 3.5f);

    float aspect = (float)GetScreenWidth() / (float)GetScreenHeight();
    float k = aspect < 1.5f ? 1.5f / aspect : 1.0f;
    k = Clampf(k, 1.0f, 2.4f);
    const float R = 11.0f * k, H = 15.0f * k;
    cam.position = Vector3{ sinf(g.camAngle) * R, H, cosf(g.camAngle) * R };
    cam.target = Vector3{ 0.0f, 0.0f, 0.0f };
    cam.up = Vector3{ 0.0f, 1.0f, 0.0f };
    cam.fovy = 45.0f;
    cam.projection = CAMERA_PERSPECTIVE;
}

void UpdateTiles(float dt) {
    for (int s = 0; s < 4; ++s) {
        for (int n = 1; n <= NUM_TILES; ++n) {
            float target = 0.0f;
            if (g.boards[s].open[n]) {
                target = OPEN_ANG;
                if (g.state != State::Menu && s == CurSeat() && (g.selected & (1u << n))) target = SEL_ANG;
            }
            g.angle[s][n] += (target - g.angle[s][n]) * std::min(1.0f, dt * 9.0f);
        }
    }
}

void Update(float dt) {
    ReadInput();
    UpdateCamera(dt);
    UpdateTiles(dt);
    // Phone BACK button: closes settings; during a game press it twice to go to the main menu.
    if (IsKeyPressed(KEY_BACK)) {
        if (g_settings) {
            g_settings = false;
        } else if (g.state != State::Menu) {
            if (GetTime() - g_backT < 2.0) { ToMenu(); g_backT = -10.0; }
            else g_backT = GetTime();
        }
    }
    if (g_settings) return;          // game is frozen while the settings screen is open

    const int seat = CurSeat();
    switch (g.state) {
    case State::Menu:
    case State::GameOver:
        break;

    case State::WaitRoll: {
        const bool camReady = fabsf(g.camDiff) < 0.12f;
        if (IsBot(g.cur)) {
            g.botTimer -= dt;
            if (g.botTimer <= 0.0f && camReady) DoRoll();
        } else if (camReady && IsKeyPressed(KEY_SPACE)) {
            DoRoll();
        }
        break;
    }

    case State::Rolling:
        g.rollT += dt / 1.1f;
        if (g.rollT >= 1.0f) { g.rollT = 1.0f; EnterChoose(); }
        break;

    case State::Choose:
        if (IsBot(g.cur)) {
            g.botTimer -= dt;
            if (g.botTimer <= 0.0f) {
                if (g.botStage == 0) {
                    g.selected = botPick(g.combos);
                    g.botStage = 1;
                    g.botTimer = 0.8f;
                } else {
                    ConfirmSelection();
                }
            }
        } else {
            const int n = (int)g.combos.size();
            if (IsKeyPressed(KEY_ONE) && n >= 1)   { g.selected = g.combos[0]; ConfirmSelection(); break; }
            if (IsKeyPressed(KEY_TWO) && n >= 2)   { g.selected = g.combos[1]; ConfirmSelection(); break; }
            if (g_tap) {
                bool onButton = false;
                for (int i = 0; i < n; ++i)
                    if (CheckCollisionPointRec(g_mp, OptionRect(i, n))) onButton = true;
                if (!onButton) {
                    const int hit = PickTile(seat, g_mp);
                    if (hit) {
                        for (int i = 0; i < n; ++i) {
                            if (g.combos[i] & (1u << hit)) { g.selected = g.combos[i]; ConfirmSelection(); break; }
                        }
                    }
                }
            }
        }
        break;

    case State::Pause:
        g.timer -= dt;
        if (g.timer <= 0.0f) {
            if (g.pauseNext == PauseNext::EndTurn) EndTurn();
            else { g.state = State::WaitRoll; g.botTimer = 0.8f; }
        }
        break;
    }
}

// ------------------------------------------------------------ drawing: 3D
const Color DIE_COL = Color{ 52, 94, 168, 255 };     // blue glazed dice, white pips
const Color PIP_COL = Color{ 244, 242, 234, 255 };

void DrawPipFace(int value) {   // pips on the +Y face of a die (local space)
    const float a = 0.15f, base = 0.263f;
    auto pip = [&](float x, float z) {
        rlPushMatrix();
        rlTranslatef(x, base, z);
        DrawLit(gx.pip, gx.paint, PIP_COL, 0.25f, 16.0f);
        rlPopMatrix();
    };
    if (value == 1 || value == 3 || value == 5) pip(0, 0);
    if (value >= 2) { pip(-a, -a); pip(a, a); }
    if (value >= 4) { pip(-a, a); pip(a, -a); }
    if (value == 6) { pip(-a, 0); pip(a, 0); }
}

void DrawDie(int i) {
    if (i == 1 && g.oneDie) return;
    if (g.d1 == 0) return;
    const float t = g.rollT;
    const float e = 1.0f - (1.0f - t) * (1.0f - t);
    Vector3 p;
    p.x = g.dieStart[i].x + (g.dieEnd[i].x - g.dieStart[i].x) * e;
    p.z = g.dieStart[i].z + (g.dieEnd[i].z - g.dieStart[i].z) * e;
    p.y = g.dieEnd[i].y + fabsf(sinf(t * PI_F * 3.0f)) * (1.0f - t) * 2.2f;
    const float spin = powf(1.0f - t, 1.5f);
    const float ax = spin * g.dieSpin[i][0];
    const float az = spin * g.dieSpin[i][1];

    const int v = (i == 0) ? g.d1 : g.d2;       // value on the top face
    int rest[4], rn = 0;
    for (int k = 1; k <= 6; ++k) if (k != v && k != 7 - v) rest[rn++] = k;
    const int fa = rest[0];
    const int fb = (rest[1] != 7 - fa) ? rest[1] : rest[2];
    // face index: 0 +Y, 1 -Y, 2 +X, 3 -X, 4 +Z, 5 -Z
    const int val[6] = { v, 7 - v, fa, 7 - fa, fb, 7 - fb };

    rlPushMatrix();
    rlTranslatef(p.x, p.y, p.z);
    rlRotatef(g.dieYaw[i], 0, 1, 0);
    rlRotatef(ax, 1, 0, 0);
    rlRotatef(az, 0, 0, 1);
    DrawLit(gx.die, gx.stone, DIE_COL, 0.9f, 70.0f);
    for (int f = 0; f < 6; ++f) {
        rlPushMatrix();
        if (f == 1)      rlRotatef(180, 1, 0, 0);
        else if (f == 2) rlRotatef(-90, 0, 0, 1);
        else if (f == 3) rlRotatef(90, 0, 0, 1);
        else if (f == 4) rlRotatef(90, 1, 0, 0);
        else if (f == 5) rlRotatef(-90, 1, 0, 0);
        DrawPipFace(val[f]);
        rlPopMatrix();
    }
    rlPopMatrix();
}

void DrawDieShadow(int i) {
    if (i == 1 && g.oneDie) return;
    if (g.d1 == 0) return;
    const float t = g.rollT;
    const float e = 1.0f - (1.0f - t) * (1.0f - t);
    const float x = g.dieStart[i].x + (g.dieEnd[i].x - g.dieStart[i].x) * e;
    const float z = g.dieStart[i].z + (g.dieEnd[i].z - g.dieStart[i].z) * e;
    const float h = g.dieEnd[i].y + fabsf(sinf(t * PI_F * 3.0f)) * (1.0f - t) * 2.2f - 0.765f;
    const float k = 1.0f / (1.0f + h * 1.4f);
    DrawBlob(x + 0.10f, 0.474f, z + 0.12f, 0.62f + h * 0.18f, 0.62f + h * 0.18f, 0.62f * k);
}

void DrawScene() {
    // light follows the camera so every player sees the board lit from the front-left
    if (gx.ok) {
        const float ca = cosf(g.camAngle), sa = sinf(g.camAngle);
        const float lx0 = -0.45f, lz0 = 0.55f;
        float L[3] = { lx0 * ca + lz0 * sa, 1.0f, -lx0 * sa + lz0 * ca };
        float V[3] = { cam.position.x, cam.position.y, cam.position.z };
        SetShaderValue(gx.lit, gx.locLight, L, SHADER_UNIFORM_VEC3);
        SetShaderValue(gx.lit, gx.locView, V, SHADER_UNIFORM_VEC3);
    }

    // table
    DrawLit(gx.plane, gx.wood, Color{ 112, 86, 74, 255 }, 0.15f, 14.0f, 14.0f);

    // wooden board
    rlPushMatrix(); rlTranslatef(0, 0.225f, 0);
    DrawLit(gx.board, gx.wood, Color{ 214, 160, 110, 255 }, 0.45f, 32.0f);
    rlPopMatrix();
    const float rimY = 0.50f;
    const float zs[2] = { -6.7f, 6.7f };
    for (int k = 0; k < 2; ++k) {
        rlPushMatrix(); rlTranslatef(0, rimY, zs[k]);
        DrawLit(gx.rimLong, gx.wood, Color{ 196, 140, 94, 255 }, 0.5f, 36.0f);
        rlPopMatrix();
        rlPushMatrix(); rlTranslatef(zs[k], rimY, 0);
        DrawLit(gx.rimShort, gx.wood, Color{ 196, 140, 94, 255 }, 0.5f, 36.0f, 1.0f);
        rlPopMatrix();
    }

    // green felt in the middle
    rlPushMatrix(); rlTranslatef(0, 0.445f, 0);
    DrawLit(gx.feltBox, gx.felt, Color{ 34, 118, 62, 255 }, 0.04f, 6.0f);
    rlPopMatrix();

    const float pulse = 0.5f + 0.5f * sinf((float)GetTime() * 4.0f);
    const bool choosing = (g.state == State::Choose);
    uint16_t eligible = 0;
    if (choosing) for (uint16_t c : g.combos) eligible |= c;

    for (int s = 0; s < 4; ++s) {
        bool active = false;
        for (int i = 0; i < g.numPlayers; ++i) if (g.seats[i] == s) active = true;
        Color c = ColorBrightness(SEAT_COL[s], active ? -0.20f : -0.65f);
        const bool isCur = g.state != State::Menu && g.state != State::GameOver && s == CurSeat();
        if (isCur) c = ColorBrightness(SEAT_COL[s], 0.10f + 0.20f * pulse);

        rlPushMatrix();
        rlRotatef(s * 90.0f, 0, 1, 0);

        // coloured felt strip for this seat
        rlPushMatrix(); rlTranslatef(0, 0.45f, 5.6f);
        DrawLit(gx.strip, gx.felt, c, 0.05f, 6.0f);
        rlPopMatrix();

        // brass hinge rod
        rlPushMatrix();
        rlTranslatef(-4.85f, HINGE_Y + 0.03f, HINGE_Z + 0.03f);
        rlRotatef(-90.0f, 0, 0, 1);
        DrawLit(gx.rod, gx.paint, Color{ 214, 170, 70, 255 }, 1.0f, 60.0f);
        rlPopMatrix();

        for (int n = 1; n <= NUM_TILES; ++n) {
            const bool open = g.boards[s].open[n];
            const bool sel = (g.state != State::Menu) && s == CurSeat() && (g.selected & (1u << n));
            const bool elig = isCur && (eligible & (1u << n)) && !IsBot(g.cur);
            rlPushMatrix();
            rlTranslatef((n - 6.5f) * TILE_STEP, HINGE_Y, HINGE_Z);
            rlRotatef(g.angle[s][n], 1, 0, 0);
            rlTranslatef(0.0f, 0.06f, -0.6f);
            if (open) {
                Color body = sel ? Color{ 255, 168, 40, 255 } : SEAT_COL[s];
                const float gl = elig ? 0.10f + 0.16f * pulse : 0.0f;
                DrawLit(gx.tile, gx.paint, body, 1.0f, 70.0f, 1.0f, gl, gl * 0.85f, gl * 0.3f);
            } else {
                DrawLit(gx.tile, gx.wood, Color{ 120, 84, 60, 255 }, 0.25f, 14.0f);
            }
            rlPopMatrix();
        }
        rlPopMatrix();
    }
    DrawDie(0);
    DrawDie(1);

    // soft shadows (drawn last, without writing depth)
    rlDrawRenderBatchActive();
    rlDisableDepthMask();
    DrawBlob(0.2f, 0.03f, 0.3f, 10.5f, 10.5f, 0.55f);     // board on table
    DrawDieShadow(0);
    DrawDieShadow(1);
    rlDrawRenderBatchActive();
    rlEnableDepthMask();
}

// ------------------------------------------------------------ drawing: 2D
// Text is drawn with an embedded font (Latin + Arabic). Arabic text is written
// normally in the code; ar::Shape() joins the letters and puts them right-to-left.
Font g_fontBig = {}, g_fontSmall = {};
bool g_fontOk = false;

void LoadUIFonts() {
    int* cps = const_cast<int*>(FONT_CPS);
    g_fontBig   = LoadFontFromMemory(".ttf", FONT_DATA, FONT_DATA_SIZE, 96, cps, FONT_CPS_COUNT);
    g_fontSmall = LoadFontFromMemory(".ttf", FONT_DATA, FONT_DATA_SIZE, 40, cps, FONT_CPS_COUNT);
    g_fontOk = g_fontBig.texture.id > 0 && g_fontSmall.texture.id > 0 && g_fontBig.glyphCount > 0;
    if (g_fontOk) {
        SetTextureFilter(g_fontBig.texture, TEXTURE_FILTER_BILINEAR);
        SetTextureFilter(g_fontSmall.texture, TEXTURE_FILTER_BILINEAR);
    }
}

Font PickFont(int size) {
    if (!g_fontOk) return GetFontDefault();
    return size <= 44 ? g_fontSmall : g_fontBig;
}
float FontSpacing(int size) { return g_fontOk ? 0.0f : size / 10.0f; }

float TxtW(const char* s, int size) {
    const std::string v = ar::Shape(s);
    return MeasureTextEx(PickFont(size), v.c_str(), (float)size, FontSpacing(size)).x;
}
void Txt(const char* s, float x, float y, int size, Color c) {
    const std::string v = ar::Shape(s);
    const Font f = PickFont(size);
    const int o = std::max(1, size / 14);
    DrawTextEx(f, v.c_str(), Vector2{ x + o, y + o }, (float)size, FontSpacing(size), Fade(BLACK, 0.65f));
    DrawTextEx(f, v.c_str(), Vector2{ x, y }, (float)size, FontSpacing(size), c);
}
void TxtC(const char* s, float cx, float y, int size, Color c) {
    Txt(s, cx - TxtW(s, size) / 2.0f, y, size, c);
}
void TxtR(const char* s, float rightX, float y, int size, Color c) {   // right-aligned
    Txt(s, rightX - TxtW(s, size), y, size, c);
}

float Pulse(float speed) { return 0.5f + 0.5f * sinf((float)GetTime() * speed); }
Rectangle Grow(Rectangle r, float e) { return Rectangle{ r.x - e, r.y - e, r.width + 2 * e, r.height + 2 * e }; }

bool Btn(Rectangle r, const char* label, Color col, int fontSize) {
    const bool hover = CheckCollisionPointRec(g_mp, r);
    DrawRectangleRounded(Rectangle{r.x + 3, r.y + 4, r.width, r.height}, 0.3f, 8, Fade(BLACK, 0.4f));
    DrawRectangleRounded(r, 0.3f, 8, hover ? ColorBrightness(col, 0.2f) : col);
    TxtC(label, r.x + r.width / 2, r.y + (r.height - fontSize) / 2, fontSize, WHITE);
    if (g_tap && hover) { g_tap = false; return true; }
    return false;
}

// colours of the two choices (match the two buttons at the bottom)
const Color HINT_COL[2] = { Color{90,190,255,255}, Color{255,170,50,255} };

void DrawTileNumbers() {
    const bool hint = g_hints && g.state == State::Choose && !IsBot(g.cur) && !g_settings;
    const float pulse = Pulse(8.0f);
    for (int s = 0; s < 4; ++s) {
        const float phi = s * PI_F / 2.0f;
        for (int n = 1; n <= NUM_TILES; ++n) {
            if (!g.boards[s].open[n] || g.angle[s][n] < 22.0f) continue;
            Vector3 c = TileCenter(s, n, g.angle[s][n]);
            Vector2 p = GetWorldToScreen(c, cam);
            Vector3 r = Vector3{ c.x + 0.4f * cosf(phi), c.y, c.z - 0.4f * sinf(phi) };
            Vector2 p2 = GetWorldToScreen(r, cam);
            float halfW = hypotf(p2.x - p.x, p2.y - p.y);
            int fs = (int)Clampf(halfW * 1.5f, 10.0f, 52.0f);
            char buf[8];
            std::snprintf(buf, sizeof(buf), "%d", n);
            const bool sel = (g.state != State::Menu) && s == CurSeat() && (g.selected & (1u << n));

            int opt = -1;      // which choice (0 or 1) this tile belongs to
            if (hint && s == CurSeat()) {
                for (int i = 0; i < (int)g.combos.size() && i < 2; ++i)
                    if (g.combos[i] & (1u << n)) opt = i;
            }
            if (opt >= 0) {
                const float rad = halfW * (0.68f + 0.20f * pulse);
                DrawCircleV(p, rad, Fade(HINT_COL[opt], 0.30f + 0.40f * pulse));
                DrawCircleLines((int)p.x, (int)p.y, rad, HINT_COL[opt]);
                DrawCircleLines((int)p.x, (int)p.y, rad + 1.0f, HINT_COL[opt]);
                TxtC(buf, p.x, p.y - fs / 2.0f, fs, WHITE);
                const int lab = std::max(11, fs / 2);
                TxtC(T("TAP", "اضغط"), p.x, p.y - rad - lab - 3.0f, lab, HINT_COL[opt]);
            } else {
                TxtC(buf, p.x, p.y - fs / 2.0f, fs, sel ? BLACK : WHITE);
            }
        }
    }
}

void DrawMenu() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    DrawRectangle(0, 0, (int)W, (int)H, Fade(BLACK, 0.45f));
    const float cx = W / 2;
    float y = H * 0.07f;
    TxtC("Q BOOL", cx, y, (int)(84 * u), Color{255,210,70,255});
    y += 100 * u;
    TxtC(T("3D dice & tiles board game  (2-4 players)", "لعبة طاولة ثلاثية الأبعاد (2-4 لاعبين)"),
         cx, y, (int)(24 * u), WHITE);
    y += 56 * u;

    TxtC(T("Players", "عدد اللاعبين"), cx, y, (int)(26 * u), WHITE);
    y += 38 * u;
    for (int i = 0; i < 3; ++i) {
        const int n = i + 2;
        Rectangle r{ cx + (i - 1.5f) * 84 * u + 5 * u, y, 74 * u, 56 * u };
        char b[4]; std::snprintf(b, sizeof(b), "%d", n);
        if (Btn(r, b, g.numPlayers == n ? Color{230,150,20,255} : Color{70,70,90,255}, (int)(30 * u)))
            g.numPlayers = n;
    }
    y += 80 * u;

    TxtC(T("Mode", "نوع اللعب"), cx, y, (int)(26 * u), WHITE);
    y += 38 * u;
    {
        Rectangle a{ cx - 190 * u, y, 180 * u, 56 * u };
        Rectangle b{ cx + 10 * u,  y, 180 * u, 56 * u };
        if (Btn(a, T("Pass & Play", "لعب مع بعض"), !g.vsComputer ? Color{230,150,20,255} : Color{70,70,90,255}, (int)(24 * u)))
            g.vsComputer = false;
        if (Btn(b, T("vs Computer", "ضد الكمبيوتر"), g.vsComputer ? Color{230,150,20,255} : Color{70,70,90,255}, (int)(24 * u)))
            g.vsComputer = true;
    }
    y += 90 * u;
    Rectangle go{ cx - 120 * u, y, 240 * u, 70 * u };
    if (Btn(go, T("START", "ابدأ"), Color{40,160,70,255}, (int)(36 * u)) || IsKeyPressed(KEY_ENTER)) StartGame();
    y += 90 * u;

    TxtC(T("One roll per turn. Close both dice tiles (e.g. 2 and 3) or just their sum (5).",
           "رمية وحدة بكل دور. اغلق قطعتي الزهرتين (مثلا 2 و 3) أو قطعة المجموع بس (5)."),
         cx, y, (int)(18 * u), Color{230,230,230,255});
    TxtC(T("Can't move? Your open tiles are your score. Lowest score wins!",
           "إذا ما تقدر تلعب، القطع المفتوحة هي نقاطك. الأقل نقاط يفوز!"),
         cx, y + 26 * u, (int)(18 * u), Color{230,230,230,255});

    if (Btn(SettingsBtnRect(), T("Settings", "الإعدادات"), Color{70,70,90,255}, (int)(20 * u)))
        g_settings = true;
}

// "press back again" message
void DrawBackToast() {
    if (GetTime() - g_backT >= 2.0) return;
    const float u = UIScale();
    const float W = (float)GetScreenWidth();
    const char* m = T("Press BACK again to return to the main menu", "اضغط رجوع مرة ثانية حتى ترجع للقائمة الرئيسية");
    const int fs = (int)(22 * u);
    const float w = TxtW(m, fs) + 40 * u;
    DrawRectangleRounded(Rectangle{W / 2 - w / 2, 100 * u, w, 44 * u}, 0.3f, 8, Fade(BLACK, 0.7f));
    TxtC(m, W / 2, 100 * u + (44 * u - fs) / 2, fs, Color{255,225,110,255});
}

void DrawHUD() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth();
    const float H = (float)GetScreenHeight();
    const int seat = CurSeat();

    Txt("Q BOOL", 14 * u, 10 * u, (int)(30 * u), Color{255,210,70,255});

    // scoreboard (top-right)
    const float boxW = 236 * u;
    const float boxX = W - boxW - 12 * u;
    DrawRectangleRounded(Rectangle{boxX, 6 * u, boxW, (g.numPlayers * 28 + 12) * u}, 0.15f, 6, Fade(BLACK, 0.45f));
    for (int i = 0; i < g.numPlayers; ++i) {
        const int s = g.seats[i];
        const float rowY = (10 + i * 28) * u;
        char line[64];
        if (g.done[i]) std::snprintf(line, sizeof(line), g_ar ? "%s: نقاط %d" : "%s: score %d", SeatName(s), g.scores[i]);
        else           std::snprintf(line, sizeof(line), g_ar ? "%s: مفتوح %d" : "%s: open %d", SeatName(s), g.boards[s].openSum());
        const bool isCur = (i == g.cur && g.state != State::GameOver);
        const Color tc = isCur ? Color{255,230,120,255} : WHITE;
        if (g_ar) {
            const float sqX = boxX + boxW - 10 * u - 16 * u;
            DrawRectangle((int)sqX, (int)(rowY + 2 * u), (int)(16 * u), (int)(16 * u), SEAT_COL[s]);
            TxtR(line, sqX - 8 * u, rowY, (int)(18 * u), tc);
        } else {
            DrawRectangle((int)(boxX + 10 * u), (int)(rowY + 2 * u), (int)(16 * u), (int)(16 * u), SEAT_COL[s]);
            Txt(line, boxX + 34 * u, rowY, (int)(18 * u), tc);
        }
    }

    // turn banner
    char t[96];
    if (g_ar) std::snprintf(t, sizeof(t), "دور %s%s", SeatName(seat), IsBot(g.cur) ? " (كمبيوتر)" : "");
    else      std::snprintf(t, sizeof(t), "%s's turn%s", SeatName(seat), IsBot(g.cur) ? " (computer)" : "");
    TxtC(t, W / 2, 12 * u, (int)(34 * u), SEAT_COL[seat].r > 200 && SEAT_COL[seat].g > 180 ? SEAT_COL[seat] : ColorBrightness(SEAT_COL[seat], 0.35f));

    // roll info
    if (g.rollTotal > 0 && g.rollT >= 1.0f) {
        char r[96];
        if (g.oneDie) std::snprintf(r, sizeof(r), g_ar ? "الرمية: %d  (زهرة وحدة)" : "Roll: %d  (one die)", g.d1);
        else          std::snprintf(r, sizeof(r), g_ar ? "الرمية: %d + %d = %d" : "Roll: %d + %d = %d", g.d1, g.d2, g.rollTotal);
        TxtC(r, W / 2, 58 * u, (int)(28 * u), WHITE);
    }

    if (g.state == State::WaitRoll && !IsBot(g.cur) && fabsf(g.camDiff) < 0.12f) {
        Rectangle rr = RollRect();
        if (g_hints) {
            const float pulse = Pulse(6.0f);
            TxtC(T("Tap ROLL to throw the dice", "اضغط على الزر حتى ترمي الزهر"),
                 W / 2, H - 150 * u, (int)(22 * u), Color{150,220,255,255});
            rr = Grow(rr, 5 * u * pulse);
        }
        if (Btn(rr, T("ROLL", "ارمي"), Color{220,120,20,255}, (int)(34 * u))) DoRoll();
    }
    if (g.state == State::Choose && !IsBot(g.cur)) {
        const int n = (int)g.combos.size();
        if (g_hints) {
            TxtC(T("Choose one: tap a blinking number, or a button below",
                   "اختار واحد: اضغط على الرقم اللي يلمع، أو على الزر اللي تحت"),
                 W / 2, H - 150 * u, (int)(20 * u), Color{150,220,255,255});
        }
        const float pulse = Pulse(8.0f);
        int picked = -1;
        for (int i = 0; i < n; ++i) {
            char lab[48];
            int a1 = 0, a2 = 0;
            for (int t2 = 1; t2 <= NUM_TILES; ++t2) if (g.combos[i] & (1u << t2)) { if (!a1) a1 = t2; else a2 = t2; }
            if (a2) std::snprintf(lab, sizeof(lab), g_ar ? "اغلق %d + %d" : "Close %d + %d", a1, a2);
            else    std::snprintf(lab, sizeof(lab), g_ar ? "اغلق %d" : "Close %d", a1);
            Rectangle br = OptionRect(i, n);
            if (g_hints) br = Grow(br, 4 * u * pulse);
            if (Btn(br, lab, i == 0 ? Color{40,140,200,255} : Color{200,120,30,255}, (int)(26 * u)))
                picked = i;
        }
        if (picked >= 0) { g.selected = g.combos[picked]; ConfirmSelection(); }
    }
    if (g.state == State::Pause && g.msgKind) {
        char m[96];
        if (g.msgKind == 1)
            std::snprintf(m, sizeof(m), g_ar ? "ما كو حركة!  %s: %d نقطة" : "No move!  %s scores %d", SeatName(g.msgSeat), g.msgScore);
        else
            std::snprintf(m, sizeof(m), g_ar ? "أغلق الصندوق بالكامل!  %s: 0 نقطة" : "SHUT THE BOX!  %s scores 0", SeatName(g.msgSeat));
        const int fs = (int)(40 * u);
        const float w = TxtW(m, fs) + 60 * u;
        DrawRectangleRounded(Rectangle{W / 2 - w / 2, H / 2 - 40 * u, w, 80 * u}, 0.3f, 8, Fade(BLACK, 0.65f));
        TxtC(m, W / 2, H / 2 - fs / 2.0f, fs, Color{255,225,110,255});
    }
    DrawBackToast();
#if defined(__EMSCRIPTEN__)
    if (H > W) TxtC(T("Tip: rotate your phone sideways", "نصيحة: دور الجهاز بالعرض"), W / 2, H - 28 * u, (int)(16 * u), Fade(WHITE, 0.8f));
#endif
}

void DrawGameOver() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    DrawRectangle(0, 0, (int)W, (int)H, Fade(BLACK, 0.55f));
    int best = 1000;
    for (int i = 0; i < g.numPlayers; ++i) best = std::min(best, g.scores[i]);
    float y = H * 0.12f;
    TxtC(T("GAME OVER", "انتهت اللعبة"), W / 2, y, (int)(60 * u), Color{255,210,70,255});
    y += 90 * u;
    for (int i = 0; i < g.numPlayers; ++i) {
        const int s = g.seats[i];
        const bool win = g.scores[i] == best;
        char line[96];
        std::snprintf(line, sizeof(line), g_ar ? "%s   %d%s" : "%s   %d%s", SeatName(s), g.scores[i],
                      win ? (g_ar ? "   الفائز!" : "   WINNER!") : "");
        Color c = win ? Color{255,230,110,255} : WHITE;
        if (g_ar) {
            const float rightEdge = W / 2 + 170 * u;
            DrawRectangle((int)(rightEdge - 22 * u), (int)(y + 4 * u), (int)(22 * u), (int)(22 * u), SEAT_COL[s]);
            TxtR(line, rightEdge - 36 * u, y, (int)(30 * u), c);
        } else {
            DrawRectangle((int)(W / 2 - 170 * u), (int)(y + 4 * u), (int)(22 * u), (int)(22 * u), SEAT_COL[s]);
            Txt(line, W / 2 - 135 * u, y, (int)(30 * u), c);
        }
        y += 46 * u;
    }
    y += 24 * u;
    if (Btn(Rectangle{W / 2 - 130 * u, y, 260 * u, 66 * u}, T("PLAY AGAIN", "العب مرة ثانية"), Color{40,160,70,255}, (int)(30 * u))
        || IsKeyPressed(KEY_ENTER)) ToMenu();
    DrawBackToast();
}

// Settings screen: language (Arabic / English) and hints (on / off).
void DrawSettings() {
    const float u = UIScale();
    const float W = (float)GetScreenWidth(), H = (float)GetScreenHeight();
    DrawRectangle(0, 0, (int)W, (int)H, Fade(BLACK, 0.72f));
    const float pw = 520 * u, ph = 400 * u;
    const float px = W / 2 - pw / 2, py = H / 2 - ph / 2;
    DrawRectangleRounded(Rectangle{px, py, pw, ph}, 0.08f, 8, Color{44,34,30,250});
    const Color on  = Color{230,150,20,255};
    const Color off = Color{70,70,90,255};
    const float cx = W / 2;
    float y = py + 16 * u;
    TxtC(T("Settings", "الإعدادات"), cx, y, (int)(42 * u), Color{255,210,70,255});

    y += 80 * u;
    TxtC(T("Language", "اللغة"), cx, y, (int)(26 * u), WHITE);
    y += 38 * u;
    if (Btn(Rectangle{cx - 190 * u, y, 180 * u, 54 * u}, "العربية", g_ar ? on : off, (int)(26 * u))) g_ar = true;
    if (Btn(Rectangle{cx + 10 * u,  y, 180 * u, 54 * u}, "English", !g_ar ? on : off, (int)(26 * u))) g_ar = false;

    y += 80 * u;
    TxtC(T("Hints", "التلميحات"), cx, y, (int)(26 * u), WHITE);
    y += 38 * u;
    if (Btn(Rectangle{cx - 190 * u, y, 180 * u, 54 * u}, T("On", "تشغيل"),  g_hints ? on : off, (int)(26 * u))) g_hints = true;
    if (Btn(Rectangle{cx + 10 * u,  y, 180 * u, 54 * u}, T("Off", "إيقاف"), !g_hints ? on : off, (int)(26 * u))) g_hints = false;

    y += 84 * u;
    if (Btn(Rectangle{cx - 110 * u, y, 220 * u, 56 * u}, T("Back", "رجوع"), Color{40,160,70,255}, (int)(28 * u))
        || IsKeyPressed(KEY_ENTER)) g_settings = false;
}

void Draw() {
    BeginDrawing();
    ClearBackground(Color{28,22,20,255});
    BeginMode3D(cam);
    DrawScene();
    EndMode3D();
    DrawTileNumbers();
    if (g_settings)                      DrawSettings();
    else if (g.state == State::Menu)     DrawMenu();
    else if (g.state == State::GameOver) DrawGameOver();
    else                                 DrawHUD();
    EndDrawing();
}

void Frame() {
    float dt = GetFrameTime();
    if (dt > 0.05f) dt = 0.05f;
    Update(dt);
    Draw();
}

} // namespace

int main() {
    int w = 1280, h = 720;
#if defined(__EMSCRIPTEN__)
    w = EM_ASM_INT({ return window.innerWidth; });
    h = EM_ASM_INT({ return window.innerHeight; });
#endif
#if defined(__ANDROID__)
    w = 0; h = 0;   // 0,0 = use the whole phone/tablet screen
#endif
    SetConfigFlags(FLAG_MSAA_4X_HINT | FLAG_WINDOW_RESIZABLE | FLAG_VSYNC_HINT);
    InitWindow(w, h, "Q BOOL");
    SetTargetFPS(60);
    SetRandomSeed((unsigned int)std::time(nullptr));
    LoadUIFonts();
    InitGraphics();

    g.numPlayers = 4;
    for (int s = 0; s < 4; ++s)
        for (int n = 0; n <= NUM_TILES; ++n) g.angle[s][n] = g.boards[s].open[n] ? OPEN_ANG : 0.0f;
    cam.up = Vector3{0, 1, 0};

#if defined(__EMSCRIPTEN__)
    emscripten_set_main_loop(Frame, 0, 1);
#else
    while (!WindowShouldClose()) Frame();
#endif
    CloseWindow();
    return 0;
}
